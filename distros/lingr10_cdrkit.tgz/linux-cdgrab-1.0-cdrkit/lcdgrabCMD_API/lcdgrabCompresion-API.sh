#########################################################
# lcgdrabCMD_API/lcdgrabCompresion-API.sh
# Soporte para archivos comprimidos.
# Pascual Martínez Cruz --> pascual89@hotmail.com
#
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

################ COMPRESIÓN DE ARCHIVOS  ################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabCompresion-API.idiom

# empaquetar
# empaqueta una imagen o directorio

empaquetar(){

INPUT=${D_TMP}/menu.sh.$$

echo $empaquetar_MSG1
read ruta

case $UD in
0)
    dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
    --title "$PROGRAMA PKG MENU" \
    --menu "" 20 70 20 \
    1 "$empaquetar_MSG3" \
    2 "$empaquetar_MSG4" \
    0 "$empaquetar_MSG5" 2>"${INPUT}"
    eop=$(<"${INPUT}")
;;

1)
    echo $empaquetar_MSG2
    echo "1.- $empaquetar_MSG3"
    echo "2.- $empaquetar_MSG4"
    echo -n $empaquetar_MSG5
    read eop
;;

2)
	eop=$(zenity --width=400 --height=300 --title="$PROGRAMA" --entry --text="
$empaquetar_MSG2
1.- $empaquetar_MSG3
2.- $empaquetar_MSG4")
;;

3)
	eop=$(kdialog --menu "$empaquetar_MSG2" \
1 "1- $empaquetar_MSG3" \
2 "2. $empaquetar_MSG4" --geometry=200x170 --title "$PROGRAMA")

;;

esac

case $eop in
1) 

	optspkggz="$ruta.tar.gz $ruta"
	lingrcmdexec $lingrpkggz "#" $optspkggz "#" "NM""#" "NM"
;;

2) 
	echo "$empaquetar_MSG6:$lingrpkgbz2 $ruta.tar.bz2 $ruta"
	optspkgbz2="$ruta.tar.bz2 $ruta"

	lingrcmdexec $lingrpkgbz2 "#" $optspkgbz2 "#" "NM" "#" "NM" || lingrcmdexec $lingrpkgbz2p "#" $optspkgbz2 "#" "NM" "#" "NM"
;;

*)
	pinta_mensaje ${COLOR_DEL_INTERFAZ} $empaquetar_MSG7
;;
esac
teclash

[ -f $INPUT ] && rm -f $INPUT &> /dev/null

}

# desempaquetar
# desempaqueta una imagen o directorio

desempaquetar(){

echo $desempaquetar_MSG1
read ruta
if ls $ruta | grep -e ".gz" && expr $? != 2;then

	opciones="-xvzf"

elif ls $ruta | grep -e ".bz2" && expr $? != 2;then

	opciones="-xvjf"

else
	echo ""
	echo ""
	echo -e "${C_FA}"
	echo "$desempaquetar_MSG2 $archivo_comprimido"
	echo ""
	echo "$desempaquetar_MSG3 $archivo_comprimido $desempaquetar_MSG4"
	echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	echo ""
	teclash
	break
fi

echo "$desempaquetar_MSG5:tar $opciones $ruta"

optspkg="$opciones $ruta"
msgokdec="$ruta $desempaquetar_MSG6"
msgerrdec="$desempaquetar_MSG7 $ruta"
lingrcmdexec $lingrpkg "#" $optspkg "#" $msgokdec "#" $msgerrdec

teclash
}

# comprime
#
# comprime una imagen

comprime(){

INPUT=${D_TMP}/menu.sh.$$

mensaje=$comprime_MSG1

clear

while $verdadero;do

	case $UD in
	0)
		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA COMPRESION MENU" \
		--menu "" 13 37 13 \
		1 "$comprime_MSG2" \
		2 "$comprime_MSG3" \
		3 "$comprime_MSG4" \
		0 "$comprime_MSG5" 2>"${INPUT}"
		menu_comprime=$(<"${INPUT}")
	;;

	1)
		cabecera
		echo "1.- $comprime_MSG2"
		echo "2.- $comprime_MSG3"
		echo "3.- $comprime_MSG4"
		echo ""
		echo "0.- $comprime_MSG5"

		read menu_comprime
	;;

	2)
		menu_comprime=$(zenity --width=300 --height=220 --title=$PROGRAMA --entry --text="
1.- $comprime_MSG2
2.- $comprime_MSG3
3.- $comprime_MSG4
0.- $comprime_MSG5")
	;;

	3)
		menu_comprime=$(kdialog --menu "GZIP, BZIP2, XZ MENU" \
1 "1.- $comprime_MSG2" \
2 "2.- $comprime_MSG3" \
3 "3.- $comprime_MSG4" \
0 "0.- $comprime_MSG5" --geometry=260x190 --title "$PROGRAMA")
	;;

	esac

	case $menu_comprime in

		1 | 2 | 3)
			echo $mensaje

			if test $menu_comprime -eq 1;then
#				compresor=bzip2
				compresor="$lingrcompbz2"
			elif test $menu_comprime -eq 2;then
#				compresor=gzip
				compresor="$lingrcompgz"
			elif test $menu_comprime -eq 3;then
#				compresor="xz -z"
				compresor="$lingrcompxz"
			fi

			msgerrcomp="$comprime_MSG8 $compresor"

			lingrcmdexec $compresor "#"$imagen "#" $comprime_MSG7 "#" $msgerrcomp

		;;

		0)
		    break
		;;

		*)
		    pinta_mensaje ${COLOR_DEL_INTERFAZ} $comprime_MSG9
		;;


	esac

done

[ -f $INPUT ] && rm -f $INPUT &> /dev/null

}

# descomprime
# descomprime una imagen

descomprime(){

typeset local archdescomp=""

cabecera
echo $descomprime_MSG1
echo $descomprime_MSG2
echo ""
read archivo_comprimido

#	solo se descomprime el .gz .bz2 .zip y xz
#	grep retorna 2 en caso de un error inesperado

if ls $archivo_comprimido | grep -e ".gz" && expr $? != 2;then

	descompresor=$lingrdcompgz

elif ls $archivo_comprimido | grep -e ".bz2" && expr $? != 2;then

	descompresor=$lingrdcompbz2

elif ls $archivo_comprimido | grep -e ".zip" && expr $? != 2;then

	descompresor=$lingrdcompzip

elif ls $archivo_comprimido | grep -e ".xz" && expr $? != 2;then

	descompresor=$lingrdcompxz
else
	echo ""
	echo ""
	echo -e "${C_FA}"
	echo "$descomprime_MSG3 $archivo_comprimido"
	echo ""
	echo "$descomprime_MSG4 $archivo_comprimido $descomprime_MSG5"
	echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	echo ""
	teclash
	break
fi

	zfm="$archivo_comprimido $descomprime_MSG7"
        lingrcmdexec $descompresor "#" $archivo_comprimido "#" $zfm "#" $descomprime_MSG8

}


