#########################################################
# lcgdrabCMD_API/lcdgrabExpulsaCDDVD-API.sh
# Implementa la expulsión del disco insertado en la
# unidad.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

# Expande el archivo de idioma

source $D_LINUXCDGRAB/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabExpulsaCDDVD-API.idiom

# expulsar_medio
# Expulsa el disco de un dispositivo de bloque

expulsar_medio(){

if ! test -z $*;then
	UNIDAD_OPTICA=$*
else
	UNIDAD_OPTICA=$LECTOR_CDROM
fi

lingrcmdexec $lingreject "#"$UNIDAD_OPTICA "#" "NM" "#" "NM" || lingrcmdexec "$lingreject $ejectop1" "#"$UNIDAD_OPTICA "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
	echo $expulsar_medio_MSG1
	sleep 1
else
			
	cabecera
	echo ""
	echo -e "${C_FA}$expulsar_medio_MSG2 $CDROM${COLOR_DEL_INTERFAZ}"
	sleep 1

	obten_cadena " " "$expulsar_medio_MSG3"
	UNIDAD_OPTICA=$lacadena


	ejectallopts="$ejectop1 $UNIDAD_OPTICA"
	
	lingrcmdexec $lingreject "#" $ejectallopts "#" "NM" "#" "NM"

fi

clear

}


