#########################################################
# lcgdrabCMD_API/lcdgrabVIDEO-API.sh
# Coleccion de funciones para tratamiento y
# conversión de archivos de video.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

########################## CONVERSION DE VIDEO ################################
###############################################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabVIDEO-API.idiom

# conv_video_BDVideo
#
# Convierte un archivo de video mkv dando
# compatibilidad a un reproductor blu-ray
# o smart-TV

conv_video_BDVideo(){

obten_cadena "$conv_video_BDVideo_MSG1" "$conv_video_BDVideo_MSG2"
origvideo=$lacadena

obten_cadena "$conv_video_BDVideo_MSG1" "$conv_video_BDVideo_MSG3"
destvideo=$lacadena

lingrcmdexec $lingrvideocv1 "#"$ffmpegvid2brvop1 $origvideo $ffmpegvid2brvop2 $destvideo "#" $conv_video_BDVideo_MSG4 "#" $conv_video_BDVideo_MSG5

}

# conv_VideoFich
#
# Convierte archivos de video a diferentes formatos mpeg, mkv, mp4, flv ...
# (No se hace ningún tratamiento de calidad sobre el video generado)

conv_VideoFich(){

obten_cadena "$conv_VideoFich_MSG1" "$conv_VideoFich_MSG2"
videoin="$lacadena"

obten_cadena "$conv_VideoFich_MSG1" "$conv_VideoFich_MSG3"
videoout="$lacadena"

lingrcmdexec $lingrvideocv1 "#"$ffmpegvid2brvop1 $videoin $ffmpegfvcforop1 $videoout "#" $conv_VideoFich_MSG4 "#" $conv_VideoFich_MSG5

}

# extrae_Audio_de_Video
#
# extrae el audio de un archivo de video a .mp3
# Ejem:ffmpeg -i source_video.avi -vn -ar 44100 -ac 2 -ab 192k -f mp3 sound.mp3

extrae_Audio_de_Video(){

obten_cadena "EXT AUDIO VIDEO" "$extrae_Audio_de_Video_MSG1"
fvid="$lacadena"

obten_cadena "EXT AUDIO VIDEO" "$extrae_Audio_de_Video_MSG2"
faudmp3="$lacadena"

lingrcmdexec $lingrvideocv1 "#"$ffmpegvid2brvop1 $fvid $ffmpegextaudfvop1 $faudmp3 "#" $extrae_Audio_de_Video_MSG3 "#" $extrae_Audio_de_Video_MSG4

}

# extrae_Fragmento_Video
#
# extrae un fragmento de Video de un archivo de Video original.
# Ejem: ffmpeg -ss 00:00:30 -i orginalfile.mpg -t 00:00:05 -vcodec copy -acodec copy newfile.mpg

extrae_Fragmento_Video(){

obten_cadena "EXT VIDEO" "$extrae_Fragmento_Video_MSG1"
inivideo="$lacadena"

obten_cadena "EXT VIDEO" "$extrae_Fragmento_Video_MSG2"
finvideo="$lacadena"

obten_cadena "EXT VIDEO" "$extrae_Fragmento_Video_MSG3"
vtini="$lacadena"

obten_cadena "EXT VIDEO" "$extrae_Fragmento_Video_MSG4"
vtfin="$lacadena"

lingrcmdexec $lingrvideocv1 "#" $ffmpegextvidop1 $vtini $ffmpegvid2brvop1 $inivideo $ffmpegextvidop2 $vtfin $ffmpegextvidop3 $finvideo "#" $extrae_Fragmento_Video_MSG5 "#" $extrae_Fragmento_Video_MSG6

}

# mezcla_Audio_Video
#
# Mezcla un video con un fichero de sonido
# Ejem: ffmpeg -i sound.wav -i original_video.avi final_video.mpg

mezcla_Audio_Video(){

obten_cadena "VIDEO+AUDIO" "$mezcla_Audio_Video_MSG1"
vcancion="$lacadena"

obten_cadena "VIDEO+AUDIO" "$mezcla_Audio_Video_MSG2"
vvideo="$lacadena"

obten_cadena "VIDEO+AUDIO" "$mezcla_Audio_Video_MSG3"
finalvideo="$lacadena"

lingrcmdexec $lingrvideocv1 "#"$ffmpegvid2brvop1 $vcancion $ffmpegvid2brvop1 $vvideo $finalvideo"#" $mezcla_Audio_Video_MSG4 "#" $mezcla_Audio_Video_MSG5

}

# graba_escritorio
#
# Graba una sesión de escritorio del usuario.
# Ejemplo Pulse Audio
# ffmpeg -video_size 1920x1080 -framerate 25 -f x11grab -i :0.0 -f pulse -ac 2 -i default salida.mkv
# Ejemplo ALSA
# ffmpeg -video_size 1920x1080 -framerate 25 -f x11grab -i :0.0 -f alsa -ac 2 -i hw:0 salida.mkv


graba_escritorio(){

typeset local fvideoout="$HOME/lcdgrabSesionEscritorio.mkv"
typeset local XResolucion=""

if test -z $DISPLAY;then
	pinta_mensaje "${C_AV}" "$graba_escritorio_MSG1"
else

	if test -f $fvideoout;then
		rm -rf $fvideoout &> /dev/null
	fi
# obtiene la resolución actual usada del entorno gráfico.
	XResolucion="$(xrandr | grep -e '*+' | cut -c 4-12)"
	
	cabecera
	echo -e "${C_AV} $graba_escritorio_MSG2 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	sleep 0.8

	lingrcmdexec $lingrvideocv1 "#"$ffmpeggescpa1 $XResolucion $ffmpeggescpa2 $fvideoout "#" "NM" "#" "NM"

	cabecera

	pinta_mensaje "${C_AV}" "$graba_escritorio_MSG3"

fi

}


