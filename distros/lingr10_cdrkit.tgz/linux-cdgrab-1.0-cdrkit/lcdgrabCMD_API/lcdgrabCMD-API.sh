#########################################################
# lcdgrabCMD_API/lcdgrabCMD-API.sh
# Carga de procedimientos generales para lcdgrabCMD_API
# junto con los procedimientos de éste mismo directorio.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

# Expande los procedimientos generales a lcdgrabCMD junto 
# con los comandos usados

source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabAPP-SYS.sh

# Expande los procedimientos de lcdgrabCMD_API

source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabCompresion-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabExpulsaCDDVD-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabIMAGENESCDDVDBD-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabAUDIO-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabVIDEO-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabCD-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabDVD-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabBD-API.sh
source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabUNIDADES-API.sh



