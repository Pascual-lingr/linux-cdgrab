#########################################################
# lcgdrabCMD_API/lcdgrabIMAGENESCDDVDBD-API.sh
# Colección de funciones para la creación y tratamiento
# de imágenes de CD, DVD y BD.
# Variante para la version debian_cdrkit
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

##################### IMÁGENES  #########################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabIMAGENESCDDVDBD-API.idiom

# imagen_linux_fs
#
# Crea una imagen ext2, ext3, ext4, XFS, JFS y Btrfs.

imagen_linux_fs(){

INPUT=${D_TMP}/menu.sh.$$

while $lverdadero;do

case $UD in
	0)
		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA LINUX FS MENU" \
		--menu "$imagen_linux_fs_MSG34" 15 50 13 \
		1 "ext2" \
		2 "ext3" \
		3 "ext4" \
		4 "XFS" \
		5 "JFS" \
		6 "BTRFS" 2>"${INPUT}"
		IMAGENDD_FS="$(<${INPUT})"
	;;

	1)
		cabecera
		echo "$imagen_linux_fs_MSG34"
		echo "$imagen_linux_fs_MSG1"
		echo ""
		echo "1.- ext2"
		echo "2.- ext3"
		echo "3.- ext4"
		echo "4.- XFS"
		echo "5.- JFS"
		echo "6.- BTRFS"

		echo ""
		echo "$imagen_linux_fs_MSG2"
		read IMAGENDD_FS
	;;

	2)
		IMAGENDD_FS=$(zenity --width=400 --height=300 --title="LINUX-CDGRAB" --entry --text="
		$imagen_linux_fs_MSG34
		$imagen_linux_fs_MSG1
		1.- ext2
		2.- ext3
		3.- ext4
		4.- XFS
		5.- JFS
		6.- BTRFS
		$imagen_linux_fs_MSG2")
	;;

	3)
		IMAGENDD_FS=$(kdialog --menu "$imagen_linux_fs_MSG1" \
1 "1- ext2" \
2 "2- ext3" \
3 "3- ext4" \
4 "4- XFS" \
5 "5- JFS" \
6 "6- BTRFS" --geometry=210x240 --title "$PROGRAMA")

	;;
esac

	# Se parametriza el block size para dd,
	# el comando advierte que los discos formateados
	# no seran accesibles en todas las máquinas.
	# Los sistemas de ficheros transaccionales
	# precisan un tamaño de bloque de 4096
	# 
	# El tamaño de bloque usado para ext2
	# se mantiene en 2048 bytes.

	case $IMAGENDD_FS in

		1)
			imagendd=$D_TMP/lcdgrabimg.ext2
			tambloque=2048
			break
		;;
	
		2)
			imagendd=$D_TMP/lcdgrabimg.ext3
			tambloque=4096
			break
		;;

		3)
			imagendd=$D_TMP/lcdgrabimg.ext4
			tambloque=4096
			break
		;;

		4)	imagendd=$D_TMP/lcdgrabimg.xfs
			tambloque=4096
			break
		;;

		5)
			imagendd=$D_TMP/lcdgrabimg.jfs
			tambloque=4096
			break
		;;

		6)
			imagendd=$D_TMP/lcdgrabimg.btrfs
			tambloque=4096
			break
		;;

		*)
            		mui_Opcion_invalida
			continue
		;;

	esac
done
	
	v_count=""

	cabecera

	# ------------------------------
	# Tamaño de imagen para CD
	# Obtencion del tamaño de la imagen ext2.
	#
	# 05-11-2018
	# Se implementa el soporte para ext3, ext4.
	# Y_2022 Se añade XFS, JFS y BTRFS.
	# Mismo metodo de imagen usado, independientemente
	# del fichero.

	#
	# cdrecord dev=3,0 -v -atip
	#
	# Linea : ATIP start of lead out : 359849 (79:59/74)
	# Tamaño en Mbytes 359849 * 2048 = 702 Mbytes
	# 
	# Esto nos saca el valor del fichero vacío que se formateará en ext2, 
	# el tamaño del fichero vacío será el tamaño de un CD de datos virgen
	# de 702 Mbytes (80 Minutos)
	#
	# CD-R/CD-RW
	# ----------
	#
	# se corrige un error de grabación
	#
	# count = 359849 , capacidad de un CD de 702 Mbytes (80 minutos)
	# count = 359824 , nueva capacidad en la que linux-cdgrab crea la imagen,
	#                  cdrecord no deberia informar de errores al grabar estas imagenes.
	#
	############################################
	# Tamaño de imagen para DVD
	# Obtención del tamaño de la imagen ext2.
	#
	# dvd+rw-mediainfo
	#
	# Linea: READ CAPACITY: 2295104 * 2048 = 4700372992
	#
	# DVD+RW
	# ------
	#
	# count = 4194304 
	#
	# Tamaño en Mbytes 4096 ,tamaño en Gbytes 4.
	############################################
	# DVD+RW--> Se hace una conversión del tamaño
	#           dado por el comando dvd+rw-mediainfo.
	# 		
	#		count = 4194304 
	#
	# Tamaño en Mbytes 4096 ,tamaño en Gbytes 4.
	# dd hace imagenes de 8 Gbytes
	# count = 2097152 , se le da el nuevo valor a la mitad.
	# ------
	############################################
	# BD-R/RE --> Solución propuesta por ChatGPT
	# dd if=/dev/zero of=/tmp/archivo_vacio bs=2048 count=12207031
	# El valor de count indica la cantidad de bloquees que se escribirán
	# en el archivo en bytes (25 GB = 26.843.545.600 bytes) por el 
	# tamaño de bloque (2048)
	# Para un archivo de 25 GBytes con tamaño de bloque 4096 (4 KB) usar
	# dd if=/dev/zero of=/tmp/archivo_vacio bs=4096 count=6250000
	# Como cada bloque tiene una tamaño de 4 KB, 25 GBytes son equivalentes
	# a 6250000 bloques de 4 KB
	#

case $UD in
0)
	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA IMG CD/DVD/BD MENU" \
	--menu "IMG CD/DVD/BD" 14 55 13 \
	1 "$imagen_linux_fs_MSG3" \
	2 "$imagen_linux_fs_MSG4" \
	3 "$imagen_linux_fs_MSG5" \
	4 "$imagen_linux_fs_MSG5B" \
	5 "$imagen_linux_fs_MSG5C" 2>"${INPUT}"
	m_opcion="$(<${INPUT})"
;;

1)
	printf "1.- $imagen_linux_fs_MSG3\n"
	printf "2.- $imagen_linux_fs_MSG4\n"
	printf "3.- $imagen_linux_fs_MSG5\n"
	printf "4.- $imagen_linux_fs_MSG5B\n"
	printf "5.- $imagen_linux_fs_MSG5C\n"	
	printf "\n"

	read m_opcion
;;

2)
	m_opcion=$(zenity --width=500 --height=200 --title="LINUX-CDGRAB" --entry --text="
IMG CD/DVD/BD
1.- $imagen_linux_fs_MSG3
2.- $imagen_linux_fs_MSG4
3.- $imagen_linux_fs_MSG5
4.- $imagen_linux_fs_MSG5B
5.- $imagen_linux_fs_MSG5C")
;;

3)
	m_opcion=$(kdialog --menu "IMG CD/DVD/BD" \
1 "1- $imagen_linux_fs_MSG3" \
2 "2- $imagen_linux_fs_MSG4" \
3 "3- $imagen_linux_fs_MSG5" \
4 "4- $imagen_linux_fs_MSG5B" \
5 "5- $imagen_linux_fs_MSG5C" --geometry=510x216 --title "$PROGRAMA")
;;

esac
		case $m_opcion in

			1)
				# CD

				case $imagendd in
					$(echo $imagendd | grep -e 'ext2'))
						v_count=359824
						
					;;

					$(echo $imagendd | grep -e 'ext3'))
						v_count=179912
						
					;;

					$(echo $imagendd | grep -e 'ext4'))
						v_count=179912
						
					;;

					$(echo $imagendd | grep -e 'xfs'))
						v_count=179912
						
					;;

					$(echo $imagendd | grep -e 'jfs'))
						v_count=179912
						
					;;

					$(echo $imagendd | grep -e 'btrfs'))
						v_count=179912
						
					;;

				esac

				echo $imagen_linux_fs_MSG6
			
			;;

			2)

				# DVD

				case $imagendd in
					$(echo $imagendd | grep -e 'ext2'))
						v_count=2097152
						
					;;

					$(echo $imagendd | grep -e 'ext3'))
						v_count=1048576
						
					;;

					$(echo $imagendd | grep -e 'ext4'))
						v_count=1048576
						
					;;

					$(echo $imagendd | grep -e 'xfs'))
						v_count=1048576
						
					;;

					$(echo $imagendd | grep -e 'jfs'))
						v_count=1048576
						
					;;

					$(echo $imagendd | grep -e 'btrfs'))
						v_count=1048576
						
					;;

				esac

				echo $imagen_linux_fs_MSG7
			;;

			3)

				# DVD DL

				case $imagendd in
					$(echo $imagendd | grep -e 'ext2'))
						v_count=4194304
						
					;;

					$(echo $imagendd | grep -e 'ext3'))
						v_count=2097152
						
					;;

					$(echo $imagendd | grep -e 'ext4'))
						v_count=2097152
						
					;;

					$(echo $imagendd | grep -e 'xfs'))
						v_count=2097152
						
					;;

					$(echo $imagendd | grep -e 'jfs'))
						v_count=2097152
						
					;;

					$(echo $imagendd | grep -e 'btrfs'))
						v_count=2097152
						
					;;

				esac

				echo $imagen_linux_fs_MSG8
			;;

			4)

				# BD-R/RE

				case $imagendd in
					$(echo $imagendd | grep -e 'ext2'))
						#v_count=12207031 -> 25 Gbytes
						# -> 24,5 Gbytes
						v_count=12582912
					;;

					$(echo $imagendd | grep -e 'ext3'))
						v_count=6250000
						
					;;

					$(echo $imagendd | grep -e 'ext4'))
						v_count=6250000
						
					;;

					$(echo $imagendd | grep -e 'xfs'))
						v_count=6250000
						
					;;

					$(echo $imagendd | grep -e 'jfs'))
						v_count=6250000
						
					;;

					$(echo $imagendd | grep -e 'btrfs'))
						v_count=6250000
						
					;;

				esac

				echo $imagen_linux_fs_MSG8B
			;;

			5)

				# Calcula el count para un archivo de imagen con tamaño personalizado
				
				cabecera
				echo -e "${C_ET}$imagen_linux_fs_MSG35${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
				echo ""
				echo "$imagen_linux_fs_MSG36"
				echo -e "${C_AV}$imagen_linux_fs_MSG37${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
				read tambloque
				echo "$imagen_linux_fs_MSG38"
				read tamarch
				echo -e "${C_AV}$imagen_linux_fs_MSG39${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
				echo -e "${C_AV}# M -> MegaBytes # G -> GigaBytes # T -> Terabytes #${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
				echo -n "$imagen_linux_fs_MSG40"
				read medidatam

				# Se calcula en tamaño de bytes el valor especificado por el usuario

				case $medidatam in 
				'M')
					tambytes=$(expr $tamarch \* 1024 \* 1024)
				;;

				'G')
					tambytes=$(expr $tamarch \* 1024 \* 1024 \* 1024)
				;;

				'T')
					tambytes=$(expr $tamarch \* 1024 \* 1024 \* 1024 \* 1024)
				;;
				
				*)
					pinta_mensaje "${C_FA}" "$imagen_linux_fs_MSG41"
					tambytes=""
				;;
	
				esac
				
				if ! test -z $tambytes;then
					v_count=`expr $tambytes / $tambloque`
					echo -e "${C_AV}$imagen_linux_fs_MSG42 $tambloque ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
					echo -e "${C_AV}$imagen_linux_fs_MSG43 $tamarch$medidatam ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
					echo -e "${C_AV}$imagen_linux_fs_MSG44 $tambytes ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
					echo -e "${C_AV}$imagen_linux_fs_MSG45 $v_count ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
					teclash

					cabecera
					echo $imagen_linux_fs_MSG8C
					sleep 2
			
				else
					v_count=""
				fi

			;;

		esac

if test -z $v_count;then

    	pinta_mensaje ${C_FA} $imagen_linux_fs_MSG9

else

	lingrcmdexec $gdd "#"$DEVZero $ddop2$imagendd $ddblkszp$tambloque $ddop5$v_count "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then

		cabecera
		echo $imagen_linux_fs_MSG11
		echo $imagen_linux_fs_MSG12
		echo $imagen_linux_fs_MSG13
		echo ""

		# se formatea el archivo vacio

		case $IMAGENDD_FS in

			1)

				# Sistema de ficheros ext2

				imgfs="ext2"
				
				lingrcmdexec $lingrfrext2 "#"$mke2fsop1 $tambloque $imagendd "#" $imagen_linux_fs_MSG13 "#" $imagen_linux_fs_MSG15

			;;

			2)

				# Sistema de ficheros ext3

				imgfs="ext3"

				lingrcmdexec $lingrfext3 "#" $mkfsext3op1 $imagendd $mkfsext3op2 $tambloque $mkfsext3op3 "#" $imagen_linux_fs_MSG13 "#" $imagen_linux_fs_MSG15

			;;

			3)

				# Sistema de ficheros ext4

				imgfs="ext4"

				lingrcmdexec $lingrfrext2 "#"$mke2fsext4 $tambloque $imagendd "#" "NM" "#" "NM"

				if test $ejcodret -eq 0;then

					echo ""
					cabecera
					echo -e "${C_OK}$D_TMP/lcdgrabimg.ext4 $imagen_linux_fs_MSG13 ${COLOR_DEL_INTERFAZ}"
				else

                    			pinta_mensaje ${C_FA} $imagen_linux_fs_MSG15
				fi
			;;

			4)

				# Sistema de ficheros XFS

				imgfs="XFS"

				lingrcmdexec $lingrfxfs "#" -f $imagendd "#" "NM" "#" "NM"

				if test $ejcodret -eq 0;then

					echo ""
					cabecera
					echo -e "${C_OK}$imagendd $imagen_linux_fs_MSG13 ${COLOR_DEL_INTERFAZ}"
				else

                    			pinta_mensaje ${C_FA} $imagen_linux_fs_MSG15
				fi

			;;

			5)

				# Sistema de ficheros JFS

				imgfs="JFS"

				lingrcmdexec $lingrfjfs "#" $imagendd "#" "NM" "#" "NM"

				if test $ejcodret -eq 0;then

					echo ""
					cabecera
					echo -e "${C_OK}$imagendd $imagen_linux_fs_MSG13 ${COLOR_DEL_INTERFAZ}"
				else

                    			pinta_mensaje ${C_FA} $imagen_linux_fs_MSG15
				fi

			;;

			6)

				# Sistema de ficheros Btrfs

				imgfs="BTRFS"

				lingrcmdexec $lingrfbtrfs "#"$imagendd "#" "NM" "#" "NM"

				if test $ejcodret -eq 0;then

					echo ""
					cabecera
					echo -e "${C_OK}$imagendd $imagen_linux_fs_MSG13 ${COLOR_DEL_INTERFAZ}"
				else

                    			pinta_mensaje ${C_FA} $imagen_linux_fs_MSG15
				fi

			;;

		esac

		# monta el archivo en /mnt/lcdgrab

		cabecera
		echo $imagen_linux_fs_MSG14
		echo ""
		sleep 1

		if $lingrmimg1 $imagendd $D_MNT;then

			echo -e "${C_OK} $lingrmimg1 $imagendd $D_MNT --> OK ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			error=0

		elif $lingrmdisc1 $mfimgop1$imgfs $imagendd $D_MNT $mfimgop2;then

			clear
			cabecera
			echo -e "${C_OK} $lingrmdisc1 $mfimgop1$imgfs $imagendd $D_MNT $mfimgop2 --> OK ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			echo ""
			echo "$imagen_linux_fs_MSG11 $D_MNT"
			echo "$imagen_linux_fs_MSG17 $D_MNT"
			echo $imagen_linux_fs_MSG18
			echo "$imagen_linux_fs_MSG19 : $imagen"
			error=0
		else
			echo -e "${C_FA} $imagen_linux_fs_MSG19B ${COLOR_DEL_INTERFAZ}"
			error=1
		fi


		teclash


		if expr $error = 0;then

			MSG=$imagen_linux_fs_MSG20
			echo $imagen_linux_fs_MSG21
			gestor_de_archivos $MSG
			
			cabecera
			echo -e "${C_AV}"
			echo $imagen_linux_fs_MSG22
			echo $imagen_linux_fs_MSG23
			echo ""
			echo "$imagen_linux_fs_MSG24 $imagendd $imagen_linux_fs_MSG25"
			echo -e "${COLOR_DEL_INTERFAZ}"
			sleep 3

		fi
	else
		echo ""
		echo -e "${C_FA} $imagen_linux_fs_MSG26 ${COLOR_DEL_INTERFAZ}"
		echo ""
		echo $imagen_linux_fs_MSG27
		echo ""
		df -h
		teclash
	fi
fi

}

# imagen_LeerCodigoHash
#
# Función sin parametrización de mensajes
# en el fichero .idiom
# Lee el código Hash de un archivo en disco.
# Formatos aceptados:
# md5, blake2, sha1, sha224, sha256, sha384 y sha512

imagen_LeerCodigoHash(){

TITUL="LINUX-CDGRAB 1.0 HASH CODE FILE"

	obten_cadena "HASH CODE" "Iso IMG:"
	archivoiso=$lacadena

	if test -f $archivoiso;then
	
		cabecera
		echo -e "${C_AV}"
		echo "Reading hash values for $archivoiso"
		echo "Wait process ..."
		echo ""
		echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"


		case $UD in
			0)
			dialog --clear --colors --backtitle "\Z6-++ $PROGRAMA ++-" --title "$TITUL" --msgbox "
			MD5
			$($lingrmd5 $archivoiso)
			BLAKE2
			$($lingrb2 $archivoiso)
			SHA1
			$($lingrsha1 $archivoiso)
			SHA224
			$($lingrsha224 $archivoiso)
			SHA256
			$($lingrsha256 $archivoiso)
			SHA384
			$($lingrsha384 $archivoiso)
			SHA512
			$($lingrsha512 $archivoiso)" 20 210
			;;

			1)

			echo ""
			echo -e "${C_ET}MD5${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrmd5 $archivoiso
			echo -e "${C_ET}BLAKE2${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrb2 $archivoiso
			echo -e "${C_ET}SHA1${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrsha1 $archivoiso
			echo -e "${C_ET}SHA224${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrsha224 $archivoiso
			echo -e "${C_ET}SHA256${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrsha256 $archivoiso
			echo -e "${C_ET}SHA384${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrsha384 $archivoiso
			echo -e "${C_ET}SHA512${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			$lingrsha512 $archivoiso

			echo ""
			teclash
			;;

			2)
			zenity --title="$PROGRAMA" --info --text="
${TITUL}
MD5
$($lingrmd5 $archivoiso)
BLAKE2
$($lingrb2 $archivoiso)
SHA1
$($lingrsha1 $archivoiso)
SHA224
$($lingrsha224 $archivoiso)
SHA256
$($lingrsha256 $archivoiso)
SHA384
$($lingrsha384 $archivoiso)
SHA512
$($lingrsha512 $archivoiso)" --width=600 --height=200
			;;

			3)

			kdialog --msgbox "${TITUL}
MD5
$($lingrmd5 $archivoiso)
BLAKE2
$($lingrb2 $archivoiso)
SHA1
$($lingrsha1 $archivoiso)
SHA224
$($lingrsha224 $archivoiso)
SHA256
$($lingrsha256 $archivoiso)
SHA384
$($lingrsha384 $archivoiso)
SHA512
$($lingrsha512 $archivoiso)
" --title="$PROGRAMA" --geometry=500x500

			;;

		esac
	else
		pinta_mensaje ${C_FA} "ERR: NO $archivoiso"
	fi


}

# extraer_isoCD_dd
# genera una imagen ISO-9660 del CD mediante el comando dd

extraer_isoCD_dd(){

# Imagen .iso a generar.

imagen=$D_TMP/lcdgrabimg.iso
compmsgimgOK="$extraer_isoCD_dd_MSG2 $D_TMP"
compmsgomgERR="$extraer_isoCD_dd_MSG3 $imagen"

# Crea la imagen .iso desde el dispositivo almacenado en la variable $LECTOR_CDROM

cabecera
echo $extraer_isoCD_dd_MSG1

sleep 1

lingrcmdexec $gdd "#"$ddop1${LECTOR_CDROM} $ddop2${imagen} $gcdisodd1 "#" "NM" "#" "NM"
sync

if test -f ${imagen} &> /dev/null;then

    	pinta_mensaje ${C_OK} $compmsgimgOK
else 

	pinta_mensaje ${C_FA} $compmsgomgERR
fi

}

# extraer_isoDVD_dd
# genera una imagen ISO-9660 del CD mediante el comando dd

extraer_isoDVD_dd(){

imagen=$D_TMP/lcdgrabdvdimg.iso
compmsgimgOK="$extraer_isoDVD_dd_MSG3 $imagen"
compmsgomgERR="$extraer_isoDVD_dd_MSG4 $imagen"
tes=0

cabecera
echo $extraer_isoDVD_dd_MSG1
sleep 2

# crea la imagen del DVD

lingrcmdexec $gdd "#"$ddop1${LECTOR_CDROM} $ddop2${imagen} $gdvdisodd1 "#" $compmsgimgOK "#" $compmsgomgERR

if test $ejcodret -eq 0;then
	sync
fi

}

# extraer_iso_mkisofs
# genera una imagen ISO-9660 del CD mediante el comando mkisofs

extraer_iso_mkisofs(){

		if $lingrmdisc1 $LECTOR_CDROM $MNT/cdrom || mount $LECTOR_CDROM $D_MNT;then

		    echo -e "${C_OK} $extraer_iso_mkisofs_MSG1 ${COLOR_DEL_INTERFAZ}"
		    echo $extraer_iso_mkisofs_MSG2
		    echo $extraer_iso_mkisofs_MSG3
		    	
		    echo "$extraer_iso_mkisofs_MSG4:$($lingrmkimg2 $mkisofsver)"

		    echo "$extraer_iso_mkisofs_MSG5:$lingrmkimg2 \"ISODISK\" mkisofscddatap2 \"NUEVO\" $genisoimagefscddatap1 $imagen $mkisofscddatap4 $NIVEL_ISO `cut -d ' ' -f 2 /etc/mtab | grep -e "$MNT/cdrom" | grep -v "$MNT/cdrom." ` || `cut -d ' ' -f 2 /etc/mtab |grep -e "$D_MNT"`"
				
		    if $lingrmkimg2 "ISODISK" mkisofscddatap2 "ISODISK" $genisoimagefscddatap1 $imagen $mkisofscddatap4 $NIVEL_ISO `cut -d ' ' -f 2 /etc/mtab | grep -e "$MNT/cdrom" | grep -v "$MNT/cdrom." ` || `cut -d ' ' -f 2 /etc/mtab |grep -e "$D_MNT"`;then
				
			sync
			echo ""
			echo -e "${C_OK} $extraer_iso_mkisofs_MSG6 $D_TMP ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"

		    else

                    	mui_img_error
			cabecera
			echo ""
			echo $extraer_iso_mkisofs_MSG7

			rm -f $imagen

			echo "$extraer_iso_mkisofs_MSG5:$lingrmkimg2 $mkisofscddat1 "NUEVO" $genisoimagefscddatap2 $imagem $mkisofscddat3 $NIVEL_ISO `cut -d ' ' -f 2 /etc/mtab | grep -e "$MNT/cdrom" | grep -v "$MNT/cdrom." ` || `cut -d ' ' -f 2 /etc/mtab |grep -e "$D_MNT"`"

			if $lingrmkimg2 $mkisofscddat1 "ISODISK" $genisoimagefscddatap2 $imagem $mkisofscddat3 $NIVEL_ISO `cut -d ' ' -f 2 /etc/mtab | grep -e "$MNT/cdrom" | grep -v "$MNT/cdrom." ` || `cut -d ' ' -f 2 /etc/mtab |grep -e "$D_MNT"`;then
				sync
				echo -e "${C_OK} $extraer_iso_mkisofs_MSG16 $D_TMP ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
			else
                        	mui_img_error
				cabecera
				echo "$extraer_iso_mkisofs_MSG13 $imagen $extraer_iso_mkisofs_MSG13B $CDROM"
				echo "$extraer_iso_mkisofs_MSG11 $imagen"
				echo "$extraer_iso_mkisofs_MSG12 $imagen $extraer_iso_mkisofs_MSG12B $D_MNT"
				sleep 3

				umount $D_MNT &> /dev/null
				mount -o loop $imagen $D_MNT ; ls -l $D_MNT
						
			fi
		     fi
			
		else
			echo "$extraer_iso_mkisofs_MSG15 $LECTOR_CDROM"
			teclash
		fi ## cierra la condicion del mandato mount

}

# m_comp_img
#
# Interfaz de submenú para comprimir una imagen iso
# Llamada a la funcion: m_comp_img $imagenacomprimir

m_comp_img(){

	IMAGENISO=$*
	cabecera
	echo "$m_comp_img_MSG1: $IMAGENISO"
	echo ""
	echo $m_comp_img_MSG2
	echo ""
	echo $m_comp_img_MSG3
	read comp

	case $comp in
		"SI" | "si" | "Si" | "sI" | "s" | "S" | "Y" | "y" | "yes" | "YES" | "Yes" | "YEs" | "yEs" | "YeS" | "yeS" | "yES" )
				
			comprime $IMAGENISO
			cabecera
			echo -e "${C_ET}DIR: $D_TMP${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			ls -l $D_TMP
			teclash
		;;
	esac

}

# generar_iso_directorio , usa genisoimage
#
# Genera una imagen ISO-9660 desde
# diferentes rutas de directorios
# especificadas por el usuario.
# 
# Genera una imagen iso-9660
# con metadatos RockRidge, Joliet y opcionalmente HFS.

generar_iso_directorio(){

	# Imagen de un directorio
	imagen="$D_TMP/lcdgrabimg.iso"

	msgisocompuestomkisofs="$generar_iso_directorio_MSG7 $D_TMP"

	echo $generar_iso_directorio_MSG1
	sleep 1
	gestor_de_archivos $MSG

        mui_rutas_dir

	obten_cadena " " "$generar_iso_directorio_MSG2"
	etiqueta=$lacadena
	
	if test $metadatosisoapple -eq 1;then
	
		echo $generar_iso_directorio_MSG3
		echo $generar_iso_directorio_MSG4
		echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

		export MKISOFS="$lingrmkimg2"

		echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt"
		sleep 1

		if $lingrmkimg2 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt;then

			pinta_mensaje ${C_OK} $msgisocompuestomkisofs

		else

            		mui_img_error

			cabecera
			echo $generar_iso_directorio_MSG8
			echo $generar_iso_directorio_MSG9
			echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

			export MKISOFS="$lingrmkimg2"

			echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt"
			sleep 1
			if $lingrmkimg2 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt;then

				pinta_mensaje ${C_OK} $msgisocompuestomkisofs

			else
				mui_img_error
			fi
		fi

	else
		
			cabecera
			echo $generar_iso_directorio_MSG3
			echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

			export MKISOFS="$lingrmkimg2"

			echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt"

			if $lingrmkimg2 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt;then

				pinta_mensaje ${C_OK} $msgisocompuestomkisofs

			else
				mui_img_error
			fi

	fi

}

# generar_udf_iso_directorio
#
# genera una imagen híbrida UDF e iso-9660
# desde datos del disco duro.
# clonada de generar_iso_directorio
# Usa las mismas variables de idioma

generar_udf_iso_directorio(){

	# Imagen de un directorio

	imagen="$D_TMP/lcdgrabimg.udf"

	msgisocompuestomkisofs="$generar_iso_directorio_MSG7 $D_TMP"

	echo $generar_iso_directorio_MSG1
	sleep 1
	gestor_de_archivos $MSG
	clear	

        mui_rutas_dir

	obten_cadena " " "$generar_iso_directorio_MSG2"
	etiqueta=$lacadena
	
	if test $metadatosisoapple -eq 1;then
	
		echo $generar_iso_directorio_MSG3
		echo $generar_iso_directorio_MSG4
		echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

		export MKISOFS="$lingrmkimg2"

		echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofsudfop1 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt"
		sleep 1

		if $lingrmkimg2 $mkisofsudfop1 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt;then

			pinta_mensaje ${C_OK} $msgisocompuestomkisofs

		else

            		mui_img_error

			cabecera
			echo $generar_iso_directorio_MSG8
			echo $generar_iso_directorio_MSG9
			echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

			export MKISOFS="$lingrmkimg2"

			echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofsudfop1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt"
			sleep 1

			if $lingrmkimg2 $mkisofsudfop1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt;then

				pinta_mensaje ${C_OK} $msgisocompuestomkisofs

			else
				mui_img_error
			fi
		fi

	else
		
#			cabecera
			echo $generar_iso_directorio_MSG3
			echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

			export MKISOFS="$lingrmkimg2"

			echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofsudfop1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt"
			
			if $lingrmkimg2 $mkisofsudfop1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt;then

				pinta_mensaje ${C_OK} $msgisocompuestomkisofs

			else
				mui_img_error
			fi

	fi

}

# generar_bdv_udf_directorio
#
# genera una imagen UDF/iso con soporte
# para el formato de video en DVD
#
# Para el DVD Video deben existir previamente los
# directorios VIDEO_TS y AUDIO_TS.
#
# No es funcional si se pretende crear una imagen
# UDF/iso de Blu Ray Video (BDAV o BDMV).
# Utilizar solamente para DVD.

generar_bdv_udf_directorio(){

	# Imagen de un directorio

	imagen="$D_TMP/lcdgrabimgbdv.udf"

	msgisocompuestomkisofs="$generar_iso_directorio_MSG7 $D_TMP"

	echo $generar_iso_directorio_MSG1
	sleep 1
	gestor_de_archivos $MSG

	obten_cadena " " "$generar_bdv_udf_directorio_MSG1"
	etiqueta=$lacadena

	obten_cadena " " "$generar_bdv_udf_directorio_MSG2"
	rutavideo=$lacadena
	
	if test $metadatosisoapple -eq 1;then
	
		echo $generar_iso_directorio_MSG3
		echo $generar_iso_directorio_MSG4
		echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

		export MKISOFS="$lingrmkimg2"
		echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofsbdv $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 4 $rutavideo"

		sleep 1

		if $lingrmkimg2 $mkisofsbdv $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 4 $rutavideo;then

			pinta_mensaje ${C_OK} $msgisocompuestomkisofs

		else

            		mui_img_error

			cabecera
			echo $generar_iso_directorio_MSG8
			echo $generar_iso_directorio_MSG9
			echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

			export MKISOFS="$lingrmkimg2"

			echo "$lingrmkimg2 $mkisofsudfop1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 4 $rutavideo"
			sleep 1

			if $lingrmkimg2 $mkisofsudfop1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 4 $rutavideo;then

				pinta_mensaje ${C_OK} $msgisocompuestomkisofs

			else
				mui_img_error
			fi
		fi

	else
		
			cabecera
			echo $generar_iso_directorio_MSG3
			echo "$generar_iso_directorio_MSG5:$($lingrmkimg2 $mkisofsver)"

			export MKISOFS="$lingrmkimg2"

			echo "$generar_iso_directorio_MSG6:$lingrmkimg2 $mkisofsbdv $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO 4 $rutavideo"

			if $lingrmkimg2 $mkisofsbdv $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO 4 $rutavideo;then

				pinta_mensaje ${C_OK} $msgisocompuestomkisofs

			else
				mui_img_error
			fi

	fi

}

# generar_iso_directorio_libburnia , usa xorriso
#
# Genera una imagen iso9660 desde ficheros y directorios
# del disco duro. Utiliza xorriso de libburnia.

generar_iso_directorio_libburnia(){

imagen="$D_TMP/lcdgrabimglb.iso"

if test -f $imagen;then
	rm -rf $imagen &> /dev/null
fi

obten_cadena " " "$generar_iso_directorio_libburnia_MSG1"
etiquetaiso=$lacadena
obten_cadena " " "$generar_iso_directorio_libburnia_MSG2"
directorioiso=$lacadena

lingrcmdexec $lingrmkimg3 "#"$xorrisocddat1 $imagen $xorrisocddat2 $etiquetaiso $xorrisocddat3 $directorioiso "#" $generar_iso_directorio_libburnia_MSG3 "#" $generar_iso_directorio_libburnia_MSG4

}

# imagenISO
# Crea una imagen ISO - 9660, con extensiones (metadatos) RockRidge, HFS y Joliet.
# Crea también imagenes iso con estructuras udf para soporte de ficheros grandes.

imagenISO(){

	ruta="$HOME/rutas_lcdgrab.txt"
	imagen=$D_TMP/lcdgrabimg.iso
	INPUT=${D_TMP}/menu.sh.$$
	MSG=$imagenISO_MSG1
	
	export MKISOFS="genisoimage"
	
	export imagenISO_MSG6="$(echo $imagenISO_MSG6 | sed 's/mkisofs/genisoimage/g')"
	export imagenISO_MSG7="$(echo $imagenISO_MSG7 | sed 's/mkisofs/genisoimage/g')"
	export imagenISO_MSG14="$(echo $imagenISO_MSG14 | sed 's/mkisofs/genisoimage/g')"
	export imagenISO_MSG15="$(echo $imagenISO_MSG15 | sed 's/mkisofs/genisoimage/g')"

clear

while $verdadero;do

case $UD in
0)
dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
--title "$PROGRAMA ISO-9660 MENU" \
--menu "$imagenISO_MSG13" 17 97 20 \
1 "$imagenISO_MSG3" \
2 "$imagenISO_MSG4" \
3 "$imagenISO_MSG6" \
4 "$imagenISO_MSG7" \
5 "$imagenISO_MSG10" \
6 "$imagenISO_MSG14" \
7 "$imagenISO_MSG15" \
0 "$imagenISO_MSG8" 2>"${INPUT}"
eleccion=$(<"${INPUT}")
;;

1)
cabecera

printf "\t$imagenISO_MSG13\n"
printf "$imagenISO_MSG13B\n"
echo ""
echo "1.- $imagenISO_MSG3"
echo "2.- $imagenISO_MSG4"
echo "3.- $imagenISO_MSG6"
echo "4.- $imagenISO_MSG7"
echo "5.- $imagenISO_MSG10"
echo "6.- $imagenISO_MSG14"
echo "7.- $imagenISO_MSG15"
echo ""
echo "0.- $imagenISO_MSG8"

read eleccion
;;

2)
eleccion=$(zenity --width=400 --height=300 --title="$PROGRAMA" --entry --text="
$imagenISO_MSG13
1.- $imagenISO_MSG3
2.- $imagenISO_MSG4
3.- $imagenISO_MSG6
4.- $imagenISO_MSG7
5.- $imagenISO_MSG10
6.- $imagenISO_MSG14
7.- $imagenISO_MSG15
0.- $imagenISO_MSG8")
;;

3)
eleccion=$(kdialog --menu "$imagenISO_MSG13" \
1 "1- $imagenISO_MSG3" \
2 "2- $imagenISO_MSG4" \
3 "3- $imagenISO_MSG6" \
4 "4- $imagenISO_MSG7" \
5 "5- $imagenISO_MSG10" \
6 "6- $imagenISO_MSG14" \
7 "7- $imagenISO_MSG15" \
0 "0- $imagenISO_MSG8" --geometry=820x350 --title "$PROGRAMA")
;;

esac

case $eleccion in

######################### Imagen desde un CD usando dd

	1)		

		cabecera
		echo $imagenISO_MSG9
		extraer_isoCD_dd
		
	;;

######################### Imagen desde un DVD usando dd

	2)		

		cabecera
		echo $imagenISO_MSG9
		extraer_isoDVD_dd
		
	;;

######################### Imagen desde CD/DVD mediante mkisofs

	3)
		extraer_iso_mkisofs
	;;

######################### Imagen desde directorios mkisofs

	4)
		generar_iso_directorio

		if test -f $D_TMP/lcdgrabimg.iso;then
			m_comp_img "$D_TMP/lcdgrabimg.iso"
		fi
	;;

######################### Imagen desde un directorio xorriso

	5)
		generar_iso_directorio_libburnia

		if test -f $D_TMP/lcdgrabimglb.iso;then
			m_comp_img "$D_TMP/lcdgrabimglb.iso"
		fi

	;;

######################### Imagen híbrida udf/iso desde directorios mkisofs
	6)
		generar_udf_iso_directorio

		if test -f $D_TMP/lcdgrabimg.udf;then
			m_comp_img "$D_TMP/lcdgrabimg.udf"
		fi
	;;

######################### Imagen híbrida udf/iso con soporte para DVD

	7)
		generar_bdv_udf_directorio
	;;

	0)
		break
	;;

	*)
        	mui_Opcion_invalida
	;;


esac

[ -f $INPUT ] && rm $INPUT &> /dev/null

done

colores_interfaz

}

# imagen_img
# crea una imagen .img con dd

imagen_img(){

imagen_img=${D_TMP}/lcdgrabimg.img

cabecera
echo $imagen_img_MSG1
echo $imagen_img_MSG2
echo $imagen_img_MSG3
more /etc/fstab | grep -v 'cgroup' | grep -v 'tmpfs' | grep -v 'C:\'
more /etc/mtab | grep -v 'cgroup' | grep -v 'tmpfs' | grep -v 'C:\'
echo $imagen_img_MSG4
echo ""
mount | grep -v 'cgroup' | grep -v 'tmpfs' | grep -v 'C:\'
echo $imagen_img_MSG2
echo -n $imagen_img_MSG5
read dispositivo_origen

if test -b $dispositivo_origen;then
	
	cabecera
	echo "$imagen_img_MSG6: $dispositivo_origen"
	echo "$imagen_img_MSG7: $gimgbd $ddop1${dispositivo_origen} $ddop2${imagen_img} $ddop3"
	$gimgbd $ddop1${dispositivo_origen} $ddop2${imagen_img} $ddop3
	sync
	msg8comp="$imagen_img_MSG8 $imagen_img"
	pinta_mensaje ${C_OK} $msg8comp
else
    	mui_img_error
fi

}

# monta_img
# monta y desmonta imagenes de CD en /mnt/lcdgrab

monta_img(){
		MSG=$monta_img_MSG1
		gestor_de_archivos $MSG
		cabecera
		echo ""
		echo $monta_img_MSG2

		read ruta

		if ls $ruta | grep -e ".ext2" && expr $? = 0;then
			# Se trata de una imagen .ext2
			imgfs="ext2"
		else
			# Se trata de una imagen .iso
			imgfs="iso9660"
		fi

		if $lingrmimg1 $mfimgop3 $imgfs $ruta $D_MNT;then

			clear

			pinta_mensaje ${C_OK} $monta_img_MSG3

			ls -l $D_MNT
			teclash
		else

			pinta_mensaje ${C_FA} $monta_img_MSG4

			if ! test -f $ruta;then

                		msgcomp="$monta_img_MSG5 $ruta"
                		pinta_mensaje ${COLOR_DEL_INTERFAZ} $msgcomp

			elif ! test -d $D_MNT;then


                		pinta_mensaje ${COLOR_DEL_INTERFAZ} $monta_img_MSG6 $D_MNT
			else

                		pinta_mensaje ${COLOR_DEL_INTERFAZ} $monta_img_MSG7
                
			fi

		fi

}

# desmonta_img
# desmonta una imagen .iso, .ext2 o .img

desmonta_img(){

MSG=$desmonta_img_MSG1

if $lingrumount1 $D_MNT;then
	
    	pinta_mensaje ${C_OK} $desmonta_img_MSG2

else

	cabecera

	echo ""
	echo -e "${C_FA} $desmonta_img_MSG3 $D_MNT ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	echo ""
	echo $desmonta_img_MSG4
	echo "--------------------------------"
	mount | grep -v 'cgroup' | grep -v 'tmpfs' | grep -v 'C:\'
	echo ""
	echo $desmonta_img_MSG5
	echo $desmonta_img_MSG6
	echo $desmonta_img_MSG7
	teclash

		cabecera
		echo $desmonta_img_MSG8
		sleep 1
		gestor_de_archivos $MSG
		cabecera
		echo $desmonta_img_MSG9
		read ruta
		

		if $lingrumount1 $ruta;then

            		pinta_mensaje ${COLOR_DEL_INTERFAZ} $desmonta_img_MSG10
		else

            		pinta_mensaje ${COLOR_DEL_INTERFAZ} $desmonta_img_MSG11
		fi

fi

}

# nrg_a_iso
# Convierte imagenes de Nero Burning ROM en imagenes ISO-9660

# Adaptado de nrg70iso autor rodrigo nannig m. --> www.lawebdelprogramador.com
# No informar al autor de errores en el presente código

nrg_a_iso(){

imgciso=/tmp/lcdgrabnrgaiso.iso
MSG=$nrg_a_iso_MSG1

# comentarios del autor

# _NRG_HEADER es el tamaño de la cabecera del
# archivo nrg en bytes
# 
# NOTA: en realidad un archivo nrg no es mas
# que un archivo iso, a la cual se le agrega
# una cabecera de 300kb

_NRG_HEADER=300

gestor_de_archivos $MSG
cabecera
echo $nrg_a_iso_MSG2
read imgnrg
echo $nrg_a_iso_MSG3

# comentarios del autor

# bs      bloques a leer y escribir en bytes (tambien bs=1k)
# skip    cuantos bloques nos vamos a saltar en bs bytes,
#         skip * bs = 300 * 1024
# if      fichero de entrada (el archivo nrg en nuestro caso)
# of      fichero de salida (el archivo iso a crear)

#
#############################################################################
#
# Información de archivos .nrg que son en realidad imágenes ISO-9660
# Comentarios del programa nrg2iso 0.1 y porción de código.
# Autor: Grégory Kokanosky <gregory.kokanosky@free.fr>
# Escrito en lenguaje C.
#
#if( fread( buf, 1,17*2048 ,f) == 17*2048 ) {

#    // taken from k3b
#    // check if this is an iso9660-image
#    // the beginning of the 16th sector needs to have the following format:
    
#    // first byte: 1
#    // second to 11th byte: 67, 68, 48, 48, 49, 1 (CD001)
#    // 12th byte: 0
    
#    iso = ( buf[16*2048] == 1 &&
#	    buf[16*2048+1] == 67 &&
#	    buf[16*2048+2] == 68 &&
#	    buf[16*2048+3] == 48 &&
#	    buf[16*2048+4] == 48 &&
#	    buf[16*2048+5] == 49 &&
#	    buf[16*2048+6] == 1 &&
#	    buf[16*2048+7] == 0 );
#  }
#  if(iso){
#    printf("It seems that %s is already an ISO 9660 image \n",filename);
#    printf("[Aborting conversion]\n");
#  }
# 
#

#
# Comentarios y poción de código de nrg70iso, sobre el mismo tema.
#
# algunos archivos nrg son iso en realidad, por lo
# cual solo basta con renombrarlos, esta función
# sirve para revisar el archivo nrg comprobando 
# que no sea un iso
#
# SINOPSIS: ckis filename
#
#ckiso()
#{
#  _err=0
#  dd bs=1024 skip=32 if="$1" of="$_ISO_TMP" count=1 2>"$_DD_TMP"

#  [ `cat "$_DD_TMP"|wc -l|cut -f1 -d' '` -ne 3 ] && 
#    _err=`expr $_err + 1`
#  [ $_err -eq 0 -a "`cut -b2-6 $_ISO_TMP`" != "CD001" ] && 
#    _err=`expr $_err + 1`

#  rm -f "$_DD_TMP" "$_ISO_TMP"
  
#  return $_err
#}
#
###############################################################################

if test -z $imgnrg && test -d $imgnrg;then # comprobación para prevenir cuelgues del sistema.

	echo -e "${C_OK} $nrg_a_iso_MSG4 : $imgnrg $nrg_a_iso_MSG5 {$COLOR_DEL_INTERFAZ}"
	echo -e $nrg_a_iso_MSG6

else

    # Chequea si se trata de un archivo ISO-9660
    
    $ddnrgcd100 $ddop1$imgnrg $ddop2 $D_TMP/neroisotemporal $ddnrgcd100op1
    if test "$(cut -b2-6 $D_TMP/neroisotemporal)" = "CD001";then
    
    	# Se trata de un archivo iso.Se hace una nueva copia de él renombrado
    
    	nuevaiso=`basename "$imgnrg" .nrg`.iso
    	
    	echo -e "${C_AV} $imgnrg $nrg_a_iso_MSG7 ${COLOR_DEL_INTERFAZ}"
    	echo $nrg_a_iso_MSG8
   
    	cp -f $imgnrg $nuevaiso
    	echo -e "${C_OK} $nrg_a_iso_MSG9 ${COLOR_DEL_INTERFAZ}"
    	 	
    else
    	
    	# El archivo especificado si se trata de una imagen .nrg
    	# Se convierte a .iso
    	
		echo "$nrg_a_iso_MSG10:$ddnrg2iso$_NRG_HEADER $ddop1$imgnrg $ddop2$imgciso $ddbgr2isoop1"

		if $ddnrg2iso$_NRG_HEADER $ddop1$imgnrg $ddop2$imgciso $ddbgr2isoop1;then
			sync
			echo -e "${C_OK} $nrg_a_iso_MSG11 ${COLOR_DEL_INTERFAZ}"
		else
			echo -e "${C_FA} $nrg_a_iso_MSG12 ${COLOR_DEL_INTERFAZ}"
		fi	
	fi
	
	rm -f $D_TMP/neroisotemporal
fi

teclash

}

# GenerarArchivocue

# Genera un archivo .cue
# para una imagen de datos .bin
# que no acompañe de éste

GenerarArchivocue(){

MSG=$GenerarArchivocue_MSG1
gestor_de_archivos $MSG

cabecera
echo ""
echo "$GenerarArchivocue_MSG2 $(pwd)"
echo ""
echo $GenerarArchivocue_MSG3
echo $GenerarArchivocue_MSG4
read imgbinpath
echo $GenerarArchivocue_MSG5
echo $GenerarArchivocue_MSG6
echo ""
read imagenbin
CUEF1="FILE \"$imagenbin\" BINARY"
CUEF2="  TRACK 01 MODE1/2352"
CUEF3="     INDEX 01 00:00:00"

nuevocue=`basename "$imagenbin" .bin`.cue

echo $CUEF1 > $imgbinpath/$nuevocue
echo $CUEF2 >> $imgbinpath/$nuevocue
echo $CUEF3 >> $imgbinpath/$nuevocue

if test -f $imgbinpath/$nuevocue;then

    pinta_mensaje ${C_OK} $GenerarArchivocue_MSG7
else

    pinta_mensaje ${C_FA} $GenerarArchivocue_MSG8
fi

}

# ImagenbincueCDDVD
# Crea una Imagen *.bin *.cue desde la grabadora de CD-DVD

# Contenido de ejemplo para un fichero cue (Datos)

# FILE "Imagenbincue.bin" BINARY
#  TRACK 01 MODE1/2352
#     INDEX 01 00:00:00

ImagenbincueCDDVD(){

# Contenido para la hoja cue de linux-cdgrab

CUEF1="FILE \"lcdgrabimgbincue.bin\" BINARY"
CUEF2="  TRACK 01 MODE1/2352"
CUEF3="     INDEX 01 00:00:00"

# Los archivos generados seran lcdgrabimgbincue.bin y lcdgrabimgbincue.cue

cabecera

umount $IDE

lingrcmdexec $lingrcdburn2 "#"$cdrdaogimgbincue1 $HOME/lcdgrabimgbincue.bin $cdrdaogimgbincue2 $IDE $HOME/lcdgrabimgbincue.cue "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then

	# reescribe la hoja cue por estandarización
	# a la hora de ser grabado.
	# se escribe una hoja cue para un cd de datos.

	echo $CUEF1 > $HOME/lcdgrabimgbincue.cue
	echo $CUEF2 >> $HOME/lcdgrabimgbincue.cue
	echo $CUEF3 >> $HOME/lcdgrabimgbincue.cue

    	pinta_mensaje ${C_OK} $ImagenbincueCDDVD_MSG2
else

    	mui_img_error
fi

expulsar_medio $IDE

}

