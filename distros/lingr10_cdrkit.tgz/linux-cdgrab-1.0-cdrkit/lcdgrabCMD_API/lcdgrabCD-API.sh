#########################################################
# lcgdrabCMD_API/lcdgrabCD-API.sh
# Colección de funciones para grabaciones en CD.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

################## GRABACIÓN EN CD ######################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabCD-API.idiom

# copia_bin
# copia un CD de datos creando una imagen binaria con dd.

copia_bin(){

#Si tes llega valiendo 1, borra la imagen generada con dd al final del proceso.
	
typeset local tes=0

DEV="dev=$IDE"
Vel="speed=$Velocidad"

extraer_isoCD_dd
	
###### graba la imagen generada anteriormente en un CD o DVD.

if test -f $D_TMP/lcdgrabimg.iso;then

	mui_una_sola_grabadora

	lingrcmdexec $lingrcdburn1 "#"$DEV $cdrecordwimgcdoverburn1 $Vel $cdrecordwimgcdoverburn2 $imagen "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then
		tes=1
	else

    		mui_CD_error

		cabecera
		echo $copia_bin_MSG2
		m_cdrecord-sin-overburn
		sleep 2
	
		lingrcmdexec $lingrcdburn1 "#"$DEV $cdrecordwimgcd1 $Vel$cdrecordwimgcd2 $imagen "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
			tes=1
		else
			mui_CD_error
		fi

	fi
	
	cabecera
	echo ""
	echo $copia_bin_MSG3
	rm -rf $imagen

	$lingreject $LECTOR_CDROM && $lingreject $IDE

	if test $tes -eq 1;then
	    mui_grabacion_ok
	else
	    pinta_mensaje ${C_FA} $copia_bin_MSG4
	fi

else
	cabecera
	pinta_mensaje ${C_FA} $copia_bin_MSG5
fi

}


# datos_al_vuelo
# copia un CD de datos al vuelo

datos_al_vuelo(){

typeset local MSGCOMP=""

DEV="dev=$IDE"
Vel="speed=$Velocidad"

cabecera
echo -e "${C_AV}$datos_al_vuelo_MSG5${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

BLKLEADOUT="$($lingrcdburn1 dev=$LECTOR_CDROM $cdrecordminf1 | grep -e 'leadout' | sed -e 's/[A-Z]//g' -e 's/[a-z]//g' -e 's/[ ]//g' -e 's/://g')s"

echo -e "${C_AV}BLKS LEADOUT $LECTOR_CDROM : $BLKLEADOUT ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
echo -e "${C_AV}$datos_al_vuelo_MSG6 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
sleep 2

# Comando de K3B 17.12.3
# /usr/bin/cdrecord -v gracetime=2 dev=/dev/sr2 speed=8 -sao driveropts=burnfree -overburn -data -tsize=1184230s -

lingrcmdexec $lingrcdburn1 "#"$cdrecordcdonflyoverburn1 $DEV $Vel $cdrecordcdonflyoverburn2$BLKLEADOUT $LECTOR_CDROM "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then

    	mui_grabacion_ok
else

    	MSGCOMP="$datos_al_vuelo_MSG3 $LECTOR_CDROM $datos_al_vuelo_MSG4"

    	mui_DO_error

	cabecera
	echo -e "${C_FA}"
	echo $datos_al_vuelo_MSG2
	echo -e "${COLOR_DEL_INTERFAZ}"
	echo "|----------------------------------------------------------------------|"
	
	m_cdrecord-sin-overburn
	sleep 2
    
	lingrcmdexec $lingrcdburn1 "#"$cdrecordcdonfly1 $DEV $Vel $cdrecordcdonfly2$BLKLEADOUT $LECTOR_CDROM "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then
		mui_grabacion_ok
	else

	        mui_DO_error
		cabecera
		echo ""
	        pinta_mensaje ${COLOR_DEL_INTERFAZ} $MSGCOMP

	fi

fi

expulsar_medio $LECTOR_CDROM
expulsar_medio $IDE

}

# datos_al_vuelo_cdrdao
# Graba un CD-R/RW de datos al vuelo
# Requiere cdrdao

datos_al_vuelo_cdrdao(){

lingrcmdexec $lingrcdburn2 "#"$cdrdaocdonfly1 $IDE $cdrdaocdonfly2 $LECTOR_CDROM $cdrdaocdonfly3 $Velocidad $cdrdaocdonfly4 "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
	mui_grabacion_ok
else
	mui_CD_error
fi

}

# audio_al_vuelo_cdrdao
# Graba un CD-Audio o CD-Mixto al vuelo
# Requiere cdrdao

audio_al_vuelo_cdrdao(){

lingrcmdexec $lingrcdburn2 "#"$cdrdaocdonfly1 $IDE $cdrdaocdonfly2 $LECTOR_CDROM $cdrdaocdonfly3 $Velocidad $cdrdaocdaonfly4 "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
	mui_grabacion_ok
else
	mui_CD_error
fi

}

# datos
# graba datos del disco duro a un CD/DVD/BD

datos(){
	ruta="$HOME/rutas_lcdgrab.txt"
	MSG=$datos_MSG1
	unid="dev=$IDE"
	vel="speed=$Velocidad"
	
############ crea la imagen

obten_cadena "$datos_MSG2" "$datos_MSG3"

etiqueta=$lacadena

if test $UD = 1;then
	cabecera
	echo $datos_MSG4
	sleep 1
	gestor_de_archivos $MSG
fi

mui_rutas_dir

cabecera
echo $datos_MSG5
sleep 1

lingrcmdexec $lingrmkimg2 "#" $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $mkisofscddatap3 $D_TMP/lcdgrabimg.iso $mkisofscddatap4 $NIVEL_ISO $mkisofscddatap5 $HOME/rutas_lcdgrab.txt "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
	sync
	echo ""
	echo -e "${C_OK}"
	echo "$datos_MSG7 : $D_TMP/lcdgrabimg.iso"
	echo ""
	echo $datos_MSG8
	echo -e "${COLOR_DEL_INTERFAZ}"
	sleep 2
	echo ""
else

	mui_img_error

	sleep 1
	echo ""
    	cabecera
	echo $datos_MSG9
	echo $datos_MSG10
	echo ""
	sleep 2
	echo $datos_MSG11
	rm -f $D_TMP/lcdgrabimg.iso

	echo $datos_MSG12

	lingrcmdexec $lingrmkimg2 "#" $mkisofscddat1 $etiqueta $mkisofscddat2 $D_TMP/lcdgrabimg.iso $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $HOME/rutas_lcdgrab.txt "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then
	    sync
	    echo ""
	    echo -e "	${C_OK}$datos_MSG7 : $D_TMP/lcdgrabimg.iso${COLOR_DEL_INTERFAZ}"
	    echo ""	

	else
	    mui_img_error

	fi

fi

################ graba el CD

if test -f $D_TMP/lcdgrabimg.iso;then

	colores_interfaz

	cabecera
	echo $datos_MSG16
	echo ""
	sleep 2

	lingrcmdexec $lingrcdburn1 "#" $unid $cdrecordwimgcdoverburn1 $vel $cdrecordwimgcdoverburn2 $D_TMP/lcdgrabimg.iso "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then

		mui_grabacion_ok
	else

		mui_DO_error

		cabecera

		echo ""
		echo "$datos_MSG13 $D_TMP/lcdgrabimg.iso"

		echo $datos_MSG14
		m_cdrecord-sin-overburn
		sleep 3

		lingrcmdexec $lingrcdburn1 "#" $unid $cdrecordwimgcd1 $vel $cdrecordwimgcd2 $D_TMP/lcdgrabimg.iso "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then

			mui_grabacion_ok
		else
	        	mui_DO_error
		fi

	fi

else
	cabecera
	echo "$D_TMP/lcdgrabimg.iso $datos_MSG17 $datos_MSG17"
	sleep 1
fi

echo $datos_MSG15
echo ""

rm -f $HOME/rutas_lcdgrab.txt &> /dev/null
rm -f $D_TMP/lcdgrabimg.iso &> /dev/null
rm -f $D_LINUXCDGRAB/lcdgrabnombreetiqueta.$$ &> /dev/null

}

# datoslb
# graba datos del disco duro a CD-R/CD-RW, (libburnia necesario cdrskin)

datoslb(){

cmdunit="dev=$IDE"
OPTCDRS="$cdrskiniso2od1 $cmdunit $cdrskiniso2od2 $D_TMP/lcdgrabimglb.iso"

generar_iso_directorio_libburnia
cabecera

if test -f $D_TMP/lcdgrabimglb.iso;then
	echo -e "${C_OK} Grabando imagen en CD-R/RW ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	lingrcmdexec $lingrcdburn3 "#" $OPTCDRS "#" $datoslb_MSG2 "#" $datoslb_MSG3
	rm -rf $D_TMP/lcdgrabimglb.iso &> /dev/null
else
	pinta_mensaje ${C_FA} $datoslb_MSG1
fi

expulsar_medio $IDE

}


# err_borra_cdrw
# Informa de error cuando se fuerza el borrado de un cdrw

err_borra_cdrw(){

	clear

	case $UD in

	0)
		MSGDed="$err_borra_cdrw_MSG1 $err_borra_cdrw_MSG2 $err_borra_cdrw_MSG3 $err_borra_cdrw_MSG4"
		dialog --title "ERROR CD-RW" --backtitle "$PROGRAMA" --msgbox "$MSGDed" 15 90
	;;

	1)
		cabecera
		echo -e "${C_FA}"
		echo $err_borra_cdrw_MSG1
		echo $err_borra_cdrw_MSG2
		echo $err_borra_cdrw_MSG3
		echo $err_borra_cdrw_MSG4
		echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		teclash
	;;

	2)
		zenity --width=600 --height=400 --error --text="
$err_borra_cdrw_MSG1
$err_borra_cdrw_MSG2
$err_borra_cdrw_MSG3
$err_borra_cdrw_MSG4"
	;;

	3)
		kdialog --title="$PROGRAMA" --error "$err_borra_cdrw_MSG1
$err_borra_cdrw_MSG2
$err_borra_cdrw_MSG3
$err_borra_cdrw_MSG4" --geometry=600x600
	;;

	esac

}

# borra
# borra un CD-RW

borra(){

unid="dev=$IDE"
vel="speed=$Velocidad"
export borra_MSG3="$(echo $borra_MSG3 | sed 's/cdrecord/wodim/g')"
export borra_MSG4="$(echo $borra_MSG4 | sed 's/cdrecord/wodim/g')"

clear

while $verdadero;do
	
	case $UD in
		0)
			dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
			--title "$PROGRAMA CD-RW BLANK MENU" \
			--menu "$borra_MSG1" 13 57 20 \
			1 "$borra_MSG3" \
			2 "$borra_MSG4" \
			3 "$borra_MSG5" \
			0 "$borra_MSG0" 2>"${INPUT}"
			mod=$(<"${INPUT}")
		;;

		1)

			cabecera
			echo $borra_MSG1
			echo $borra_MSG2
			echo ""
			echo "1.- $borra_MSG3"
			echo "2.- $borra_MSG4"
			echo "3.- $borra_MSG5"
			echo ""
			echo "0.- $borra_MSG0"
			read mod
		;;

		2)
			mod=$(zenity --width=125 --height=250 --title="$PROGRAMA" --entry --text="
$borra_MSG1
1.- $borra_MSG3
2.- $borra_MSG4
3.- $borra_MSG5
0.- $borra_MSG0")
		;;

		3)

			mod=$(kdialog --menu "$borra_MSG1" \
1 "1- $borra_MSG3" \
2 "2- $borra_MSG4" \
3 "3- $borra_MSG5" \
0 "0- $borra_MSG0" --title="$PROGRAMA" --geometry=430x210)

		;;

	esac

case $mod in
	1)
		# Borra un CD-RW en modo rapido (usa cdrecord)

		lingrcmdexec $lingrcdburn1 "#"$unid $cdrecordcdrweras1 $vel $cdrecordcdrweras2 "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
			pinta_mensaje ${C_OK} $borra_MSG8
		else
			# Fuerza el formato del CD-RW

			cabecera
			echo -e "${C_FA} $borra_MSG9 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			echo -e "${C_AV} $borra_MSG10 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

			sleep 2

			lingrcmdexec $lingrcdburn1 "#"$unid $cdrecordcdrwferas1 $vel $cdrecordcdrwferas2 "#" "NM" "#" "NM"

			if test $ejcodret -eq 0;then

				pinta_mensaje ${C_OK} $borra_MSG8
			else
				err_borra_cdrw
			fi
		fi

		expulsar_medio $IDE
	;;

	2)
		# Borra un CD-RW en modo completo (usa cdrecord)
		
		cabecera

		lingrcmdexec $lingrcdburn1 "#"$unid $cdrecordcdrwerascomp1 $vel $cdrecordcdrwerascomp2 "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
			pinta_mensaje ${C_OK} $borra_MSG8
		else
			# Fuerza el formato del CD-RW
			clear
			cabecera
			echo -e "${C_FA} $borra_MSG9 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			echo -e "${C_AV} $borra_MSG10 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

			sleep 2
			lingrcmdexec $lingrcdburn1 "#"$unid $cdrecordcdrwferascomp1 $vel $cdrecordcdrwferascomp2 "#" "NM" "#" "NM"

			if test $ejcodret -eq 0;then
				pinta_mensaje ${C_OK} $borra_MSG8
			else
				err_borra_cdrw
			fi
		fi

		expulsar_medio $IDE
	;;

	3)
		# Borra un CD-RW con cdrskin

		cabecera
		echo -e "${C_AV}$borra_MSG7${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		sleep 2

		lingrcmdexec $lingrcdburn3 "#" $cdrskincdrwerase1 $unid $cdrskincdrwerase2 "#" $borra_MSG8 "#" $borra_MSG9
	;;

	0)
		break
	;;

	*)
		mui_Opcion_invalida
	;;
esac

[ -f $INPUT ] && rm $INPUT &> /dev/null

done

}

# cerrar_cd
# cierra un CD abierto

cerrar_cd(){

DEV="dev=$IDE"
Vel="speed=$Velocidad"

    	echo -e "${C_AV}$cerrar_cd_MSG4${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

	lingrcmdexec $lingrcdburn1 "#"$DEV $Vel $cdrecordfixcd1 "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then

        	pinta_mensaje ${C_OK} $cerrar_cd_MSG2

	else

        	pinta_mensaje ${C_FA} $cerrar_cd_MSG3

	fi	

}

# grabimg
# graba una imagen en CD o DVD mediante cdrecord

# modificada para informar sobre el proceso
# de grabacion de imagenes .ext2

grabimg(){

	typeset local tes=0
	typeset local MSG=$grabimg_MSG1
	typeset local msgiiso="Img (Iso-9660) .iso / (Second Extended) .ext2"

	DEV="dev=$IDE"
	Vel="speed=$Velocidad"

	echo $grabimg_MSG2
	gestor_de_archivos $MSG

	case $UD in
		0 | 3)
			obten_cadena "$msgiiso" "$MSG"
			imagen=$lacadena
		;;

		1)
			cabecera
			echo $grabimg_MSG3
			read imagen

		;;

		2)
			imagen=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="$grabimg_MSG3")
		;;

	esac

	lingrcmdexec $lingrcdburn1 "#"$DEV $cdrecordwimgcdoverburn1 $Vel $cdrecordwimgcdoverburn2 $imagen "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then

		if ls $imagen | grep -e ".ext2" && expr $? = 0;then
		# Se trata de una imagen .ext2
			tes=2
		else
		# Se trata de una imagen .iso
			tes=1
		fi
	else


	    if test $MEDIO != "DVD";then
		
        		mui_CD_error

			echo ""

			echo $grabimg_MSG5
			m_cdrecord-sin-overburn

			lingrcmdexec $lingrcdburn1 "#"$DEV $cdrecordwimgcd1 $Vel $cdrecordwimgcd2 $imagen "#" "NM" "NM"

			if test $ejcodret -eq 0;then
	
				if ls $imagen | grep -e ".ext2" && expr $? = 0;then
				# Se trata de una imagen .ext2
					tes=2
				else
				# Se trata de una imagen .iso
					tes=1
				fi

			else

                		mui_DO_error

			fi

	    else
            
            		mui_DO_error

	    fi
	fi

	if test $tes -eq 1;then
        	pinta_mensaje ${C_OK} $grabimg_MSG6
	else 
	     if test $tes -eq 2;then
            	pinta_mensaje ${C_OK} $grabimg_MSG7
	     fi
	fi

}

# grabimglb
# Graba una imagen iso en CD/DVD/BD con cdrskin

grabimglb(){

typeset local imageniso9660lb=""
typeset local LABELTIT="ISO-9660 IMG"

cmdunit="dev=$IDE"

obten_cadena "$LABELTIT" "$grabimglb_MSG1"
imageniso9660lb=$lacadena
OPTCDRS="$cdrskiniso2od1 $cmdunit $cdrskiniso2od2 $imageniso9660lb"

cabecera

if test -f $imageniso9660lb;then
	echo -e "${C_OK} $grabimglb_MSG2 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	lingrcmdexec $lingrcdburn3 "#" $OPTCDRS "#" $grabimglb_MSG3 "#" $grabimglb_MSG4
	expulsar_medio $IDE
else
	pinta_mensaje ${C_FA} $grabimglb_MSG5
fi

}

# grabimg_cue
# graba una imagen .bin desde su fichero .cue en CD.

# requiere cdrdao

grabimg_cue(){

MSG=$grabimg_cue_MSG1
gestor_de_archivos $MSG
cd $HOME
cabecera
echo $grabimg_cue_MSG2
echo $grabimg_cue_MSG3
echo "$grabimg_cue_MSG4: $(pwd)"
echo $grabimg_cue_MSG5
echo -n $grabimg_cue_MSG6
read filecue

lingrcmdexec $lingrcdburn2 "#"$cdrdaowimgbincue1 $IDE $cdrdaowimgbincue2 $Velocidad $filecue "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
    pinta_mensaje ${C_OK} $grabimg_cue_MSG8
else
    mui_CD_error
fi

expulsar_medio $IDE

}

# graba un CD multisesión

cd_multi(){

DEV="dev=$IDE"
Vel="speed=$Velocidad"
CATA="ATAPI:$IDE"

imagen=$D_TMP/lcdgrabcmulti.iso

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

case $UD in
0)
    dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA CD MENU" \
	--menu "$cd_multi_MSG18" 10 70 20 \
	1 "$cd_multi_MSG1" \
	2 "$cd_multi_MSG3" \
	0 "$cd_multi_MSG6" 2>"${INPUT}"
	cdmultimenu="$(<${INPUT})"

;;

1)
    cdmultimenu=""

    cabecera
    printf "\t\t$cd_multi_MSG18"
    printf "\n=================================================\n"
    echo "1.- $cd_multi_MSG1"
    echo -e "${C_AV}    $cd_multi_MSG2 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
    echo "2.- $cd_multi_MSG3"
    echo -e "${C_AV}    $cd_multi_MSG4 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
    echo -e "${C_AV}    $cd_multi_MSG5 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
    echo ""
    echo "0.- $cd_multi_MSG6"
    read cdmultimenu

;;

2)
	cdmultimenu=$(zenity --width=80 --height=200 --title="$PROGRAMA" --entry --text="
$cd_multi_MSG18
1.- $cd_multi_MSG1
$cd_multi_MSG2
2.- $cd_multi_MSG3
$cd_multi_MSG4
$cd_multi_MSG5
0.- $cd_multi_MSG6")

;;

3)

	cdmultimenu=$(kdialog --menu="$cd_multi_MSG18" \
1 "1.- $cd_multi_MSG1" \
2 "2.- $cd_multi_MSG3" \
0 "0.- $cd_multi_MSG6" --geometry=600x170 --title="$PROGRAMA")

;;

esac

case $cdmultimenu in

	1)	# crea un CD-Multisesión a partir de una imagen .iso

		clear

		case $UD in
		0)
            	    dialog --title "$rutas_dir_D_MSG1" --backtitle "$PROGRAMA" --inputbox "$cd_multi_MSG7" 8 60 2> $D_LINUXCDGRAB/lcdgrabnombreruta.$$
        
            	    isomulti=$(cat $D_LINUXCDGRAB/lcdgrabnombreruta.$$)
            	    rm -rf $D_LINUXCDGRAB/lcdgrabnombreruta.$$
		;;

		1)
		    MSG=$cd_multi_MSG7

		    gestor_de_archivos $MSG

		    cabecera
		    echo $cd_multi_MSG8
		    read isomulti
		;;

		2)
		    isomulti=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="$cd_multi_MSG8")
		;;

		3)
		    isomulti=$(kdialog --title="$PROGRAMA" --inputbox "$cd_multi_MSG8" --geometry=600x300)
		;;

		esac

		cabecera

		lingrcmdexec $lingrcdburn1 "#"$DEV $Vel $cdrecordisocdmulti1 $isomulti "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
            		pinta_mensaje ${C_OK} $cd_multi_MSG10
		else
            		mui_CD_error
		fi

	;;

	2)	# crea un CD_Multisesión a partir de ficheros y directorios en disco


		cabecera
		MSG=$cd_multi_MSG11
		gestor_de_archivos $MSG
		echo ""
		cabecera
		echo $cd_multi_MSG12
		sleep 1.5

        	mui_rutas_dir

		obten_cadena " " "$cd_multi_MSG13"

		etiqueta=$lacadena

		cabecera
		echo $cd_multi_MSG14

		if $lingrmkimg2 $mkisofscddat1 $etiqueta $mkisocddatmulti1 $imagen $mkisocddatmulti2 $($lingrcdburn1 $cdrecordcdtpistamulti1:$CANALATAPI) $mkisoMop $CATA $mkisocddatmulti4 $NIVEL_ISO $mkisocddatmulti5 $HOME/rutas_lcdgrab.txt;then
			
			compmsg="$D_TMP/lcdgrabimg.iso $cd_multi_MSG15"
			pinta_mensaje ${C_OK} $compmsg

			cabecera
			echo $cd_multi_MSG17
			sleep 2
		
			lingrcmdexec $lingrcdburn1 "#"$DEV $Vel $cdrecordisocdmulti1 $imagen "#" "NM" "#" "NM"
		
			if test $ejcodret -eq 0;then
            			pinta_mensaje ${C_OK} $cd_multi_MSG10
			else
            			mui_CD_error
			fi

		else

            		pinta_mensaje ${C_FA} $cd_multi_MSG16

		fi
		
		rm -f $HOME/rutas_lcdgrab.txt
		rm -f $D_TMP/lcdgrabcmulti.iso

	;;

	0)	# Sale del menú
		break
	;;

	*)	# Opcion inválida

        	mui_Opcion_invalida
	;;
esac

done

rm -rf $INPUT &> /dev/null

}

# copia_cd_audio
# copia un cd de audio , ripea las pistas con cdda2wav

copia_cd_audio(){

DEV="dev=$LECTOR_CDROM"
AUXDEV="auxdevice=$IDE"
Vel="speed=$Velocidad"
GDEV="dev=$IDE"

if test -d $D_TMP/lcdgrabaudio;then
	rm -rf $D_TMP/lcdgrabaudio &> /dev/null
fi

mkdir $D_TMP/lcdgrabaudio

# extrae el CD

echo $copia_cd_audio_MSG1

lingrcmdexec $lingraudextr1 "#"$DEV $AUXDEV $Vel $cdda2wavripcd1 $D_TMP/lcdgrabaudio/ "#" $copia_cd_audio_MSG3 "#" $copia_cd_audio_MSG4

mui_una_sola_grabadora

echo $copia_cd_audio_MSG5

lingrcmdexec $lingrcdburn1 "#"$cdrecordcdda2wavwavcd1 $GDEV $Vel $cdrecordcdda2wavwavcd2 $D_TMP/lcdgrabaudio/*.[Ww][Aa][Vv] "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
    pinta_mensaje ${C_OK} $copia_cd_audio_MSG6
else
    mui_CD_error
fi

rm -rf $D_TMP/lcdgrabaudio &> /dev/null

if test $LECTOR_CDROM != $IDE;then
	expulsar_medio $LECTOR_CDROM
fi

}

# wav_a_cd
# graba archivos de audio .wav a un CD

wav_a_cd(){

MSG=$wav_a_cd_MSG1
msgerrcomp=""

cabecera
gestor_de_archivos $MSG

case $UD in
0)

	    dialog --clear --colors --backtitle "$PROGRAMA" --msgbox " $wav_a_cd_MSG2 \
		$wav_a_cd_MSG3 \
		$wav_a_cd_MSG4 " 11 55

	    obten_cadena " " "$wav_a_cd_MSG5"
	    wavruta=$lacadena
;;

1)
	    cabecera
	    echo -e "${C_AV}"
	    echo $wav_a_cd_MSG2
	    echo $wav_a_cd_MSG3
	    echo $wav_a_cd_MSG4
	    echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	    echo $wav_a_cd_MSG5

	    read wavruta
;;

2)

	    zenity --title="$PROGRAMA" --info --text="
$wav_a_cd_MSG2
$wav_a_cd_MSG3
$wav_a_cd_MSG4" --width=400 --height=150

	    obten_cadena "${COLOR_DEL_INTERFAZ}" "$wav_a_cd_MSG5"
	    wavruta=$lacadena
;;

3)

	    kdialog --msgbox "$wav_a_cd_MSG2
$wav_a_cd_MSG3
$wav_a_cd_MSG4" --title="$PROGRAMA" --geometry=500x500

	    obten_cadena "${COLOR_DEL_INTERFAZ}" "$wav_a_cd_MSG5"
	    wavruta=$lacadena
;;

esac

if test -d $wavruta;then
	
	cabecera
	echo "$wav_a_cd_MSG6:$lingrcdburn1 $cdrecordwav2cd1 dev=$IDE speed=$Velocidad $cdrecordwav2cd2 `ls $wavruta/*.[Ww][Aa][Vv]`"
	
	$lingrcdburn1 $cdrecordwav2cd1 dev=$IDE speed=$Velocidad $cdrecordwav2cd2 `ls $wavruta/*.[Ww][Aa][Vv]` & ImprimirProgreso

	pinta_mensaje ${C_OK} $wav_a_cd_MSG7

else
	msgerrcomp="$wavruta $datos_MSG17 $datos_MSG18"
	pinta_mensaje ${C_FA} $msgerrcomp
fi

}

# mp3_a_cd
# Graba archivos de audio .mp3 a un CD

mp3_a_cd(){

	mp3awav
	wav_a_cd

}

# ogg_a_cd
# Graba archivos de audio .ogg a un CD

ogg_a_cd(){

	oggawav
	wav_a_cd

}

# flac_a_cd
# Graba archivos de audio .flac a un CD

flac_a_cd(){

	flacawav
	wav_a_cd

}

# cdmixto
# Graba un CD mixto ; Datos .iso + Audio .wav

cdmixto(){

DEV="dev=$IDE"
Vel="speed=$Velocidad"

typeset local MSG=$cdmixto_MSG1

gestor_de_archivos $MSG
cabecera

echo -e "${C_AV}"
echo $cdmixto_MSG2
echo $cdmixto_MSG3
echo $cdmixto_MSG4
echo $cdmixto_MSG5
echo $cdmixto_MSG6
echo $cdmixto_MSG7
echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

echo $cdmixto_MSG8
read cdmwavruta

echo $cdmixto_MSG9
read cdmisoruta
echo ""
echo -e "$C_ET"
echo $cdmixto_MSG10
echo $cdmixto_MSG11
echo $cdmixto_MSG10
echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
sleep 1

# Llamada directa a la parametrización de comandos

echo "$cdmixto_MSG12:$lingrcdburn1 $cdrecordmixcd1 $cdmisoruta $cdrecordmixcd2 `ls $cdmwavruta/*.[Ww][Aa][Vv]`"

if $lingrcdburn1 $DEV $Vel $cdrecordmixcd1 $cdmisoruta $cdrecordmixcd2 `ls $cdmwavruta/*.[Ww][Aa][Vv]`;then
    pinta_mensaje ${C_OK} $cdmixto_MSG13
else
    pinta_mensaje ${C_FA} $cdmixto_MSG14
fi

}

# discoinfo
# Información sobre el disco grabado ,usa cdrecord

discoinfo(){

DEV="dev=$IDE"

cabecera
$lingrcdburn1 $DEV $cdrecordminf1

teclash

}

# cdrecord_scan
# Escanea el canal IDE e IDE ATAPI

cdrecord_scan(){
	
	cabecera

	if $lingrcdburn1 $cdrecordscop1 && $lingrcdburn1 dev=ATAPI $cdrecordscop1;then

		echo -e "${C_OK}$cdrecord_scan_MSG0${COLOR_DEL_INTERFAZ}"
	else

		echo -e "${C_FA}$cdrecord_scan_MSG1${COLOR_DEL_INTERFAZ}"

		if ! test -x $lingrcdburn1;then
			echo -e "${C_FA}$cdrecord_scan_MSG2${COLOR_DEL_INTERFAZ}"
		fi
	fi

}

# atapi_cdrecord_scan
# Escanea el canal IDE ATAPI

atapi_cdrecord_scan(){

	$lingrcdburn1 dev=ATAPI $cdrecordscop1

}

# cdrskin_scan
# Escanea el canal IDE con cdrskin
# Los valores pueden no concordar con la salida de cdrecord -scanbus

cdrskin_scan(){

	$lingrcdburn3 $cdrecordscop1

}

