#########################################################
# lcgdrabCMD_API/lcdgrabAUDIO-API.sh
# Coleccion de funciones para la extracción de pistas
# CD-Audio a diversos formatos de audio. Convierte
# formatos de audio. Soportados wav, ogg, mp3 y flac.
# Otros tratamientos sobre archivos de audio.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

########################## CONVERSION DE AUDIO ################################
###############################################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabAUDIO-API.idiom

# mp3awav
# convierte .mp3 en .wav
# Usa lame para convertir y sox para normalizar
# acepta rutamp3 como parametro

mp3awav(){

if test -z $rutamp3 || ! test -d $rutamp3;then

	obten_cadena "$mp3awav_MSG0B" "$mp3awav_MSG0"
	rutamp3=$lacadena

fi

if test -d $rutamp3;then

	cabecera

	for i in $rutamp3/*.[Mm][Pp][3];do

		cancionmp3=$i
		nombrewav=`basename "$cancionmp3" .mp3`.wav
		cancionwav="$( echo "$rutamp3$nombrewav" | sed -e 's/[ ]/_/g' -e 's/[	]/_/g')"
		corregido="$( echo "$rutamp3/corregido.wav")"
		fnormalizado="$( echo "$rutamp3/fnormalizado.wav")"

		echo -e "${C_AV}$mp3awav_MSG1 $cancionmp3 $mp3awav_MSG1B ${COLOR_DEL_INTERFAZ}"
		echo $cancionwav
		echo "cmd: $lingraudconv1 $lamedecodeop1 $cancionmp3 ${cancionwav}"
        	if $lingraudconv1 $lamedecodeop1 "$cancionmp3" "${cancionwav}";then

			echo -e "${C_OK} $cancionwav OK ${COLOR_DEL_INTERFAZ}"
			echo ""

			lingrcmdexecnostop $lingraudconv2 "#"$cancionwav $soxaudfrec1 $corregido "#" "NM" "#" "NM"

			if test $ejcodret -eq 0;then
				echo -e "${C_OK} $mp3awav_MSG3 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
				mv -f "$corregido" "$cancionwav"
				echo "$mp3awav_MSG8 $cancionwav"

				lingrcmdexecnostop $lingraudconv2 "#"$soxaudnorm1 $cancionwav $fnormalizado "#" "NM" "#" "NM"

				if test $ejcodret -eq 0;then
					mv -f "$fnormalizado" "$cancionwav"
					echo -e "${C_OK} $mp3awav_MSG9 $cancionwav $mp3awav_MSG10 ${COLOR_DE_INTERFAZ}${FONDO_INTERFAZ}"
				else
					echo -e "${C_FA} $mp3awav_MSG11 $cancionwav ${COLOR_DE_INTERFAZ}${FONDO_INTERFAZ}"
				fi

			else
				echo -e "${C_FA} $mp3awav_MSG4 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
			fi

			echo ""

		else 
			echo -e "${C_FA} $cancionmp3 $mp3awav_MSG5 ${COLOR_DEL_INTERFAZ}"
		fi
	done

	pinta_mensaje ${COLOR_DEL_INTERFAZ} $mp3awav_MSG7

else

	msgcompd="$mp3awav_MSG6 $rutamp3"
	pinta_mensaje ${C_FA} $mp3awav_MSG7 $msgcompd
fi

rutamp3=""

}

# oggawav
# convierte .ogg a .wav
# Usa oggdec para convertir y sox para normalizar
# acepta rutaogg como parametro

oggawav(){

typeset local cwavokmsg="$cancionwav OK"
typeset local cwaverrmsg="$cancionogg $oggawav_MSG6"
typeset local cnormok="$oggawav_MSG10 $cancionwav $oggawav_MSG11"
typeset local cnormerr="$oggawav_MSG12 $cancionwav"

if test -z $rutaogg || ! test -d $rutaogg;then

	obten_cadena "$oggawav_MSG0" "$oggawav_MSG1"
	rutaogg=$lacadena

fi

if test -d $rutaogg;then
	
	cabecera
	
	for i in $rutaogg/*.[Oo][Gg][Gg];do

		cancionogg=$i
		nombrewav=`basename "$cancionogg" .ogg`.wav
		cancionwav="$( echo "$rutaogg/$nombrewav" | sed -e 's/[ ]/_/g' -e 's/[	]/_/g')"
		corregido="$( echo "$rutaogg/corregido.wav")"
		fonormalizado="$( echo "$rutaogg/fonormalizado.wav")"

		echo -e "${C_AV} $oggawav_MSG2 $cancionogg $oggawav_MSG2B ${COLOR_DEL_INTERFAZ}"

	    	lingrcmdexecnostop $lingraudconv3 "#" "${cancionogg}" $oggdecaudout1 "${cancionwav}" "#" $cwavokmsg "#" $cwaverrmsg

	    	if test $ejcodret -eq 0;then

			    lingrcmdexecnostop $lingraudconv2 "#"$cancionwav $soxaudfrec1 $corregido "#" $oggawav_MSG4 "#" $oggawav_MSG5
                            if test -$ejcodret -eq 0;then

					mv -f "$corregido" "$cancionwav"

					lingrcmdexecnostop $lingraudconv2 "#"$soxaudnorm1 $cancionwav $fonormalizado "#" $cnormok "#" $cnormerr
					if test $ejcodret -eq 0;then
						mv -f "$fonormalizado" "$cancionwav"
					fi
			    fi
		fi

	done

else
	cabecera
	echo -e "${C_FA} $oggawav_MSG7 $rutaogg ${COLOR_DEL_INTERFAZ}"
	sleep 2
	echo ""
fi

pinta_mensaje ${COLOR_DEL_INTERFAZ} $oggawav_MSG8

rutaogg=""

}

# cdawav
# cdawav, Ripea un CD de Audio a ficheros .wav

cdawav(){

DEV="dev=$LECTOR_CDROM"
AUXDEV="auxdevice=$IDE"
Vel="speed=$Velocidad"

if test -d ${HOME}/lcdgrabaudio;then
	rm -rf ${HOME}/lcdgrabaudio
fi

mkdir ${HOME}/lcdgrabaudio

cabecera

echo $cdawav_MSG1

lingrcmdexec $lingraudextr1 "#"$DEV $AUXDEV $Vel $cdda2wavripcd1 $HOME/lcdgrabaudio/ "#" $cdawav_MSG3 "#" $cdawav_MSG5

if test $ejcodret -eq 0;then

	cabecera
	echo "$cdawav_MSG4 $HOME/lcdgrabaudio :"
	ls -l $HOME/lcdgrabaudio
	teclash

fi

}

# cddawav
# ripea un numero determinado de pistas de audio a ficheros .wav

cddawav(){

x=1 # contador

DEV="dev=$IDE"
AUXDEV="auxdevice=$LECTOR_CDROM"
Vel="speed=$Velocidad"

obten_cadena " " "$cddawav_MSG1"
numcanciones=$lacadena

if test -d $HOME/lcdgrabaudio;then
	rm -rf $HOME/lcdgrabaudio
fi

mkdir $HOME/lcdgrabaudio

cabecera

while `test $x -le $numcanciones`;do

	nombrewav=`basename pista_"$x"`.wav
	echo $cddawav_MSG2

	lingrcmdexecnostop $lingraudextr1 "#"$DEV $AUXDEV $Vel $cdda2wavripcdtrks1 $numcanciones track=$x $HOME/lcdgrabaudio/trackcd$x "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then
		echo -e "${C_OK} pista_$x.wav $cddawav_MSG4 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	else
		echo -e "${C_FA} $cddawav_MSG5 pista_$x.wav ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	fi

	let x++

done

}

# wavamp3
# comprime ficheros .wav en mp3

# comando de comprension: lame -h -m s -b 128 archivo.wav archivo.mp3

wavamp3(){

if test -z $*;then
	obten_cadena "$wavamp3_MSG0" "$wavamp3_MSG1"
	rutawav=$lacadena
else
	rutawav=$*
fi

if test -d $rutawav;then
	
	cabecera

	for i in $rutawav/*.[Ww][Aa][Vv];do

		cancionwav=$i
		nombremp3=`basename "$cancionwav" .wav`.mp3
		cancionmp3="$( echo "$rutawav/$nombremp3" | sed -e 's/[ ]/_/g' -e 's/[	]/_/g')"
		

		echo -e "${C_AV}$wavamp3_MSG1B $cancionwav $wavamp3_MSG2 .mp3 ${COLOR_DEL_INTERFAZ}"

		lingrcmdexecnostop $lingraudconv1 "#"$lamecodemp31 $cancionwav $cancionmp3 "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
			echo -e "${C_OK} $cancionmp3 OK${COLOR_DEL_INTERFAZ}"
			echo ""
		else
			echo -e "${C_FA}$wavamp3_MSG6 $cancionwav $wavamp3_MSG5 ${COLOR_DEL_INTERFAZ}"
		fi
		
	done

	pinta_mensaje ${COLOR_DEL_INTERFAZ} $wavamp3_MSG7

else
	pinta_mensaje ${C_FA} "$wavamp3_MSG8 --> $rutawav"
fi

rutawav=""

}

# cdamp3
# Ripea un CD de Audio a ficheros .mp3

cdamp3(){

DEV="dev=$LECTOR_CDROM"
AUXDEV="auxdevice=$IDE"
Vel="speed=$Velocidad"

if test -d  ${HOME}/lcdgrabaudio;then
	rm -rf ${HOME}/lcdgrabaudio
fi

mkdir ${HOME}/lcdgrabaudio

cabecera

echo $cdamp3_MSG1

lingrcmdexec $lingraudextr1 "#"$DEV $AUXDEV $Vel $cdda2wavripcd1 ${HOME}/lcdgrabaudio/lingrsongcd "#" $cdamp3_MSG3 "#" $cdamp3_MSG4

if test $ejcodret -eq 0;then

	rutamp3="${HOME}/lcdgrabaudio/"
	cabecera
	echo ""
	echo "$cdamp3_MSG5 wavamp3 $rutamp3"
	wavamp3 $rutamp3

	rm -f $HOME/lcdgrabaudio/*.cddb 
	rm -f $HOME/lcdgrabaudio/*.cdtext
	rm -f $HOME/lcdgrabaudio/*.inf
	rm -f $HOME/lcdgrabaudio/*.cdindex
	rm -f $HOME/lcdgrabaudio/*.wav

fi

}

# wavaogg
# Comprime ficheros .wav en .ogg

wavaogg(){

if test -z $1 || ! test -d $1;then

	obten_cadena "$wavamp3_MSG0" "$wavaogg_MSG1"
	rutawav=$lacadena

else
	rutawav=$*
fi

if test -d $rutawav;then
	
	cabecera

	for i in $rutawav/*.[Ww][Aa][Vv];do

		cancionwav=$i
		nombreogg=`basename "$cancionwav" .wav`.ogg
		cancionogg="$( echo "$rutawav/$nombreogg" | sed -e 's/[ ]/_/g' -e 's/[	]/_/g')"

		echo -e "${C_AV}$wavaogg_MSG2 $cancionwav $wavaogg_MSG3 ${COLOR_DEL_INTERFAZ}"
		
		lingrcmdexecnostop $lingraudconv4 "#"$cancionwav $oggencaudout1 $cancionogg "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
			echo -e "${C_OK} $cancionogg OK${COLOR_DEL_INTERFAZ}"
			echo ""
		else
			echo -e "${C_FA} $wavaogg_MSG5 $cancionwav $wavaogg_MSG6 ${COLOR_DEL_INTERFAZ}"
		fi
		
	done
fi

echo ""

rutawav=""

teclash

}

# cdaogg
# Ripea un CD de Audio a ficheros .ogg

cdaogg(){

DEV="dev=$LECTOR_CDROM"
AUXDEV="auxdevice=$IDE"
Vel="speed=$Velocidad"

if test -d ${HOME}/lcdgrabaudio;then
	rm -rf ${HOME}/lcdgrabaudio
fi

mkdir ${HOME}/lcdgrabaudio

cabecera

echo $cdaogg_MSG1

lingrcmdexec $lingraudextr1 "#"$DEV $AUXDEV $Vel $cdda2wavripcd1 $HOME/lcdgrabaudio/lingrsongcd "#" $cdaogg_MSG3 "#" $cdaogg_MSG4

if test $ejcodret -eq 0;then

	rutaogg="$HOME/lcdgrabaudio"
	cabecera
	echo "$cdaogg_MSG5 wavaogg $rutaogg"
	wavaogg $rutaogg
	rm -f $HOME/lcdgrabaudio/*.cddb 
	rm -f $HOME/lcdgrabaudio/*.cdtext
	rm -f $HOME/lcdgrabaudio/*.inf
	rm -f $HOME/lcdgrabaudio/*.cdindex
	rm -f $HOME/lcdgrabaudio/*.wav
fi

}

# cdaflac
# Ripea un CD de Audio a ficheros .flac

cdaflac(){

DEV="dev=$LECTOR_CDROM"
AUXDEV="auxdevice=$IDE"
Vel="speed=$Velocidad"

cdaflac_MSG1=$cdaogg_MSG1
cdaflac_MSG2=$cdaogg_MSG3
cdaflac_MSG3=$cdaogg_MSG4
cdaflac_MSG4=$cdaogg_MSG5

if test -d ${HOME}/lcdgrabaudio;then
	rm -rf ${HOME}/lcdgrabaudio
fi

mkdir ${HOME}/lcdgrabaudio

cabecera

echo $cdaflac_MSG1

lingrcmdexec $lingraudextr1 "#"$DEV $AUXDEV $Vel $cdda2wavripcd1 ${HOME}/lcdgrabaudio/lingrsongcd "#" $cdaflac_MSG2 "#" $cdaflac_MSG3

if test $ejcodret -eq 0;then

	rutaflac="$HOME/lcdgrabaudio"
	cabecera
	echo "$cdaflac_MSG4 wavaflac $rutaflac"
	wavaflac $rutaflac

	rm -f $HOME/lcdgrabaudio/*.cddb 
	rm -f $HOME/lcdgrabaudio/*.cdtext
	rm -f $HOME/lcdgrabaudio/*.inf
	rm -f $HOME/lcdgrabaudio/*.cdindex
	rm -f $HOME/lcdgrabaudio/*.wav
fi

}
# corta_wav
# Corta un fichero .wav

corta_wav(){

	INIAUDIOCON=0
	FINAUDIOCON=0

	MSG=$corta_wav_MSG13
	MSGCOMP=""

	clear
	gestor_de_archivos $MSG

	obten_cadena "$MSG" "$corta_wav_MSG1"
	audioorig=$lacadena
	
	cabecera
	echo $corta_wav_MSG2
	echo $corta_wav_MSG3
	echo $corta_wav_MSG4
	echo $corta_wav_MSG5
	echo $corta_wav_MSG6

	obten_cadena "$corta_wav_MSG0" "$corta_wav_MSG6"
	INIAUDIOCON=$lacadena

	cabecera
	echo $corta_wav_MSG7
	echo $corta_wav_MSG8
	echo ""
	echo $corta_wav_MSG9

	obten_cadena "$corta_wav_MSG0" "$corta_wav_MSG9"
	FINAUDIOCON=$lacadena

	MSGCOMP="$corta_wav_MSG12 $audioorig"

	lingrcmdexec $lingraudconv2 "#"$audioorig $audioorig.Recortado.wav $soxaudrecort1 $INIAUDIOCON $FINAUDIOCON "#" $corta_wav_MSG11 "#" $MSGCOMP

}

# flacawav
# Convierte archivos de audio .flac en .wav
# Usa flac para convertir y sox para normalizar
# acepta rutaflac como parametro

flacawav(){

if test -z $rutaflac || ! test -d $rutaflac;then

	obten_cadena "$flacawav_MSG0" "$flacawav_MSG1"	
	rutaflac=$lacadena

fi

if test -d $rutamp3;then

	cabecera

	for i in $rutaflac/*.[Ff][Ll][Aa][Cc];do

		cancionflac=$i
		nombrewav=`basename "$cancionflac" .flac`.wav
		cancionwav="$( echo "$rutaflac$nombrewav" | sed -e 's/[ ]/_/g' -e 's/[	]/_/g')"
		corregido="$( echo "$rutaflac/corregido.wav")"
		fnormalizado="$( echo "$rutaflac/fnormalizado.wav")"

		echo -e "${C_AV}$flacawav_MSG2 $cancionflac $flacawav_MSG3 ${COLOR_DEL_INTERFAZ}"
		echo $cancionwav
		echo "cmd: $lingraudconv5 $flacconvop1 $cancionflac ${cancionwav}"
        	if $lingraudconv5 $flacconvop1 "$cancionflac" -o "${cancionwav}";then

			echo -e "${C_OK} $cancionwav OK ${COLOR_DEL_INTERFAZ}"
			echo ""

			lingrcmdexecnostop $lingraudconv2 "#"$cancionwav $soxaudfrec1 $corregido "#" "NM" "#" "NM"

			if test $ejcodret -eq 0;then
				echo -e "${C_OK} $flacawav_MSG4 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
				mv -f "$corregido" "$cancionwav"
				echo "$flacawav_MSG6 $cancionwav"

				lingrcmdexecnostop $lingraudconv2 "#"$soxaudnorm1 $cancionwav $fnormalizado "#" "NM" "#" "NM"

				if test $ejcodret -eq 0;then
					mv -f "$fnormalizado" "$cancionwav"
					echo -e "${C_OK} $flacawav_MSG7 $cancionwav $flacawav_MSG8 ${COLOR_DE_INTERFAZ}${FONDO_INTERFAZ}"
				else
					echo -e "${C_FA} $flacawav_MSG9 $cancionwav ${COLOR_DE_INTERFAZ}${FONDO_INTERFAZ}"
				fi

			else
				echo -e "${C_FA} $flacawav_MSG5 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
			fi

			echo ""

		else 
			echo -e "${C_FA} $cancionflac $flacawav_MSG10 ${COLOR_DEL_INTERFAZ}"
		fi
	done

	pinta_mensaje ${COLOR_DEL_INTERFAZ} $flacawav_MSG12

else

	msgcompd="$flacawav_MSG11 $rutaflac"
	pinta_mensaje ${C_FA} $flacawav_MSG12 $msgcompd
fi

rutaflac=""

}

# wavaflac
# Convierte archivos de audio .wav en .flac

wavaflac(){

if test -z $1 || ! test -d $1;then

	obten_cadena "$wavaflac_MSG0" "$wavaflac_MSG1"
	rutawav=$lacadena

else
	rutawav=$*
fi

if test -d $rutawav;then
	
	cabecera

	for i in $rutawav/*.[Ww][Aa][Vv];do

		cancionwav=$i

		echo -e "${C_AV}$wavaflac_MSG2 $cancionwav $wavaflac_MSG4 ${COLOR_DEL_INTERFAZ}"

		lingrcmdexecnostop $lingraudconv5 "#"$flacconvop2 $cancionwav"#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
			echo -e "${C_OK} $cancionwav $wavaflac_MSG4 ${COLOR_DEL_INTERFAZ}"
			echo ""
		else
			echo -e "${C_FA} $wavaflac_MSG5 $cancionwav $wavaflac_MSG6 ${COLOR_DEL_INTERFAZ}"
		fi
		
	done

	echo ""

	rutawav=""
else
	echo -e "${C_FA}  $wavaflac_MSG7 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
fi

teclash

}

