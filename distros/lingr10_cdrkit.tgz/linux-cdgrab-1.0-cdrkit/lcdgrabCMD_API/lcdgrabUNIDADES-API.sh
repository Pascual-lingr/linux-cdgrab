#########################################################
# lcgdrabCMD_API/lcdgrabUNIDADES-API.sh
# Colección de funciones para la escritura de archivos
# de imagen y formateo en unidades de disco.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de linux-cdgrab 1.0
#########################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabUNIDADES-API.idiom

################## DISPOSITIVOS DE BLOQUE ###################

# volcar_imagen
#
# Mensaje de Aviso, llamada a la función p_volcar_imagen

volcar_imagen(){

MSG=$volcar_imagen_MSG1

clear

case $UD in 

0)

	UNIDAVV="$volcar_imagen_MSG2
		$volcar_imagen_MSG3
		$volcar_imagen_MSG4
		$volcar_imagen_MSG5
		$volcar_imagen_MSG6
		$volcar_imagen_MSG7
		$volcar_imagen_MSG8
		$volcar_imagen_MSG9
		$volcar_imagen_MSG10
		$volcar_imagen_MSG11
		$volcar_imagen_MSG12
		$volcar_imagen_MSG13
		$volcar_imagen_MSG14"

dialog --clear --backtitle "-++ $PROGRAMA ++-" --title "$PROGRAMA FLASHDRIVE MENU" --yesno "$UNIDAVV" 20 83 

if test $? -eq 0;then
	opciondddisco="C"
else
	opciondddisco="A"
fi

;;

1)
cabecera
echo -e "${C_AV} "
echo $volcar_imagen_MSG2
echo $volcar_imagen_MSG3
echo $volcar_imagen_MSG4
echo ""
echo $volcar_imagen_MSG5

echo $volcar_imagen_MSG6
echo $volcar_imagen_MSG7
echo $volcar_imagen_MSG8
echo ""
echo $volcar_imagen_MSG9
echo $volcar_imagen_MSG10
echo ""
echo $volcar_imagen_MSG11
echo $volcar_imagen_MSG12
echo $volcar_imagen_MSG13
echo $volcar_imagen_MSG14
echo -e "${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"

echo $volcar_imagen_MSG15
read opciondddisco

;;

2)

	opciondddisco=$(zenity --width=400 --height=250 --title="$PROGRAMA" --entry --text="
$volcar_imagen_MSG2
$volcar_imagen_MSG3
$volcar_imagen_MSG4
$volcar_imagen_MSG5
$volcar_imagen_MSG6
$volcar_imagen_MSG7
$volcar_imagen_MSG8
$volcar_imagen_MSG9
$volcar_imagen_MSG10
$volcar_imagen_MSG11
$volcar_imagen_MSG12
$volcar_imagen_MSG13
$volcar_imagen_MSG15")

;;

3)

		KDIAMSGVOL="$volcar_imagen_MSG2
$volcar_imagen_MSG3
$volcar_imagen_MSG4
$volcar_imagen_MSG5
$volcar_imagen_MSG6
$volcar_imagen_MSG7
$volcar_imagen_MSG8
$volcar_imagen_MSG9
$volcar_imagen_MSG10
$volcar_imagen_MSG11
$volcar_imagen_MSG12
$volcar_imagen_MSG13
$volcar_imagen_MSG14"

		kdialog --warningyesno "$KDIAMSGVOL" --geometry=400x400 --title "$PROGRAMA"

		if test $? -eq 0;then
			opciondddisco="C"
		else
			opciondddisco="A"
		fi

;;

esac

case $opciondddisco in

"C" | "c")

	p_volcar_imagen

;;

*)
echo " "
;;

esac

}

# p_volcar_imagen
#
# vuelca una imagen .ext2, .iso o.img en un dispositivo de bloque.
# No soporta imágenes autoarrancables. Solo imágenes de datos.

# NOTA: 
# Esta función no es funcional en discos ópticos.
# Usar sobre pendrives, diskettes, particiones de disco etc.

# Usar con precaución y bajo riesgo propio.
# La escritura de la imagen se hace con dd desde el inicio
# de disco, no se permite escribir la imagen desde otras 
# regiones del disco.

# No usar en sistemas de múltiples particiones.
# La restauración puede dejar la tabla de particiones y
# particiones en si inservibles.

p_volcar_imagen(){

gestor_de_archivos $MSG
cabecera
echo -n $volcar_imagen_MSG16
read imagenavolcar

cabecera
echo -e "${C_ET} $volcar_imagen_MSG17 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
mount | grep -v 'cgroup' | grep -v 'tmpfs'
echo ""
echo $volcar_imagen_MSG18
read DispositivoBloque

cabecera
echo "$volcar_imagen_MSG19 $imagenavolcar $volcar_imagen_MSG20 $DispositivoBloque"

ddoptsdi="$ddop1$imagenavolcar $ddop2$DispositivoBloque $ddop4"
lingrcmdexec $gdd "#" $ddoptsdi "#" "NM" "#" "NM"

cabecera
echo ""
echo -e "${C_AV} $volcar_imagen_MSG22 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
echo ""
teclash

}


# m_volcar_iso, clon de volcar_imagen
#
# Mensaje de aviso y llamada a función volcar_iso

m_volcar_iso(){

clear

case $UD in 

0)

	UNIDAVV="$volcar_imagen_MSG2
		$volcar_imagen_MSG3
		$volcar_imagen_MSG4
		$volcar_imagen_MSG5
		$volcar_imagen_MSG6
		$volcar_imagen_MSG7
		$volcar_imagen_MSG8
		$volcar_imagen_MSG9
		$volcar_imagen_MSG10
		$volcar_imagen_MSG11
		$volcar_imagen_MSG12
		$volcar_imagen_MSG13
		$volcar_imagen_MSG14"

dialog --clear --backtitle "-++ $PROGRAMA ++-" --title "$PROGRAMA FLASHDRIVE MENU" --yesno "$UNIDAVV" 20 83 

if test $? -eq 0;then
	opciondddisco="C"
else
	opciondddisco="A"
fi

;;

1)
cabecera
echo -e "${C_AV} "
echo $volcar_imagen_MSG2
echo $volcar_imagen_MSG3
echo $volcar_imagen_MSG4
echo ""
echo $volcar_imagen_MSG5

echo $volcar_imagen_MSG6
echo $volcar_imagen_MSG7
echo $volcar_imagen_MSG8
echo ""
echo $volcar_imagen_MSG9
echo $volcar_imagen_MSG10
echo ""
echo $volcar_imagen_MSG11
echo $volcar_imagen_MSG12
echo $volcar_imagen_MSG13
echo $volcar_imagen_MSG14
echo -e "${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"

echo $volcar_imagen_MSG15
read opciondddisco

;;

2)

	opciondddisco=$(zenity --width=400 --height=250 --title="$PROGRAMA" --entry --text="
$volcar_imagen_MSG2
$volcar_imagen_MSG3
$volcar_imagen_MSG4
$volcar_imagen_MSG5
$volcar_imagen_MSG6
$volcar_imagen_MSG7
$volcar_imagen_MSG8
$volcar_imagen_MSG9
$volcar_imagen_MSG10
$volcar_imagen_MSG11
$volcar_imagen_MSG12
$volcar_imagen_MSG13
$volcar_imagen_MSG15")

;;

3)

		KDIAMSGVOL="$volcar_imagen_MSG2
$volcar_imagen_MSG3
$volcar_imagen_MSG4
$volcar_imagen_MSG5
$volcar_imagen_MSG6
$volcar_imagen_MSG7
$volcar_imagen_MSG8
$volcar_imagen_MSG9
$volcar_imagen_MSG10
$volcar_imagen_MSG11
$volcar_imagen_MSG12
$volcar_imagen_MSG13
$volcar_imagen_MSG14"

		kdialog --warningyesno "$KDIAMSGVOL" --geometry=400x400 --title "$PROGRAMA"

		if test $? -eq 0;then
			opciondddisco="C"
		else
			opciondddisco="A"
		fi

;;

esac

case $opciondddisco in

"C" | "c")

	volcar_iso

;;

*)
echo " "
;;

esac

}

# volcar_iso
# Función para volcar una imagen .iso o .img autoarrancable sobre pendrive.

# NOTA: Sistemas soportados:
#
# Linux, FreeBSD, OpenSolaris --> bs=4M
# NetBSD y Haiku OS --> bs=1M
# Windows 10 --> bs=4M conv=fdatasync
# DragonFlyBSD --> tanto bs=4M como bs=1M
#
# Es posible que alguna de estas opciones no sea
# funcional por no soportar el formato del archivo
# de imagen.
# No soportadas todas las distribuciones Linux u
# otros sistemas operativos.
# 
# Esta opción borrara todos los datos y formato anterior
# de la unidad.
# Usar con precaución, usar bajo propio riesgo.

volcar_iso(){

typeset local isofile=""
typeset local tblkop=0

cabecera

if test -x $D_BIN/lsblk;then
	lsblk
elif test -x /bin/lsblk;then
	lsblk
else
	echo -e "${C_ET} $volcar_imagen_MSG17 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	mount | grep -v "none"
	echo ""
fi

echo -e "${C_AV}$volcar_iso_MSG2 ${FONDO_INTERFAZ}"
echo -e "${C_AV}$volcar_iso_MSG2B ${FONDO_INTERFAZ}"
echo -e "${C_AV}$volcar_iso_MSG3 ${FONDO_INTERFAZ}"
echo -e "${C_AV}$volcar_iso_MSG4 ${FONDO_INTERFAZ}"
echo -e "${C_AV}$volcar_iso_MSG5 ${FONDO_INTERFAZ}"
echo -e "${C_AV}$volcar_iso_MSG6 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
echo $volcar_iso_MSG1
read DispositivoBloque

clear

while $verdad;do

case $UD in
0)

	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA FLASH ISO-9660/IMG" \
	--menu "$volcar_ISO_MSG16" 12 65 14 \
	1 "Linux, FreeBSD, OpenSolaris, DragonFlyBSD --> bs=4M" \
	2 "Windows 10 --> bs=4M" \
	3 "NetBSD, OpenBSD, Haiku OS, DragonFlyBSD --> bs=1M" \
	0 "$volcar_iso_MSG14" 2>"${INPUT}"
	tblkop=$(<"${INPUT}")
;;

1)
	cabecera
	echo "$volcar_iso_MSG11"
	echo "$volcar_iso_MSG12"
	echo "1.- Linux, FreeBSD, OpenSolaris, DragonFlyBSD --> bs=4M"
	echo "2.- Windows 10 --> bs=4M"
	echo "3.- NetBSD, OpenBSD, Haiku OS, DragonFlyBSD --> bs=1M"
	echo ""
	echo "0.- $volcar_iso_MSG14"
	echo ""
	read tblkop
;;

2)
	tblkop=$(zenity --width=400 --height=300 --title="$PROGRAMA" --entry --text="
$volcar_iso_MSG11
$volcar_iso_MSG12
1.- Linux, FreeBSD, OpenSolaris, DragonFlyBSD -- bs=4M
2.- Windows 10 -- bs=4M
3.- NetBSD, OpenBSD, Haiku OS, DragonFlyBSD -- bs=1M
0.- $volcar_iso_MSG14")
;;

3)
	tblkop=$(kdialog --menu "$volcar_iso_MSG12" \
1 "1- Linux, FreeBSD, OpenSolaris, DragonFlyBSD -- bs=4M" \
2 "2- Windows 10 -- bs=4M" \
3 "3- NetBSD, OpenBSD, Haiku OS, DragonFlyBSD -- bs=1M" \
0 "0- $volcar_iso_MSG14" --geometry=650x190 --title "$PROGRAMA")
;;

esac
  
  case $tblkop in

	1 | 2)
		tblk="4M"
		break
	;;
	
	3)
		tblk="1M"
		break
	;;

	0)	
		break
	;;

	*)
		mui_Opcion_invalida
	;;
  esac

done

if test $tblkop -ne 0;then

	gestor_de_archivos $volcar_iso_MSG13

	obten_cadena "$volcar_iso_MSG15" "$volcar_iso_MSG7"

	isofile=$lacadena

	# Escribe la imagen en el dispositivo

	lingrcmdexec $gdd "#"$ddop1$isofile $ddop2$DispositivoBloque $ddblkszp$tblk $ddisodb1 "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then
		sync
		pinta_mensaje ${C_OK} $volcar_iso_MSG9
	else

		pinta_mensaje ${C_FA} $volcar_iso_MSG10
	fi
fi

[[ -f ${INPUT} ]] && rm -rf ${INPUT} &> /dev/null

}

# Formateador_linuxfs
# 
# Formatea una unidad con los siguientes sistemas de ficheros:
# ext2, ext3 y ext4
# NTFS
# FAT32 (vfat)
# XFS
# Btrfs
# exFAT
#
# NOTA: 
# Esta opción borrara todos los datos y formato anterior
# de la unidad.
# Usar con precaución, usar bajo propio riesgo.

Formateador_linuxfs(){

local vollabel=""
local lingrblksize="4096"

cabecera
echo ""
if test -x $D_BIN/lsblk;then
	lsblk
elif test -x /bin/lsblk;then
	lsblk
else
	echo -e "${C_ET} $volcar_imagen_MSG17 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	mount | grep -v "none"
	echo ""
fi
echo ""
echo $Formateador_linuxfs_MSG3
read dispositivobloqueaformatear

clear

while $verdadero;do

			case $UD in
			0)

    				dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
				--title "$PROGRAMA MENU FMRT UNID" \
				--menu "" 20 90 20 \
				1 "Ext2 (Second extended) # Linux FS #" \
				2 "Ext3 (Three extended) # Linux FS #" \
				3 "Ext4 (Four extended) # Linux FS #" \
				4 "XFS (XFS file system) # Linux FS #" \
				5 "JFS (Journaling file system) # Linux FS #" \
				6 "BTRFS (Be Tree file system) # Linux FS #" \
				7 "NTFS (New Technology File System) # Windows FS #" \
				8 "VFat (FAT32: File Allocation Table) # Windows FS #" \
				9 "exFAT (Extended File Allocation Table) # Windows FS #" \
				0 "$Formateador_linuxfs_MSG14" \
				SL "--> $Formateador_linuxfs_MSG7" 2>"${INPUT}"
				fop="$(<${INPUT})"
			;;

			1)
				cabecera
				printf "\t\t $Formateador_linuxfs_MSG6 \n"
				printf "=================================================\n"
				echo $Formateador_linuxfs_MSG1
				echo $Formateador_linuxfs_MSG2
				echo -e "${C_ET}---------LINUX------------${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
				echo "1.- Ext2 (Second extended)"
				echo "2.- Ext3 (Three extended)"
				echo "3.- Ext4 (Four extended)"
				echo "4.- XFS (XFS file system)"
				echo "5.- JFS (Journaling file system)"
				echo "6.- BTRFS (Be Tree file system)"
				echo -e "${C_ET}---------WINDOWS----------${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
				echo "7.- NTFS (New Technology File System)"
				echo "8.- VFat (FAT32: File Allocation Table)"
				echo "9.- exFAT (Extended File Allocation Table)"
				echo "0.- $Formateador_linuxfs_MSG14"
				echo ""
				echo "SL --> $Formateador_linuxfs_MSG7"

				read fop

			;;

			2)
				fop=$(zenity  --width=400 --height=400 --title="$PROGRAMA" --entry --text="
$Formateador_linuxfs_MSG6
=================================================
$Formateador_linuxfs_MSG1 $Formateador_linuxfs_MSG2
---------LINUX------------
1.- Ext2 (Second extended)
2.- Ext3 (Three extended)
3.- Ext4 (Four extended)
4.- XFS (XFS file system)
5.- JFS (Journaling file system)
6.- BTRFS (Be Tree file system)
---------WINDOWS----------
7.- NTFS (New Technology File System)
8.- VFat (FAT32: File Allocation Table)
9.- exFAT (Extended File Allocation Table)
0.- $Formateador_linuxfs_MSG14
SL -- $Formateador_linuxfs_MSG7")
			;;

			3)
				fop=$(kdialog --menu "$Formateador_linuxfs_MSG6" \
1 "1- Ext2 (Second extended) # Linux FS #" \
2 "2- Ext3 (Three extended) # Linux FS #" \
3 "3- Ext4 (Four extended) # Linux FS #" \
4 "4- XFS (XFS file system) # Linux FS #" \
5 "5- JFS (Journaling file system) # Linux FS #" \
6 "6- BTRFS (Be Tree file system) # Linux FS #" \
7 "7- NTFS (New Technology File System) # Windows FS #" \
8 "8- VFat (FAT32: File Allocation Table) # Windows FS #" \
9 "9- exFAT (Extended File Allocation Table) # Windows FS#" \
SL "SL -- $Formateador_linuxfs_MSG7" \
0 "0- $Formateador_linuxfs_MSG14" --geometry=510x380 --title "$PROGRAMA")
			;;

			esac

			case $fop in

				1)
		
				# Formatea la unidad en ext2

				if test -z $vollabel;then
					vollabel="EXT2FS-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsunitext2="$mke2fsuop1 $vollabel $dispositivobloqueaformatear"

				lingrcmdexec $lingrfrext2 "#" $optsunitext2 "#" "NM" "#" "NM"

				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				2)

				# Formatea la unidad en ext3

				if test -z $vollabel;then
					vollabel="EXT3FS-DISK"
				fi
				
				lingrcmdexec $lingrumount1 "#"$dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsuniext3="$mkfsext3uop1 $vollabel $mkfsext3uop2 $lingrblksize $mkfsext3uop3 $dispositivobloqueaformatear"

				lingrcmdexec $lingrfext3 "#"$optsuniext3 "#" "NM" "#" "NM"

				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				3)

				# Formatea la unidad en ext4

				if test -z $vollabel;then
					vollabel="EXT4FS-DISK"
				fi

				lingrcmdexec $lingrumount1 "#"$dispositivobloqueaformatear "#" "NM" "#" "NM" 

				optsuniext4="$mkfsext4op1 $vollabel $mkfsext4op2 $lingrblksize $mkfsext4op3 $dispositivobloqueaformatear"

				lingrcmdexec $lingrfext4 "#" $optsuniext4 "#" "NM" "#" "NM"

				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break	

				;;

				4)

				# Formatea la unidad en XFS

				if test -z $vollabel;then
					vollabel="XFS-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsunixfs="$mkfsxfsop1 $vollabel $dispositivobloqueaformatear"

				lingrcmdexec $lingrfxfs "#"$optsunixfs "#" "NM" "#" "NM"

				printf "\n"
				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				5)

				# Formatea la unidad en JFS

				if test -z $vollabel;then
					vollabel="JFS-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsunijfs="$mkfsjfsop1 $vollabel $dispositivobloqueaformatear"

				lingrcmdexec $lingrfjfs "#"$optsunijfs "#" "NM" "#" "NM"

				printf "\n"
				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				6)

				# Formatea la unidad en BTRFS

				if test -z $vollabel;then
					vollabel="BTRFS-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				lingrcmdexec $lingrfbtrfs "#"$mkfsbtrfsop1 $vollabel $dispositivobloqueaformatear "#" "NM" "#" "NM"

				printf "\n"
				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				7)

				# Formatea  la unidad en NTFS (Windows)

				if test -z $vollabel;then
					vollabel="NTFS-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsunintfs="$mkfsntfsop1 $vollabel $dispositivobloqueaformatear"

				lingrcmdexec $lingrfntfs "#" $optsunintfs "#" "NM" "#" "NM"

				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				8)

				# Formatea  la unidad en vfat (FAT32, Windows)

				if test -z $vollabel;then
					vollabel="VFAT-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsunivfat="$mkfsvfatop1 $vollabel $dispositivobloqueaformatear"

				lingrcmdexec $lingrfvfat "#" $optsunivfat "#" "NM" "#" "NM"

				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				9)

				# Formatea  la unidad en exFAT (extended FAT, Windows)

				if test -z $vollabel;then
					vollabel="exFAT-DISK"
				fi

				lingrcmdexec $lingrumount1 "#" $dispositivobloqueaformatear "#" "NM" "#" "NM"

				optsuniexfat="$mkfsexfatop1 $vollabel $dispositivobloqueaformatear"

				lingrcmdexec $lingrfexfat "#"$optsuniexfat "#" "NM" "#" "NM"

				echo $Formateador_linuxfs_MSG5
				echo ""
				teclash
				break

				;;

				'SL')
				
				clear
				cabecera
				echo ""
				echo -n "$Formateador_linuxfs_MSG10: "
				read vollabel
				echo "$Formateador_linuxfs_MSG11: $vollabel"
				teclash
				continue
				;;

				0)
					break
				;;


				*)

                			mui_Opcion_invalida
					continue

				;;

			esac
done

}

