############################################################
# lcdgrabCoreAPP/lingrcmd.sh
# Parametrización de comandos ejecutados por linux-cdgrab.
# v_0.1.0
# Parametriza los comandos de linux-cdgrab 0.5 y los usados
# en nuevas funcionalidades.
# v_0.1.1dc
# Para la versión cdrkit_debian. 
# Elimina referencias a cdrtools. Solamente usa cdrkit.
# Elimina md5, cambios en parametros para la grabación
# de sesión de escritorio.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
############################################################

########################## Versión #########################

lingrcmdver="---- linux-cdgrab-1.0-def-param-cmd-v_0.1.1dc ----"

########################### Tratamiento de Audio #######################################

# Extrae un numero secuencial de pistas de audio de un CD-Audio a archivos .wav
# Precede dev=$IDE auxdevice=$LECTOR_CDROM speed=$Velocidad
cdda2wavripcdtrks1="-stereo -max -i"
# Extrae pistas de audio de un CD-Audio a archivos .wav
# precede dev=$LECTOR_CDROM auxdevice=$IDE speed=$Velocidad
cdda2wavripcd1="-stereo -max -B"
# Extractor de audio icedax
lingraudextr1="icedax"
# Comprime ficheros .wav en .mp3
lamecodemp31="-h -m s -b 128"
# Descomprime ficheros .mp3 a .wav
lamedecodeop1="-h --decode"
# Conversor lame
lingraudconv1="lame"
# Recorta un fichero .wav
soxaudrecort1="trim"
# Establece la frecuencia de audio de un fichero .wav
soxaudfrec1="-r 44100"
# Normaliza un fichero de audio .wav
soxaudnorm1="--norm"
# Conversor sox
lingraudconv2="sox"
oggdecaudout1="-o"
oggencaudout1=$oggdecaudout1
# Convierte archivos de audio .ogg a .wav
lingraudconv3="oggdec"
# Convierte archivos de audio .wav a .ogg
lingraudconv4="oggenc"
# Conversión de .flac a .wav
flacconvop1="-d"
# Conversión de .wav a .flac
flacconvop2="--best"
# Conversor flac
lingraudconv5="flac"

########################### Tratamiento de Video #######################################

# Convierte un video a compatibilidad con Blu Ray Video
# A ffmpegvid2brvop2 le precede -i archivoaconvertir.mkv. Antecede archivoconvertido.mkv
ffmpegvid2brvop2="-c:v libx264 -preset medium -crf 17 -profile:v high -level 4.1 -pix_fmt yuv420p -c:a copy"
ffmpegvid2brvop1="-i"
# Convierte archivo de video a diferentes formatos mpeg, mkv, mp4, flv ...
# Precede -i y el fichero de entrada, antecede el fichero de salida
ffmpegfvcforop1="-acodec copy -vcodec copy"
# Extrae el audio mp3 de un video.
# precede -i y el video de entrada, antecede el archivo de audio mp3 generado
ffmpegextaudfvop1="-vn -ar 44100 -ac 2 -ab 192k -f mp3"
# Extrae un fragmento de video, de un video original
ffmpegextvidop3="-vcodec copy -acodec copy"
# Se informa el tiempo final después de -t
ffmpegextvidop2="-t"
# Se informa el tiempo inicial después de -ss, antecede -i y el video a recortar.
ffmpegextvidop1="-ss"
# Graba la pantalla de escritorio
# Utiliza Pulse Audio
ffmpeggescpa2="-framerate 25 -f x11grab -i :0.0 -f pulse -ac 2 -i default"
ffmpeggescpa1="-video_size"
# Conversor ffmpeg
lingrvideocv1="ffmpeg"

############################# Grabaciones en CD ########################################

cdrecordburnfree="driveropts=burnfree"
cdrecordburnfreev="-v driveropts=burnfree"

# Graba un CD-R/CD-RW como CD-Mixto (Datos + Audio)
cdrecordmixcd2="-pad -audio"
# a cdrecordmixcd1 le precede dev=$IDE speed=$Velocidad
cdrecordmixcd1="driveropts=burnfree -v -dao -eject"
# Graba archivos .wav del disco duro a CD-R/CD-RW. Usa raw96, de K3B 2.0.2
# precede a cdrecordwav2cd2, dev=$IDE speed=$Velocidad
cdrecordwav2cd2="-raw96r driveropts=burnfree -eject -useinfo -audio -pad -shorttrack"
cdrecordwav2cd1="gracetime=2" 
# Graba archivos .wav extraidos de un CD-Audio con cdda2wav
# a cdrecordcdda2wavwavcd2 precede dev=$IDE speed=$Velocidad
cdrecordcdda2wavwavcd2="-dao driveropts=burnfree -eject -useinfo -audio -pad -shorttrack"
cdrecordcdda2wavwavcd1=$cdrecordwav2cd1
# Para la opción -C de genisoimage. Obtiene el tamaño de una pista de datos
# grabada en CD Multisesión, la posterior imagen iso-9660 generada empieza
# por el valor de los sectores obtenidos por wodim.
# Esta iso será la que se grabe en el CD Multisesión.
# Ejecución en subshell: wodim -msinfo dev=ATAPI:$CANALATAPI
cdrecordcdtpistamulti1="-msinfo dev=ATAPI"
# Graba una imagen iso-9660 en CD-R/CD-RW dejando este disponible para grabaciones multisesión
# a cdrecordisocdmulti1 le precede dev=$IDE speed=$Velocidad
cdrecordisocdmulti1="driveropts=burnfree -v -eject -multi -data"
# Fuerza el borrado completo de un CD-RW
# a cdrecordcdrwferascomp2 le precede speed=$Velocidad
cdrecordcdrwferascomp2="-eject blank=all -force"
# a cdrecordcdrwferascomp1 le precede dev=$IDE
cdrecordcdrwferascomp1=$cdrecordburnfreev
# Borrado completo de CD-RW
# a cdrecordcdrwerascomp2 le precede speed=$Velocidad
cdrecordcdrwerascomp2="-eject blank=all"
# a cdrecordcdrwerascomp1 le precede dev=$IDE
cdrecordcdrwerascomp1=$cdrecordburnfree
# Fuerza el Borrado rápido de un CD-RW
# a cdrecordcdrwferas2 le precede speed=$Velocidad
cdrecordcdrwferas2="-eject blank=fast -force"
# a cdrecordcdrwferas1 le precede dev=$IDE
cdrecordcdrwferas1=$cdrecordburnfree
# Borrado rápido de CD-RW
# a cdrecordcdrweras2 le precede speed=$Velocidad
cdrecordcdrweras2="-eject blank=fast"
# a cdrecordcdrweras1 le precede dev=$IDE
cdrecordcdrweras1=$cdrecordburnfreev
# Muestra información de la unidad
cdrecordminf1="-minfo"
# Cierra la sesión de un CD-R o CD-RW
# precede dev=$IDE speed=$Velocidad
cdrecordfixcd1="-v -fix -eject"
# Grabación de CD-R/CD-RW al vuelo, modo clonación. De K3B 17.12.3
# a cdrecordclonefly1 le precede $cdrecordcdonfly1 dev=$IDE speed=$Velocidad
# antecede el archivo de imagen generado con readcd.
cdrecordcdclonefly1="-raw96r driveropts=burnfree -clone -overburn"
# Grabación de CD-R/CD-RW al vuelo. De K3B 17.12.3
# a cdrecordcdonfly2 le antecede el informe del número de sectores
# totales del disco origen (leadout) al parámetro tsize, mas $LECTOR_CDROM
cdrecordcdonfly2="-sao $cdrecordburnfree -data -tsize="
cdrecordcdonfly1="-v gracetime=2"
# Grabacion de CD-R/CD-RW al vuelo, con overburn activado.
# a cdrecordcdonflyoverburn2 le antecede lo mismo que ha cdrecordcdonfly2 
cdrecordcdonflyoverburn2="-sao $cdrecordburnfree -overburn -data -tsize="
# a cdrecordcdonflyoverburn1 le precede dev=$IDE
cdrecordcdonflyoverburn1=$cdrecordcdonfly1
# Graba imagen iso-9660 en CD-R/CD-RW
cdrecordwimgcd2=" -dao -eject -data"
cdrecordwimgcd1=" driveropts=burnfree -v" 
# Graba imagen iso-9660 en CD-R/CD-RW, overburn activado
cdrecordwimgcdoverburn2=" -dao -overburn -eject -data"
cdrecordwimgcdoverburn1=" $cdrecordburnfreev"
# Escanea el puerto IDE/SCSI con cdrecord, precede dev=$IDE
cdrecordscop1="-scanbus"
# Grabaciones con wodim
lingrcdburn1="wodim"
# Graba una imagen .bin .cue en CD-R/CD-RW
cdrdaowimgbincue2="--driver generic-mmc --speed"
cdrdaowimgbincue1="write --device"
# Graba un CD-R/RW  de datos o audio al vuelo.
# CD Audio o CD Mixto.
cdrdaocdaonfly4="--buffers 64 --reload --eject --on-the-fly --fast-toc --paranoia-mode 0"
# CD de datos.
cdrdaocdonfly4="--buffers 64 --reload --eject --on-the-fly --fast-toc"
cdrdaocdonfly3="--speed"
cdrdaocdonfly2="--source-device"
cdrdaocdonfly1="copy -v 2 --device"
# Grabaciones con cdrdao
lingrcdburn2="cdrdao"
# Borra un CD-RW, se aplica el borrado necesario
cdrskincdrwerase2="blank=as_needed -eject"
cdrskincdrwerase1="-v"
# Graba imagen iso9660 en CD/DVD
cdrskiniso2od2=" -dao"
cdrskiniso2od1="-v"
# Grabaciones con cdrskin
lingrcdburn3="cdrskin"

############################# Grabaciones en DVD #######################################

# Graba una sola sesion con growisofs
gus="-Z"

# Graba un DVD de datos iso-9660 con extensiones HFS, Rock Ridge y Joliet (mkisofs)
growisofshfsrocjol1s6=" -hide-rr-moved -path-list "
growisofshfsrocjol1s5="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -iso-level"
growisofshfsrocjol1s4="-mac-name -r -joliet-long -verbose -V"
growisofshfsrocjol1s3="-graft-points -pad -J -l -apple -hfs-volid"
growisofshfsrocjol1s2="-use-the-force-luke=notray -use-the-force-luke=tty -use-the-force-luke=dao -dvd-compat"
growisofshfsrocjol1s1=$gus
# Soporte para genisoimage
growisofsgenhfsrocjol1s="-hide-rr-moved -allow-limited-size -path-list"
# Graba un DVD de datos iso-9660 con extensiones Rock Ridge y Joliet (mkisofs)
growisofsrocjol1s6=$growisofshfsrocjol1s6
growisofsrocjol1s5=$growisofshfsrocjol1s5
growisofsrocjol1s4="-r -joliet-long -verbose -V"
growisofsrocjol1s3="-graft-points -pad -J -l"
growisofsrocjol1s2=$growisofshfsrocjol1s2
growisofsrocjol1s1=$gus
# Soporte para genisoimage
growisofsgenrocjol1s=$growisofsgenhfsrocjol1s
# Graba imagen iso en DVD+-R/RW, precede growisofs -Z
growisofswimgdvd1="-dvd-compat -use-the-force-luke=notray -use-the-force-luke=tty -use-the-force-luke=dao -use-the-force-luke=spare:none"
# Graba DVD de Video (DVD 9), precede growisofs -Z
# a growisofsdvdvideo2 le precede -speed=$Velocidad"
growisofsdvdvideo2="-dvd-compat -dvd-video"
# a growisofsdvdvideo1 le precede -Z
growisofsdvdvideo1="-use-the-force-luke=tty"
# Grabacion en DVD-R/RW con growisofs
lingrdvdburn1="growisofs"
# Formatea un DVD-RW a incremental secuencial
dvdrwformatfful="-force=full"
# Formatea DVD-RW a sobreescritura restringida
dvdrwformatbful="-blank=full"
# Relocaliza el bloque lead-out en un DVD+RW
dvdrwformatlout="-lead-out"
# Fuerza el formato de un DVD+RW
dvdrwformatforce="-force"
# Formateador de DVD+-RW con dvd+rw-format
lingrdvdburn2="dvd+rw-format"
# Muestra informacion de disco
lingrdvdburn3="dvd+rw-mediainfo"
# Graba una imagen iso-9660 en DVD, overburn activado
cdrecordwimgdvdov="$cdrecordwimgcdoverburn1 $cdrecordwimgcdoverburn2"
# Formatea DVD+-RW con cdrecord
# a cdrecordformatdvd le prece dev=$IDE speed=$Velocidad
cdrecordformatdvd="-format -v -eject"
# Grabacion en DVD+-RW con Wodim
lingrdvdburn4=$lingrcdburn1
# Formatea un DVD-RW a Incremental secuencial.
cdrskinfdvdrwis="blank=deformat_sequential"
# Muestra información de la unidad
cdrskininfdev="-minfo"
# Lista los dispositivos de grabación existentes en el sistema
cdrskinlistd="--devices"
# Grabacion em DVD+-RW con cdrskin
lingrdvdburn5=$lingrcdburn3

########################### Grabaciones en Blu-Ray Disc ###################################

# Grabaciones con growisofs
lingrbdburn1=$lingrdvdburn1
# Información con dvd+rw-mediainfo
lingrbdburn2=$lingrdvdburn3
# Grabaciones con cdrskin
lingrbdburn3=$lingrcdburn3

################################### Creacion de Imagenes ##################################

# Para las imagenes multisesion con genisoimage
mkisoMop="-M"
# Genera una imagen .bin .cue desde CD, precede cdrdao
cdrdaogimgbincue2="--device"
cdrdaogimgbincue1="read-cd --read-raw --datafile"
# iso cd de datos multisesion, grabación de iso continuando sesión en CD-R/CD-RW
# a mkisocddatmulti5 le precede $NIVEL_ISO
mkisocddatmulti5="-path-list"
# a mkisocddatmulti4 le precede ATAPI:$IDE
mkisocddatmulti4="-iso-level"
mkisocddatmulti3=" -M"
mkisocddatmulti2="-C"
mkisocddatmulti1="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -hide-rr-moved -graft-points -pad -o"
# Fichero salida genisoimage
mkisofsfsop1="-o"
# iso cd de datos con metadatos RockRidge, Joliet
mkisofscddat4="-path-list"
mkisofscddat3="-iso-level"
mkisofscddat2="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -hide-rr-moved -graft-points -pad -o"
genisoimagefscddatap2="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -volset-size 1 -volset-seqno 1 -hide-rr-moved -allow-limited-size -graft-points -pad -o"
mkisofscddat1="-J -r -l -joliet-long -verbose -V"
# iso cd de datos con metadatos RockRidge, Joliet y Apple
mkisofscddatap5=$mkisofscddat4
mkisofscddatap4=$mkisofscddat3
genisoimagefscddatap1="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -hide-rr-moved -allow-limited-size -graft-points -pad -o"
mkisofscddatap3="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -hide-rr-moved -graft-points -pad -o"
mkisofscddatap2="-mac-name -joliet-long -verbose -V"
mkisofscddatap1="-J -r -l -apple -hfs-volid"
# iso directorios de datos
mkisofsisodir1="-A \"LINUX-CDGRAB_1.0\" -sysid LINUX -volset-size 1 -volset-seqno 1 -hide-rr-moved -graft-points -pad -o"
# Imagenes UDF hibridas con iso-9660 (genisoimage)
mkisofsudfop1="-udf"
# Muestra la version de genisoimage
mkisofsver="-version"
# Imagenes UDF para DVD Video.
mkisofsbdv="-dvd-video -udf"
# iso cd/dvd/bd de datos desde ficheros del disco duro con xorriso, metadatos joliet
xorrisocddat3="-joliet on -add"
xorrisocddat2="-volid"
xorrisocddat1="-outdev"
# Crea imagenes .iso (ISO-9660), genisoimage
lingrmkimg2="genisoimage"
# Crea imagenes .iso (ISO-9660), xorriso
lingrmkimg3="xorriso"
# Crea imagenes con dd (coreutils)
# Genera imagen iso-9660 desde discos ópticos
# imagen iso-9660 desde CD-ROM
gcdisodd1="conv=noerror,sync"
# imagen iso-9660 desde DVD-ROM
gdvdisodd1="bs=2048 conv=noerror,sync"
# Genera y escribe imagen .img desde o a un dispositivo de bloque, sectores de 2048
ddop5="count="
ddop4="conv=sync;sync"
ddop3="conv=noerror,sync"
ddop2="of="
ddop1="if="
ddblksz="bs=2048"
# Referencia al dispositivo /dev/zero, Genera archivo vacio
DEVZero="if=/dev/zero"
gdd="dd"
# Escribe imagen iso autoarranclable en pendrive o tarjeta flash
ddblkszp="bs="
ddisodb1="conv=fsync"
# Conversor imagenes .nrg (Nero) en iso-9660
# Comprueba imagenes .nrg para su conversion en iso
ddnrgcd100op1="count=1"
ddnrgcd100="dd bs=1024 skip=32"
# Convierte .nrg en iso
ddbgr2isoop1="conv=noerror"
ddnrg2iso="dd bs=1024 skip="
# Fin-dd
# Comprobacion de código hash en archivos
lingrmd5="md5sum -t"
lingrb2="b2sum -t"
lingrsha1="sha1sum -t"
lingrsha224="sha224sum -t"
lingrsha256="sha256sum -t"
lingrsha384="sha384sum -t"
lingrsha512="sha512sum -t"

##################################### Formato Imagenes y Unidades #####################################

# Formatea unidad en ext2
mke2fsuop1="-m 0 -L"
# Formatea un archivo vacio en ext2
mke2fsop1="-t ext2 -m 0 -b"
# ext2 (Second Extended)
lingrfrext2="mke2fs"
# Formatea unidad en ext3
mkfsext3uop3="-o LINUX"
mkfsext3uop2="-b"
mkfsext3uop1="-t ext3 -L"
# Formatea un archivo vacio en ext3
mkfsext3op3=$mkfsext3uop3
mkfsext3op2=$mkfsext3uop2
mkfsext3op1="-t ext3 -c"
# ext3 (Three extended)
lingrfext3="mkfs.ext3"
# Formatea unidad en ext4
mkfsext4op3=$mkfsext3uop3
mkfsext4op2=$mkfsext3uop2
mkfsext4op1="-t ext4 -L"
# Formatea un archivo vacio en ext4, precede mke2fs
mke2fsext4="-t ext4 -m 0 -b"
# ext4 (Four extended)
lingrfext4="mkfs.ext4"
# Formatea unidad en XFS
mkfsxfsop1="-f -L"
# XFS (XFS File System)
lingrfxfs="mkfs.xfs"
# Formatea unidad en JFS
mkfsjfsop1="-L"
# JFS (Journal File System)
lingrfjfs="mkfs.jfs"
# Formatea unidad en Btrfs
mkfsbtrfsop1="-f -L"
# BTRFS (Be Tree FS)
lingrfbtrfs="mkfs.btrfs"
# Formatea unidad en NTFS
mkfsntfsop1="-f -L"
# NTFS (New Technology File System)
lingrfntfs="mkfs.ntfs"
# Formatea unidad en vfat
mkfsvfatop1="-n"
# vfat (FAT32: File Allocation Table)
lingrfvfat="mkfs.vfat"
# Formatea unidad en exFAT 
mkfsexfatop1="-n"
# exFAT (Extended File Allocation Table)
lingrfexfat="mkexfatfs"

################################ Montar y Desmontar Unidades e Imagenes ###############################

# Opciones para montar archivo vacío ext2, ext3, ext4, xfs, jfs y btrfs. Precede mount
mfimgop3="-t"
mfimgop2="-o loop"
mfimgop1="-t="
# Monta una unidad
lingrmdisc1="mount"
# Monta una imagen de CD/DVD/BD
lingrmimg1="mount -o loop"
# Desmonta unidad
lingrumount1="umount"
# Expulsa disco de la unidad
ejectop1="-vrsfq"
lingreject="eject"

######################################### Archivos Comprimidos ########################################

# Empaqueta con tar
lingrpkg="tar"
lingrpkggz="tar -cvzf"
lingrpkgbz2="tar -cvjf"
lingrpkgbz2p="tar -cvyf"

# Compresores de archivo
lingrcompgz="gzip -9"
lingrcompbz2="bzip2"
lingrcompxz="xz -z"

# Descompresores de archivo
lingrdcompgz="gunzip -v"
lingrdcompbz2="bunzip2 -v"
lingrdcompzip="unzip"
lingrdcompxz="xz --decompress"

######################################### Herramientas usadas #########################################

APPBURN="wodim icedax cdrdao growisofs dvd+rw-format dvd+rw-mediainfo cdrskin"
APPISOF="genisoimage xorriso"
APPFMTD="mke2fs mkfs.ext3 mkfs.ext4 mkfs.xfs mkfs.jfs mkfs.btrfs mkfs.ntfs mkfs.vfat mkexfatfs"
APPFCOM="bzip2 gzip xz bunzip2 gunzip unzip"
APPAUDC="lame oggenc oggdec flac sox"
APPVIDC="ffmpeg"
