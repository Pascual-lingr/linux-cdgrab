#########################################################
# lcgdrabMenu_API/lcdgrabUIIMAGENESCDDVD.sh
# Menú de Interfaz para la creación y tratado de imágenes
# de CD, DVD y BD.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

################################# OPCIONES DE CREACIÓN DE IMÁGENES ################################
###################################################################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIIMAGENESCDDVD.idiom

# MenuImagen
# Menu , Creación de imágenes ISO-9660, imágenes .img e imágenes con sistemas de ficheros de linux.

MenuImagen(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do
	
	if test -f $HOME/rutas_lcdgrab.txt;then
		rm -f $HOME/rutas_lcdgrab.txt
	fi


case $UD in
0)	

	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA IMG MENU" \
	--menu "$MenuImagen_MSG1" 19 80 20 \
	1 "$MenuImagen_MSG3" \
	2 "$MenuImagen_MSG4" \
	3 "$MenuImagen_MSG5" \
	4 "$MenuImagen_MSG6 $IDE" \
	5 "$MenuImagen_MSG8" \
	6 "$MenuImagen_MSG9" \
	7 "$MenuImagen_MSG10" \
	8 "$MenuImagen_MSG11" \
	9 "Hash Code File" \
	MI "$MenuImagen_MSG12" \
	0 "$MenuImagen_MSG0" 2>"${INPUT}"
	modoimagen="$(<${INPUT})"
;;

1)
	cabecera
	printf "    $MenuImagen_MSG1\n"
	printf "==================================================\n\n"
	echo -e "${C_ET} $MenuImagen_MSG2 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "1.-$MenuImagen_MSG3"
	echo "2.-$MenuImagen_MSG4"
	echo "3.-$MenuImagen_MSG5"
	echo "4.-$MenuImagen_MSG6 $IDE"
	echo -e "${C_ET} $MenuImagen_MSG7 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "5.-$MenuImagen_MSG8"
	echo "6.-$MenuImagen_MSG9"
	echo "7.-$MenuImagen_MSG10"
	echo "8.-$MenuImagen_MSG11"
	echo "9.-Hash Code File"
	echo ""
	echo "--------->> MI: $MenuImagen_MSG12"
	echo ""
	echo "0.-$MenuImagen_MSG0"

	read modoimagen

;;

2)
	modoimagen=$(zenity --width=200 --height=375 --title="$PROGRAMA" --entry --text="
$MenuImagen_MSG1
$MenuImagen_MSG2
1.-$MenuImagen_MSG3
2.-$MenuImagen_MSG4
3.-$MenuImagen_MSG5
4.-$MenuImagen_MSG6 $IDE
$MenuImagen_MSG7
5.-$MenuImagen_MSG8
6.-$MenuImagen_MSG9
7.-$MenuImagen_MSG10
8.-$MenuImagen_MSG11
9.-Hash Code File
MI: $MenuImagen_MSG12
0.-$MenuImagen_MSG0")
;;

3)
	modoimagen=$(kdialog --menu "$MenuImagen_MSG1" \
1 "1-$MenuImagen_MSG3" \
2 "2-$MenuImagen_MSG4" \
3 "3-$MenuImagen_MSG5" \
4 "4-$MenuImagen_MSG6 $IDE" \
5 "5-$MenuImagen_MSG8" \
6 "6-$MenuImagen_MSG9" \
7 "7-$MenuImagen_MSG10" \
8 "8-$MenuImagen_MSG11" \
9 "9-Hash Code File" \
MI "MI-$MenuImagen_MSG12" \
0 "0-$MenuImagen_MSG0" --geometry=600x390 --title "$PROGRAMA")
;;


esac

case $modoimagen in

	1)
	imagenISO
	;;
	
	2)
	clear
	imagen_linux_fs
	;;

	3)
	imagen_img
	;;

	4)
	ImagenbincueCDDVD
	;;

	5)
	GenerarArchivocue
	;;

	6)
	nrg_a_iso
	;;

	7)
	MSG=$MenuImagen_MSG13
	gestor_de_archivos $MSG
	
	obten_cadena "$MenuImagen_MSG14" "$MenuImagen_MSG15"
	imagen=$lacadena

	comprime $imagen

	rm -f $D_LINUXCDGRAB/lcdgrabimgcomp.$$ &> /dev/null

	;;

	8)
	MSG=$MenuImagen_MSG16
	gestor_de_archivos $MSG
	descomprime
	;;

	9)
	imagen_LeerCodigoHash
	;;

	0)
	break
	;;

	"MI")

	clear
	cabecera
	echo "$MenuImagen_MSG17 : $NIVEL_ISO"
	echo -e "${C_ET} $MenuImagen_MSG18 1${COLOR_DEL_INTERFAZ}"
	echo "-----------"
	echo $MenuImagen_MSG19
	echo $MenuImagen_MSG20
	echo $MenuImagen_MSG21
	echo $MenuImagen_MSG21b
	echo -e "${C_ET} $MenuImagen_MSG18 2${COLOR_DEL_INTERFAZ}"
	echo "-----------"
	echo $MenuImagen_MSG22
	echo -e "${C_ET} $MenuImagen_MSG18 3${COLOR_DEL_INTERFAZ}"
	echo "-----------"
	echo $MenuImagen_MSG23
	echo $MenuImagen_MSG24
	echo $MenuImagen_MSG25
	echo "-----------"



	echo $MenuImagen_MSG26
	echo $MenuImagen_MSG27
	echo $MenuImagen_MSG28
	echo $MenuImagen_MSG29
	echo -n "$MenuImagen_MSG30 : "
	read op

		case $op in

		1|2|3|4)
	
			if test $op -eq 4;then
		
				echo -e "${C_AV}"
				echo $MenuImagen_MSG31
				echo $MenuImagen_MSG32
				echo -e "${COLOR_DEL_INTERFAZ}"
				sleep 2
			fi
		
			NIVEL_ISO="$op"
		;;

		*)
			echo $MenuImagen_MSG33
			echo $MenuImagen_MSG34
			sleep 1.0
		;;
	
		esac
		
	;;

	*)

        	mui_Opcion_invalida

	;;
esac

[ -f $INPUT ] && rm $INPUT &> /dev/null

done

colores_interfaz

}

