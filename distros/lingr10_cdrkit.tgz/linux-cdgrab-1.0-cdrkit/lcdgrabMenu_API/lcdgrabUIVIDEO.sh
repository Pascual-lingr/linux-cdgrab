#########################################################
# lcgdrabMenu_API/lcdgrabUIVIDEO.sh
# Menú de Interfaz para la conversión de Video.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

####################### CONVERSION DE VIDEO ####################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIVIDEO.idiom

# menu_conversion_video

menu_conversion_video(){

INPUT=${D_TMP}/vmenu.sh.$$

clear

while $verdadero;do

case $UD in
0)

dialog --clear --no-cancel --ok-label "OK" --backtitle  "-++ $PROGRAMA ++-" \
--title "$PROGRAMA VIDEO MENU" \
--menu "$menu_conversion_video_MSG1" 15 70 20 \
1 "$menu_conversion_video_MSG3" \
2 "$menu_conversion_video_MSG7" \
3 "$menu_conversion_video_MSG9" \
4 "$menu_conversion_video_MSG10" \
5 "$menu_conversion_video_MSG11" \
6 "$menu_conversion_video_MSG6" \
0 "$menu_conversion_video_MSG0" 2>"${INPUT}"
opcv=$(<"${INPUT}")

;;

1)

cabecera
printf "\t\t$menu_conversion_video_MSG1\n"
printf "==================================================\n"
echo -e "${C_ET}$menu_conversion_video_MSG2${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
printf "1.- $menu_conversion_video_MSG3\n"
printf "2.- $menu_conversion_video_MSG7\n"
echo -e "${C_ET}$menu_conversion_video_MSG8${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
printf "3.- $menu_conversion_video_MSG9\n"
printf "4.- $menu_conversion_video_MSG10\n"
printf "5.- $menu_conversion_video_MSG11\n"
printf "6.- $menu_conversion_video_MSG6\n"
printf "\n"
printf "0.- $menu_conversion_video_MSG0\n"
read opcv

;;

2)
opcv=$(zenity --width=300 --height=250 --title="$PROGRAMA" --entry --text="
$menu_conversion_video_MSG1
$menu_conversion_video_MSG2
1.- $menu_conversion_video_MSG3
2.- $menu_conversion_video_MSG7
$menu_conversion_video_MSG8
3.- $menu_conversion_video_MSG9
4.- $menu_conversion_video_MSG10
5.- $menu_conversion_video_MSG11
6.- $menu_conversion_video_MSG6
0.- $menu_conversion_video_MSG0")

;;

3)
opcv=$(kdialog --menu "$menu_conversion_video_MSG1" \
1 "1- $menu_conversion_video_MSG3" \
2 "2- $menu_conversion_video_MSG7" \
3 "3- $menu_conversion_video_MSG9" \
4 "4- $menu_conversion_video_MSG10" \
5 "5- $menu_conversion_video_MSG11" \
6 "6.-$menu_conversion_video_MSG6" \
0 "0- $menu_conversion_video_MSG0" --geometry=710x260 --title "$PROGRAMA")
;;

esac

case $opcv in

	1)	
		MSG=$menu_conversion_video_MSG4
		gestor_de_archivos $MSG
		conv_video_BDVideo
	;;

	2)
		conv_VideoFich
	;;

	3)
		mezcla_Audio_Video
	;;

	4)
		extrae_Audio_de_Video
	;;

	5)
		extrae_Fragmento_Video
	;;

	6)
		graba_escritorio
	;;

	0)
		break
	;;
	
	*)
        	mui_Opcion_invalida
	;;
	
esac

[ -f $INPUT ] && rm -f $INPUT &> /dev/null

done

}

