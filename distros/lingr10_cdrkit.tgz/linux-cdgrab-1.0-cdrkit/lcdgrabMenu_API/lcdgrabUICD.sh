#########################################################
# lcgdrabMenu_API/lcdgrabUICD.sh
# Menú de Interfaz para la grabación de CD.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

#######################  GRABACIONES EN CD ######################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUICD.idiom

# clonar
# submenu, copias directas de CDs de datos

clonar(){

INPUT=${D_TMP}/menu.sh.$$

clonecdmsg="$clonar_MSG8
$clonar_MSG9
$clonar_MSG10
$clonar_MSG11"

clear

while $verdadero;do

case $UD in
	0)

		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" --title "$PROGRAMA CLON CD" --msgbox "$clonecdmsg" 11 74

		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA CD MENU" \
		--menu "$clonar_MSG12B" 13 70 14 \
		1 "$clonar_MSG3 -> cdrkit" \
		2 "$clonar_MSG6 -> cdrkit" \
		3 "$clonar_MSG6 -> cdrdao" \
		4 "$clonar_MSG7B -> cdrdao" \
		0 "$clonar_MSG0" 2>"${INPUT}"
		modoclonar=$(<"${INPUT}")
	;;

	1)
		cabecera
		printf "\t\t$clonar_MSG1\n"
		printf "==================================================\n"
		echo -e "${C_ET} $clonar_MSG2 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
		echo "1.- $clonar_MSG3 -> cdrkit"
		echo -e "${C_AV}    $clonar_MSG4 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
		echo -e "${C_ET} $clonar_MSG5 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
		echo "2.- $clonar_MSG6 -> cdrkit **"
		echo "3.- $clonar_MSG6 -> cdrdao **"
		echo "4.- $clonar_MSG7B -> cdrdao **"
		echo -e "${C_AV}"
		echo "**"
		echo $clonar_MSG8
		echo $clonar_MSG9
		echo $clonar_MSG10
		echo $clonar_MSG11
		echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		echo "0.- $clonar_MSG0"

		read modoclonar
	;;

	2)
	
		zenity --title="$PROGRAMA" --info --text="$clonecdmsg" --width=500 --height=200
		
		modoclonar=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="
$clonar_MSG2
1) $clonar_MSG3 -> cdrkit
2) $clonar_MSG6 -> cdrkit
3) $clonar_MSG6 -> cdrdao
4) $clonar_MSG7B -> cdrdao
0) $clonar_MSG0
	")

	;;

	3)

		kdialog --msgbox "$clonecdmsg" --title="$PROGRAMA"

		modoclonar=$(kdialog --menu "$clonar_MSG1" \
1 "1- $clonar_MSG3 -> cdrkit" \
2 "3- $clonar_MSG6 -> cdrkit" \
3 "4- $clonar_MSG6 -> cdrdao" \
4 "5- $clonar_MSG7B -> cdrdao" \
0 "0- $clonar_MSG0" \
--geometry=620x260 --title="$PROGRAMA")

	;;
esac

case $modoclonar in

1)
copia_bin
;;

2)
datos_al_vuelo
;;

3)
datos_al_vuelo_cdrdao
;;

4)
audio_al_vuelo_cdrdao
;;

0)
break
;;

*)

mui_Opcion_invalida
;;

esac

[ -f $INPUT ] && rm -rf $INPUT &> /dev/null

done

}

# mgrabacd
#
# submenú para grabar CD de datos desde ficheros
# del disco duro.

mgrabacd(){

INPUT=${D_TMP}/menu.sh.$$
export mgrabacd_MSG2="$(echo $mgrabacd_MSG2 | sed 's/cdrtools/cdrkit/g')"

clear

while $verdadero;do

	case $UD in
		0)

			dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
			--title "$PROGRAMA CD MENU" \
			--menu "$mgrabacd_MSG1" 10 75 21 \
			1 "$mgrabacd_MSG2" \
			2 "$mgrabacd_MSG3" \
			0 "$mgrabacd_MSG4" 2>"${INPUT}"
			cddathd="$(<${INPUT})"
		;;

		1)
			cabecera
			printf "\t$mgrabacd_MSG1\n"
			printf "==================================================\n"
			printf "1.- $mgrabacd_MSG2\n"
			printf "2.- $mgrabacd_MSG3\n"
			printf "\n"
			printf "0.- $mgrabacd_MSG4\n"
			printf "\n"
			echo -n "$mgrabacd_MSG5 : "
			read cddathd
			printf "\n"

		;;

		2)
			cddathd=$(zenity --width=50 --height=150 --title="$PROGRAMA" --entry --text="
$mgrabacd_MSG1
1) $mgrabacd_MSG2
2) $mgrabacd_MSG3
0) $mgrabacd_MSG4

	")
		;;

		3)

			cddathd=$(kdialog --menu "$mgrabacd_MSG1" \
1 "1- $mgrabacd_MSG2" \
2 "2- $mgrabacd_MSG3" \
0 "0- $mgrabacd_MSG4" \
--geometry=660x180 --title="$PROGRAMA")

		;;
	esac

	case $cddathd in 

		1)
			cabecera
			datos
		;;

		2)
			datoslb
		;;
		
		0)
			break
		;;

		*)
			mui_Opcion_invalida
		;;
	esac

	[ -f $INPUT ] && rm -rf $INPUT &> /dev/null

done

}

# mgrabaimg
#
# submenú para grabar imagenes iso en CD-R/RW

mgrabacdimg(){

INPUT=${D_TMP}/menu.sh.$$
export mgrabaimg_MSG2="$(echo $mgrabaimg_MSG2 | sed 's/cdrtools/cdrkit/g')"

clear

while $verdadero;do

	case $UD in
		0)

			dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
			--title "$PROGRAMA CD MENU" \
			--menu "$mgrabaimg_MSG1" 10 75 21 \
			1 "$mgrabaimg_MSG2" \
			2 "$mgrabaimg_MSG3" \
			0 "$mgrabaimg_MSG4" 2>"${INPUT}"
			imgacdr="$(<${INPUT})"
		;;

		1)
			clear
			cabecera
			printf "\t$mgrabaimg_MSG1\n"
			printf "==================================================\n"
			printf "1.- $mgrabaimg_MSG2\n"
			printf "2.- $mgrabaimg_MSG3\n"
			printf "\n"
			printf "0.- $mgrabaimg_MSG4\n"
			printf "\n"
			echo -n "$mgrabaimg_MSG5 : "
			read imgacdr
			printf "\n"

		;;

		2)
			imgacdr=$(zenity --width=50 --height=150 --title="$PROGRAMA" --entry --text="
$mgrabaimg_MSG1
1) $mgrabaimg_MSG2
2) $mgrabaimg_MSG3
0) $mgrabaimg_MSG4")

		;;

		3)

			imgacdr=$(kdialog --menu "$mgrabaimg_MSG1" \
1 "1- $mgrabaimg_MSG2" \
2 "2- $mgrabaimg_MSG3" \
0 "0- $mgrabaimg_MSG4" \
--geometry=620x180 --title="$PROGRAMA")

		;;

	esac

	case $imgacdr in 

		1)
			clear
			cabecera
			grabimg
		;;

		2)
			grabimglb
		;;
		
		0)
			break
		;;

		*)
			mui_Opcion_invalida
		;;
	esac

	[ -f $INPUT ] && rm -rf $INPUT &> /dev/null

done

}

# mgrabararchivosaudio
# submenú para la grabación de CD-Audio desde archivos
# en disco. Soportados los formatos .wav, .mp3, .ogg y .flac

mgrabararchivosaudio(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

	case $UD in
		0)

			dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
			--title "$PROGRAMA CD MENU" \
			--menu "$mgrabararchivosaudio_MSG5" 13 60 14 \
			1 "$mgrabararchivosaudio_MSG1" \
			2 "$mgrabararchivosaudio_MSG2" \
			3 "$mgrabararchivosaudio_MSG3" \
			4 "$mgrabararchivosaudio_MSG4" \
			0 "$mgrabararchivosaudio_MSG0" 2>"${INPUT}"
			ophd2cd="$(<${INPUT})"
		;;

		1)
			cabecera
			printf "\t$mgrabararchivosaudio_MSG5\n"
			printf "==================================================\n"
			printf "1.- $mgrabararchivosaudio_MSG1\n"
			printf "2.- $mgrabararchivosaudio_MSG2\n"
			printf "3.- $mgrabararchivosaudio_MSG3\n"
			printf "4.- $mgrabararchivosaudio_MSG4\n"
			printf "\n"
			printf "0.- $mgrabararchivosaudio_MSG0\n"
			printf "\n"
			echo -n "$mgrabararchivosaudio_MSG0B : "
			read ophd2cd
			printf "\n"
		;;

		2)
			ophd2cd=$(zenity --width=50 --height=150 --title="$PROGRAMA" --entry --text="
$mgrabararchivosaudio_MSG5
1) $mgrabararchivosaudio_MSG1
2) $mgrabararchivosaudio_MSG2
3) $mgrabararchivosaudio_MSG3
4) $mgrabararchivosaudio_MSG4
0) $mgrabararchivosaudio_MSG0")
		;;

		3)

ophd2cd=$(kdialog --menu "$mgrabararchivosaudio_MSG5" \
1 "1- $mgrabararchivosaudio_MSG1" \
2 "2- $mgrabararchivosaudio_MSG2" \
3 "3- $mgrabararchivosaudio_MSG3" \
4 "4- $mgrabararchivosaudio_MSG4" \
0 "0- $mgrabararchivosaudio_MSG0" \
--geometry=550x230 --title="$PROGRAMA")

		;;

	esac

#
# Opciones
#

case $ophd2cd in

		1)
		cabecera
		wav_a_cd
		;;

		2)
		clear
		mp3_a_cd
		;;

		3)
		clear
		ogg_a_cd
		;;

		4)
		clear
		flac_a_cd
		;;

		0)
		break
		;;

		*)

        	mui_Opcion_invalida
		;;
esac

	[ -f $INPUT ] && rm -rf $INPUT &> /dev/null

done


}

# menugrabar_cd
#
# Menú de grabación en CD

menugrabar_cd(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

	if test -f $HOME/rutas_lcdgrab.txt;then
		rm -f $HOME/rutas_lcdgrab.txt
	fi

	case $UD in 
		0)

			dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
			--title "$PROGRAMA CD MENU" \
			--menu "$menugrabar_cd_MSG1" 21 65 20 \
			1 "$menugrabar_cd_MSG3" \
			2 "$menugrabar_cd_MSG4" \
			3 "$menugrabar_cd_MSG5" \
			4 "$menugrabar_cd_MSG6" \
			5 "$menugrabar_cd_MSG7" \
			6 "$menugrabar_cd_MSG9" \
			7 "$menugrabar_cd_MSG18" \
			8 "$menugrabar_cd_MSG14" \
			9 "$menugrabar_cd_MSG15" \
			10 "$menugrabar_cd_MSG16" \
			11 "$menugrabar_cd_MSG17" \
			0 "$menugrabar_cd_MSG0" 2>"${INPUT}"
			opcion="$(<${INPUT})"
		;;

		1)
			cabecera
			printf "\t\t$menugrabar_cd_MSG1\n"
			printf "==================================================\n"
			echo -e "${C_ET}$menugrabar_cd_MSG2${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
			echo "1.- $menugrabar_cd_MSG3"
			echo "2.- $menugrabar_cd_MSG4"
			echo "3.- $menugrabar_cd_MSG5"
			echo "4.- $menugrabar_cd_MSG6"
			echo "5.- $menugrabar_cd_MSG7"
			echo -e "${C_ET}$menugrabar_cd_MSG8${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
			echo "6.- $menugrabar_cd_MSG9"
			echo "7.- $menugrabar_cd_MSG18"
			echo -e "${C_ET}$menugrabar_cd_MSG13${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
			echo "8.- $menugrabar_cd_MSG14"
			echo "9.- $menugrabar_cd_MSG15"
			echo "10.- $menugrabar_cd_MSG16"
			echo "11.- $menugrabar_cd_MSG17"
			echo "0.-  $menugrabar_cd_MSG0"
			echo ""
			echo -n "$menugrabar_cd_MSGPRINCIPAL : "
			read opcion
			echo ""

		;;

		2)
			opcion=$(zenity --width=75 --height=150 --title="$PROGRAMA" --entry --text="
$menugrabar_cd_MSG1
$menugrabar_cd_MSG2
1) $menugrabar_cd_MSG3
2) $menugrabar_cd_MSG4
3) $menugrabar_cd_MSG5
4) $menugrabar_cd_MSG6
5) $menugrabar_cd_MSG7
$menugrabar_cd_MSG8
6) $menugrabar_cd_MSG9
7) $menugrabar_cd_MSG18
$menugrabar_cd_MSG13
8) $menugrabar_cd_MSG14
9) $menugrabar_cd_MSG15
10) $menugrabar_cd_MSG16
11) $menugrabar_cd_MSG17
0) $menugrabar_cd_MSG0")
		;;

		3)
			opcion=$(kdialog --menu "$menugrabar_cd_MSG1" \
1 "1- $menugrabar_cd_MSG3" \
2 "2- $menugrabar_cd_MSG4" \
3 "3- $menugrabar_cd_MSG5" \
4 "4- $menugrabar_cd_MSG6" \
5 "5- $menugrabar_cd_MSG7" \
6 "6- $menugrabar_cd_MSG9" \
7 "7- $menugrabar_cd_MSG18" \
8 "8- $menugrabar_cd_MSG14" \
9 "9- $menugrabar_cd_MSG15" \
10 "10- $menugrabar_cd_MSG16" \
11 "11- $menugrabar_cd_MSG17" \
0 "0- $menugrabar_cd_MSG0" \
--geometry=600x420 --title="$PROGRAMA")
		;;
	esac

	case $opcion in

		1)
		clear
		clonar $LECTOR_CDROM
		;;

		2)
		mgrabacd
		;;

		3)
		cd_multi
		;;

		4)
		mgrabacdimg
		;;
		
		5)
		cabecera
		grabimg_cue
		;;

		6)
		cabecera
		copia_cd_audio
		;;

		7)
		mgrabararchivosaudio
		;;

		8)
		clear
		cdmixto
		;;

		9)
		borra
		;;

		10)
		cabecera
		cerrar_cd
		;;

		11)
		discoinfo
		;;

		0)
		break
		;;

		*)

        	mui_Opcion_invalida
		;;

	esac

	[ -f $INPUT ] && rm -rf $INPUT &> /dev/null
done

}

