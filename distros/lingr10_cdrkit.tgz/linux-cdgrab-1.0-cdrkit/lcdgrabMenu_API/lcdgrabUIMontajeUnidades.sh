#########################################################
# lcgdrabMenu_API/lcdgrabUIMontajeUnidades.sh
# Menú de Interfaz para montar imágenes 
# iso, ext2, ext3, ext4, reiserfs.
# Menu para montar CD/DVD/BD.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIMontajeUnidades.idiom

# montar_dispositivos
# Acepta como argumento $LECTOR_CDROM
# MONTA O DESMONTA DISPOSITIVOS DE BLOQUE

montar_dispositivos(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

case $UD in
0)

	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA" \
	--menu "$montar_dispositivos_MSG1B" 15 65 25 \
	1 "$montar_dispositivos_MSG3" \
	2 "$montar_dispositivos_MSG4" \
	3 "$montar_dispositivos_MSG5" \
	4 "$montar_dispositivos_MSG6" \
	5 "$montar_dispositivos_MSG7" \
	0 "$montar_dispositivos_MSG0" 2>"${INPUT}"
	mopc="$(<${INPUT})"

;;

1)
	clear
	cabecera

	echo -e "${C_ET} $montar_dispositivos_MSG1 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_ET}------------------------------------------------- ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	mount | grep -v 'none' | grep -v '/sys' | grep -v '/run' | grep -v '/proc'
	echo -e "${C_ET}------------$montar_dispositivos_MSG2------------- ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo ""
	echo "1.- $montar_dispositivos_MSG3"
	echo "2.- $montar_dispositivos_MSG4"
	echo "3.- $montar_dispositivos_MSG5"
	echo "4.- $montar_dispositivos_MSG6"
	echo "5.- $montar_dispositivos_MSG7"
	echo ""
	echo "0.- $montar_dispositivos_MSG0"

	read mopc

;;

2)

	mopc=$(zenity --width=350 --height=100 --title="$PROGRAMA" --entry --text="
$montar_dispositivos_MSG1B
1.- $montar_dispositivos_MSG3
2.- $montar_dispositivos_MSG4
3.- $montar_dispositivos_MSG5
4.- $montar_dispositivos_MSG6
5.- $montar_dispositivos_MSG7
0.- $montar_dispositivos_MSG0")
;;

3)

	mopc=$(kdialog --menu "$montar_dispositivos_MSG1B" \
1 "1- $montar_dispositivos_MSG3" \
2 "2- $montar_dispositivos_MSG4" \
3 "3- $montar_dispositivos_MSG5" \
4 "4- $montar_dispositivos_MSG6" \
5 "5- $montar_dispositivos_MSG7" \
0 "0- $montar_dispositivos_MSG0" --geometry=570x270 --title "$PROGRAMA")
;;

esac

case $mopc in

	1)

		#expulsa el CD/DVD/BD

		expulsar_medio $LECTOR_CDROM
		
		continue
	;;

	2)

		#expulsa el cd/dvd/bd de la grabadora

		expulsar_medio $IDE
		
		continue
	;;

	3)	# montar CD-ROM

		if mount $LECTOR_CDROM $MNT/cdrom || mount -t iso9660 $LECTOR_CDROM $MNT/cdrom;then

			# se ha montado bien el CD

			echo "$montar_dispositivos_MSG8 $MNT/cdrom"
			sleep 1
			ls -l $MNT/cdrom
			echo "$montar_dispositivos_MSG9"
			read xxxPxxx

		else

			pinta_mensaje ${C_FA} "$montar_dispositivos_MSG10 $MNT/cdrom"

		fi

	;;

	4)	#desmontar CD-ROM

		if umount $MNT/cdrom;then
			pinta_mensaje ${C_OK} $montar_dispositivos_MSG11
		else
			pinta_mensaje ${C_FA} $montar_dispositivos_MSG12
		fi
	;;

	5)
		cabecera
		echo -e "${C_AV}${FONDO_INTERFAZ}$montar_dispositivos_MSG1${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		mount | grep -v 'cgroup' | grep -v 'tmpfs'
		echo ""
		echo $montar_dispositivos_MSG13
		read dispositivo
		echo ""
		echo $montar_dispositivos_MSG14
		read punto_mnt

		if ! test -b $dispositivo;then
			echo -e "${C_FA}"
			echo "ERROR : $dispositivo $montar_dispositivos_MSG15"
			echo -e "${COLOR_DEL_INTERFAZ}"
		fi

		if ! test -d $punto_mnt || test "$punto_mnt" = "";then
			echo -e "${C_FA}ERROR : $montar_dispositivos_MSG16 $punto_mnt ${COLOR_DEL_INTERFAZ}"
			echo "$montar_dispositivos_MSG17 $D_MNT"
			punto_mnt=$D_MNT
		fi

		echo ""

		echo $montar_dispositivos_MSG18
		echo "-------------"
		echo "M o m -- > $montar_dispositivos_MSG19 $dispositivo $montar_dispositivos_MSG20 $punto_mnt"
		echo "D o d -- > $montar_dispositivos_MSG21 $dispoditivo $montar_dispositivos_MSG22 $punto_mnt"
		read op

		case $op in

			"M" | "m" )

			if mount $dispositivo $punto_mnt;then
				echo ""
				echo -e "${C_OK} $dispositivo $montar_dispositivos_MSG23 $punto_mnt${COLOR_DEL_INTERFAZ}"
				ls -l $punto_mnt
			else
				echo ""
				echo -e "${C_FA} $montar_dispositivos_MSG24 $dispositivo $montar_dispositivos_MSG25 $punto_mnt${COLOR_DEL_INTERFAZ}"
			fi

			teclash

			;;

			"D" | "d" )

			if umount $dispositivo || umount $punto_mnt;then
				echo ""
				echo -e "${C_OK} $dispositivo $montar_dispositivos_MSG26 $punto_mnt${COLOR_DEL_INTERFAZ}"
				echo ""
			else
				echo ""
				echo -e "${C_FA}$montar_dispositivos_MSG27 $dispositivo $montar_dispositivos_MSG28 $punto_mnt${COLOR_DEL_INTERFAZ}"
				echo ""

			fi

			teclash
				;;

			esac

	;;
	
	0)
		break
	;;

	*)
        	mui_Opcion_invalida
	;;

esac

[ -f $INPUT ] && rm $INPUT

done

}

# Montar_Imagenes
# Monta o desmonta imágenes
# .iso , .ext2, .ext3, .ext4 y reiserfs

Montar_Imagenes(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

case $UD in
0)

	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA" \
	--menu "$Montar_Imagenes_MSG1B" 11 45 15 \
	1 "$Montar_Imagenes_MSG3" \
	2 "$Montar_Imagenes_MSG4" \
	0 "$Montar_Imagenes_MSG5" 2>"${INPUT}"
	op_mon="$(<${INPUT})"

;;

1)
	clear

	cabecera
	echo -e "${C_ET} $Montar_Imagenes_MSG1 : ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_ET} -------------------------- ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	mount | grep -v 'none' | grep -v '/sys' | grep -v '/run' | grep -v '/proc'
	echo ""
	echo -e "${C_ET} $Montar_Imagenes_MSG2${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_ET} ----------------${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "1.- $Montar_Imagenes_MSG3"
	echo "2.- $Montar_Imagenes_MSG4"
	echo ""
	echo "0.- $Montar_Imagenes_MSG5"

	read op_mon

;;

2)

	op_mon=$(zenity --width=300 --height=250 --title="$PROGRAMA" --entry --text="
$Montar_Imagenes_MSG1B
1.- $Montar_Imagenes_MSG3
2.- $Montar_Imagenes_MSG4
0.- $Montar_Imagenes_MSG5")
;;

3)
	op_mon=$(kdialog --menu "$Montar_Imagenes_MSG1B" \
1 "1- $Montar_Imagenes_MSG3" \
2 "2- $Montar_Imagenes_MSG4" \
0 "0- $Montar_Imagenes_MSG5" --geometry=380x190 --title "$PROGRAMA")
;;
esac

case $op_mon in

	1)

		monta_img
	;;

	2)

		desmonta_img
	;;

	0)

		break
	;;

	*)

		mui_Opcion_invalida
		continue

	;;

esac


[ -f $INPUT ] && rm -f $INPUT

done

}

