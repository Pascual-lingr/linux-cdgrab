#########################################################
# lcgdrabMenu_API/lcdgrabMainMenu.sh
# Colección de funciones para el programa principal.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabMainMenu.idiom

# imprimeIUcolor
# Imprime los colores por defecto del Interfaz de usuario

imprimeIUcolor(){

colores_por_defecto

echo -e "${COLOR_DEL_INTERFAZ}"
echo -e "${FONDO_INTERFAZ}"

}

# ayuda
# Muestra la Ayuda de LINUX-CDGRAB.

# modificada 13-10-2014, añadida la comprobación de vi en los directorios /bin y /usr/bin

ayuda(){

	editor_vi=""

# chequea /bin/vi y /usr/bin/vi

	if test -x /bin/vi;then
		editor_vi=/bin/vi
	fi

	if test -x /usr/bin/vi;then
		editor_vi=/usr/bin/vi
	fi

# los editores por defecto no estan instalados en el sistema.
# se da la posibilidad de abrir la ayuda con cualquiera existente.

	if test -z $editor_vi;then

		echo $ayuda_MSG1
		echo $ayuda_MSG2
		read editor

		if ($editor $D_LINUXCDGRAB/ayuda.txt);then
			echo ""
		else
			pinta_mensaje ${C_FA} $ayuda_MSG3

		fi
	else
		$editor_vi $D_LINUXCDGRAB/ayuda.txt
	fi

	colores_interfaz

}

# creacion_de_mnt
#
# Crea el archivo de aviso AVISO_PUNTO_DE_MONTAJE_CDROM.txt
# cuando se crea el directorio /mnt/cdrom

creacion_de_mnt(){	
	
cat << EOF >$MNT/AVISO_PUNTO_DE_MONTAJE_CDROM.txt

$creacion_de_mnt_MSG1

$creacion_de_mnt_MSG2 $MNT/cdrom $creacion_de_mnt_MSG3
$creacion_de_mnt_MSG4
$creacion_de_mnt_MSG5 $MNT/cdrom.

$creacion_de_mnt_MSG6
$creacion_de_mnt_MSG7 $MNT/cdrom $creacion_de_mnt_MSG8
$creacion_de_mnt_MSG9

$creacion_de_mnt_MSG10 $MNT/cdrom
$creacion_de_mnt_MSG11
$creacion_de_mnt_MSG12 $MNT/cdrom

$creacion_de_mnt_MSG13

EOF

}

# txtcreditos
#
# Creditos tradicionales en texto

txtcreditos(){

typeset local xcreditosx

    cabecera
    echo ${VERSIONPGM}

cat << ACERCA

$creditos_MSG1
$creditos_MSG2
		
$creditosinf_MSG3
		
$creditosinf_MSG4
$creditosinf_MSG5
$creditosinf_MSG6
ACERCA

    echo $main_lcdgrabopA_MSG1
    echo $InfNucleo
    read xcreditosx

}

# compcreditos
#
# Mensaje de creditos compuesto, usa cowsay

compcreditos(){

typeset local xcreditosx

cabecera
echo -e "${C_ET}"
cowsay "${VERSIONPGM} $creditos_MSG1; $creditos_MSG2; $creditosinf_MSG3; $creditosinf_MSG4; $creditosinf_MSG5; $creditosinf_MSG6"
echo -e "${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
echo $main_lcdgrabopA_MSG1
echo $InfNucleo
read xcreditosx

}

# creditos
#
# Imprime los créditos de Linux-cdgrab.
# Recibe $TipoVer como parámetro, para
# diferenciar la versión original o
# la versión clonada del programa.

creditos(){

if test $TipoVer -eq 0;then
    creditosinf_MSG3=$creditos_MSG3
    creditosinf_MSG4=$creditos_MSG4
    creditosinf_MSG5=$creditos_MSG5
    creditosinf_MSG6=""
    VERSIONPGM=${VERSION}
else
    creditosinf_MSG3=$creditosno_MSG3
    creditosinf_MSG4=$creditosno_MSG4
    creditosinf_MSG5=$creditosno_MSG5
    creditosinf_MSG6=$creditosno_MSGVSRC
    VERSIONPGM=${VERSIONNO}
fi

InfNucleo=" $(uname -a)"

clear

if test $UD -eq 0;then
    dialog --clear --colors --backtitle "\Z6-++ $PROGRAMA ++-\Z7-++ $PROGRAMA ++-\Z5-++ $PROGRAMA ++-\Z4-++ $PROGRAMA ++-\Z3-++ $PROGRAMA ++-\Z2-++ $PROGRAMA ++-\Z1-++ $PROGRAMA ++-\Z0-++ $PROGRAMA ++-" --title "\Z4$PROGRAMA" --msgbox "${VERSIONPGM} \

                                                                                                             $creditos_MSG1 \

                                                                                                             $creditos_MSG2 \

                                                                                                             $creditosinf_MSG3 \

                                                                                                             $creditosinf_MSG4 \

                                                                                                             $creditosinf_MSG5 \

                                                                                                             $creditosinf_MSG6 \

                                                                                                             $main_lcdgrabopA_MSG1 \
                                                                                                             
                                                                                                             $InfNucleo" 23 90


elif test $UD -eq 2;then

	zenity --title="$PROGRAMA" --info --text="
${VERSIONPGM}
$creditos_MSG1
$creditos_MSG2
$creditosinf_MSG3
$creditosinf_MSG4
$creditosinf_MSG5
$creditosinf_MSG6
$main_lcdgrabopA_MSG1
$InfNucleo" --width=600 --height=200

elif test $UD -eq 3;then

	kdialog --msgbox "${VERSIONPGM}
$creditos_MSG1
$creditos_MSG2
$creditosinf_MSG3
$creditosinf_MSG4
$creditosinf_MSG5
$creditosinf_MSG6
$main_lcdgrabopA_MSG1
$InfNucleo" --title="$PROGRAMA" --geometry=500x500

else

	if which "cowsay";then
		compcreditos
	else
		txtcreditos
	fi

fi

}

# exportar_variables
# Exporta variables al entorno

# exporta la grabadora de DVD,el NIVEL_ISO y los colores de la aplicación

exportar_variables(){

# exporta la velocidad de grabación

export Velocidad="$( cat $D_CFG/lcdgrab.cfg | grep -e 'VELOCIDAD.' | sed -e 's/VELOCIDAD//g' -e 's/ //g' -e 's/[=]//g')"

# exporta el dispositivo de grabación (tenga el valor que tenga, dispositivo de bloque o asignación numérica de tipo X.Y.Z)

export IDE="$( cat $D_CFG/lcdgrab.cfg | grep -e 'IDE.' | sed -e 's/IDE//g' -e 's/ //g' -e 's/[=]//g')"

# exporta el lector de CD-ROM o DVD-ROM

export LECTOR_CDROM="$( cat $D_CFG/lcdgrab.cfg | grep -e 'LECTOR_CDROM.' | sed -e 's/LECTOR_CDROM//g' -e 's/ //g' -e 's/[=]//g')"

# exporta el dispositivo asignado a dev=ATAPI, variable CANALATAPI

export CANALATAPI="$( cat $D_CFG/lcdgrab.cfg | grep -e 'CANALATAPI.' | sed -e 's/CANALATAPI//g' -e 's/ //g' -e 's/[=]//g')"
# exporta el nivel ISO (por defecto vale 3)

export NIVEL_ISO

# exporta la grabadora de DVD usada para las dvd+-rw-tools
# si existe. En este caso IDE tiene un valor del tipo X.Y.Z

if ! test -z $grabadora_dvd;then
	export grabadora_dvd
fi

# exporta los colores.

export NEGRO
export ROJO
export VERDE
export AMARILLO
export AZUL
export MAGENTA
export CIAN
export GRIS
export DEFECTO
export STANDAR
export B_NEGRO
export B_ROJO
export B_VERDE
export B_AMARILLO
export B_AZUL
export B_MAGENTA
export B_CIAN
export B_BLANCO
export FONDO_NEGRO
export FONDO_ROJO
export FONDO_VERDE
export FONDO_NARANJA
export FONDO_AZUL
export FONDO_MAGENTA
export FONDO_CIAN
export FONDO_GRIS
export FONDO_DEFECTO
export C_OK
export C_FA
export C_AV
export C_ET
export TipoVer
export IDSISTEMA
export utiliso
export metadatosisoapple

}


# Resuelve_Interfaz_Usuario
#
# Selecciona el modo en que se  
# muestra los interfaces de menú.
# Comandos:
# dialog, echo, zenity y kdialog.

Resuelve_Interfaz_Usuario(){

if test -z $DISPLAY;then

 	# La aplicación se ejecuta bajo un terminal en texto
	# Se comprueba el uso de dialog o mensajes de texto

	if which "dialog" &> /dev/null;then

		# se usa dialog
		UD=0
	else

		# se usa texto
		UD=1
	fi		
else

	# DISPLAY tendrá un valor como :0 o bien :0.0 o bien
	# otra numeración según la configuración del sistema.

	# La aplicación se ejecuta bajo un terminal desde 
	# el entorno gráfico (Xorg)

	case $1 in

		"ncurses")

			# Interfaz de menús con ncurses

			if which "dialog" &> /dev/null;then

				# se usa dialog
				UD=0
			else

				# se usa texto
				UD=1
			fi	
		;;

		"gtk")

			# Interfaz gráfica con GTK

			if which "zenity"  &> /dev/null;then
				# se usa zenity
				UD=2
			else
				# no se encuentra zenity
				# resuelve el uso con dialog o mensajes de texto
				if which "dialog" &> /dev/null;then
					# se usa dialog
					UD=0
				else
					# se usa texto
					UD=1
				fi
			fi
		;;

		"Qt")

			# Interfaz gráfica con Qt

			if which "kdialog"  &> /dev/null;then
				# se usa kdialog
				UD=3
			else
				# no se encuentra kdialog
				# resuelve el uso con dialog o mensajes de texto
				if which "dialog" &> /dev/null;then
					# se usa dialog
					UD=0
				else
					# se usa texto
					UD=1
				fi
			fi
		;;

		*)
			
			# Interfaz gráfica con Qt, GTK, ncurses o texto

			if which "kdialog"  &> /dev/null;then
				# se usa kdialog
				UD=3
			elif which "zenity" &> /dev/null;then
				# se usa zenity
				UD=2
			else
				# no se encuentra kdialog
				# resuelve el uso con dialog o mensajes de texto
				if which "dialog" &> /dev/null;then
					# se usa dialog
					UD=0
				else
					# se usa texto
					UD=1
				fi
			fi
		;;

	esac


fi
	
export UD

}

# establece_gestor_de_archivos
#
# Establece el gestor de archivos que 
# sera usado en la aplicación

establece_gestor_de_archivos(){

if test -x $D_BIN/mc;then
    export usarmc=1
else
    export usarmc=0
fi

}

# chkmnt_genera_mnt
#
# verifica si /mnt/cdrom existe, si no, crea el directorio

chkmnt_genera_mnt(){

    if ! test -d $MNT/cdrom;then

	    mkdir $MNT &> /dev/null	
	    mkdir $MNT/cdrom
	    creacion_de_mnt

    fi

    

}

# resuelve_cdrtools
#
# Emulación de wodim y genisoimage con xorriso.

resuelve_cdrtools(){

if ! test -x $D_BIN/wodim && ! test -x $D_BIN/genisoimage && test -x $D_BIN/xorriso;then
		# En el sistema no esta wodim ni genisoimage, pero existe xorriso
		cp ${D_LINUXCDGRAB}/lcdgrabCoreAPP/wodim $D_BIN
		chmod +x $D_BIN/wodim
		cp ${D_LINUXCDGRAB}/lcdgrabCoreAPP/genisoimage $D_BIN
		chmod +x $D_BIN/genisoimage		

		echo -e "${C_AV} xorriso emul wodim/genisoimage ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		sleep 2
fi

}

# Inicia_LINUXCDGRAB

Inicia_LINUXCDGRAB(){

## VARIABLES

# El modo iso usado por mkisofs para crear las imagenes ISO-9660.
# Consultar página man.

NIVEL_ISO="3"

# Opción de elección sobre el comando generador de iso para CD/DVD
# utiliso=1 --> opera con dd utiliso=2 --> opera con readcd

utiliso=1

# Establece si en la generación de imagenes ISO-9660
# se crean metadatos para apple junto con RockRidge y Joliet.
# Solo metadatos RockRidge y Joliet por defecto.

metadatosisoapple=0

# Se sustituye por sha256 en la version debian_cdrkit

# Establece si se lee la suma md5 de una imagen iso generada
# leermd5si = 0 para leer. Un valor distinto no hace el proceso.

#leermd5si=1
#leersha256si=1

## FIN VARIABLES

# Muestra los colores por defecto usados en ejecución

imprimeIUcolor			

# Crea el directorio /mnt/cdrom si no existe

chkmnt_genera_mnt

# Establece el gestor de archivos usado por defecto

establece_gestor_de_archivos

# En esta versión solo resolverá la emulación con libburnia

resuelve_cdrtools

# verifica si el fichero de configuración existe
# si no existe se crea uno nuevo

clear

if test -f $D_CFG/lcdgrab.cfg;then
	leer_lcdgrabcfg
else
	nuevo_lcdgrabcfg
fi

}

# cargar_parche
# Carga parches para linux - cdgrab

# Especificarle el nombre del parche

cargar_parche(){

cabecera
echo $main_lcdgrabopdeppatch_MSG1
echo "###################"
echo ""
ls $D_PARCHES/*.sh
	
echo $main_lcdgrabopdeppatch_MSG2
read parche

echo "$cargar_parche_MSG1 $parche"
sleep 1

exportar_variables

$D_PARCHES/$parche

}

# logo
# imprime el logo

logo(){
colores_interfaz
clear
cat $D_LINUXCDGRAB/logo.txt
echo ""
read xx

}

# lcdgrab_sintaxis
# Imprime la sintaxis de lcdgrab

lcdgrab_sintaxis(){

cat << EOF
$lcdgrab_sintaxis_MSG1 :
lcdgrab [-v]|[-h]|[-iut]|[-ium]|[-iug]|[-iuk]|[-G=$lcdgrab_sintaxis_MSG12][-V=$lcdgrab_sintaxis_MSG13][-L=$lcdgrab_sintaxis_MSG12][-CA=$lcdgrab_sintaxis_MSG12][[-iut]|[-ium]|[-iug]|[-iuk]]

-h  --help , $lcdgrab_sintaxis_MSG2
-v  --version , $lcdgrab_sintaxis_MSG3
-G  --grabadora , $lcdgrab_sintaxis_MSG4 -G=0,1,0 $lcdgrab_sintaxis_MSG5 -G=/dev/hdd
-V  --velocidad , $lcdgrab_sintaxis_MSG6 -V=32
-L  --lector , $lcdgrab_sintaxis_MSG7 -L=/dev/cdrom
-CA --canal-atapi , $lcdgrab_sintaxis_MSG8 -CA=0,0,0 o -CA=1,0,0
-iut --iu-text, $lcdgrab_sintaxis_MSG14
-ium --iu-ncurses, $lcdgrab_sintaxis_MSG15
-iug --iu-gtk, $lcdgrab_sintaxis_MSG16 
-iuk --iu-qt, $lcdgrab_sintaxis_MSG17

$lcdgrab_sintaxis_MSG9
$lcdgrab_sintaxis_MSG9B
$lcdgrab_sintaxis_MSG9C
$lcdgrab_sintaxis_MSG10

$lcdgrab_sintaxis_MSG11
lcdgrab -G=0,1,0 -L=/dev/hdc -V=16 -CA=0,1,0
lcdgrab -G=0,0,0 -L=/dev/hdd -V=32 -CA=0,0,0 -iut
lcdgrab --grabadora=/dev/hdd --lector=/dev/cdrom --velocidad=32 --canal-atapi=1,0,0 --iu-text
lcdgrab -ium
lcdgrab --iu-ncurses
lcdgrab --help
lcdgrab --version
EOF

}

# err_lcdgrab_sintaxis
#
# Informa de error en los argumentos pasados a lcdgrab

err_lcdgrab_sintaxis(){

	echo -e "${ROJO}ERROR: lcdgrab $@ ${STANDAR}"
	echo -e "${ROJO}$@ $main_arg_MSG1 ${STANDAR}"
	echo ""
	lcdgrab_sintaxis
	exit 1

}

# depura_lcdgrab
#
# Ejecuta linux-cdgrab en modo depuración

depura_lcdgrab(){

	if test -x $D_BIN/lcdgrab;then

		bash -x $D_BIN/lcdgrab
	else
		echo ""
		echo $main_lcdgrabopdep_MSG1
		read r_script

		if ! [ -z $r_script ];then
			bash -x $r_script
		else
			echo $main_lcdgrabopdep_MSG2
			sleep 0.5
		fi
		
	fi

}

# depura_parche
#
# depura un parche para linux-cdgrab

depura_parche(){

	cabecera
	echo $main_lcdgrabopdeppatch_MSG1
	echo "###################"
	echo ""
	ls $D_PARCHES/*.sh
	
	echo $main_lcdgrabopdeppatch_MSG2
	read r_parche

	if test -x $r_parche;then

		bash -x $r_parche && exportar_variables
		
	else
		echo "$main_lcdgrabopdeppatch_MSG3 $r_parche"
		teclash
	fi

}

# consultarVersion
#
# consulta la versión de la aplicación

consultarVersion(){

	if test $TipoVer -eq 0;then
		echo "$VERSION"
	else
		echo "$VERSIONNO"
	fi

	echo ""

}

# Instancia_LINUXCDGRAB
#
# Muestra el menú principal de la aplicación

Instancia_LINUXCDGRAB(){

Inicia_LINUXCDGRAB

### Menu principal de la aplicacion.
# Imprime el menu principal en pantalla.
# Pide seleccion de opciones al usuario.

while $verdadero;do

	MSG=$MSG1_MAIN

	exportar_variables

	case $UD in
		1)
			lcdgrabmainmenutext
		;;

		2)
			lcdgrabmainmenuzenity
		;;

		3)
			lcdgrabmainmenukdialog
		;; 

		0)
			lcdgrabmainmenudialog
		;;
	esac

done

}

# lcdgrabmainmenukdialog
#
# Implementación del menú principal de la aplicación
# con el comando kdialog

lcdgrabmainmenukdialog(){

mainopcion="NA"

clear

mainopcion=$(kdialog --menu "$PROGRAMA" \
1 "1- $main_lcdgrabop1" \
2 "2- $main_lcdgrabop2" \
3 "3- $main_lcdgrabop3" \
4 "4- $main_lcdgrabop4" \
5 "5- $main_lcdgrabop5" \
6 "6- $main_lcdgrabop6" \
7 "7- $main_lcdgrabop6b" \
8 "8- $main_lcdgrabop7" \
9 "9- $main_lcdgrabop8" \
10 "10- $main_lcdgrabop9uidia" \
11 "11- $main_lcdgrabop10" \
E "E- $main_lcdgrabopEe" \
TD "TD- $main_lcdgrabopTD $D_TMP" \
G "G- $main_lcdgrabopG" \
H "H- $main_lcdgrabopH" \
A "A- $main_lcdgrabopA" \
0 "0- $main_lcdgrabop0" \
--geometry=500x550 --title="$PROGRAMA")

lcdgrabmainmenutextopt $mainopcion

}

# lcdgrabmainmenuzenity
#
# Implementación del menú principal de la aplicación
# con el comando zenity

lcdgrabmainmenuzenity(){

mainopcion="LINUX-CDGRAB"

clear

mainopcion=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="
1) $main_lcdgrabop1
2) $main_lcdgrabop2
3) $main_lcdgrabop3
4) $main_lcdgrabop4
5) $main_lcdgrabop5
6) $main_lcdgrabop6
7) $main_lcdgrabop6b
8) $main_lcdgrabop7
9) $main_lcdgrabop8
10) $main_lcdgrabop9uidia
11) $main_lcdgrabop10
E) $main_lcdgrabopEe
TD) $main_lcdgrabopTD $D_TMP
G) $main_lcdgrabopG
H) $main_lcdgrabopH
A) $main_lcdgrabopA
0) $main_lcdgrabop0")

lcdgrabmainmenutextopt $mainopcion

}

# lcdgrabmainmenudialog
#
# Implementación del menú principal de la aplicación
# con el comando dialog

lcdgrabmainmenudialog(){

INPUT=${D_TMP}/menu.sh.$$

OUTPUT=${D_TMP}/output.sh.$$

clear

while  [[ $UD -eq 0 ]]
do

dialog --clear --no-cancel --ok-label "OK" \
--colors --backtitle "\Z6-++ $PROGRAMA ++-" \
--title "\Z4$PROGRAMA" \
--menu "" 23 57 23 \
1 "$main_lcdgrabop1" \
2 "$main_lcdgrabop2" \
3 "$main_lcdgrabop3" \
4 "$main_lcdgrabop4" \
5 "$main_lcdgrabop5" \
6 "$main_lcdgrabop6" \
7 "$main_lcdgrabop6b" \
8 "$main_lcdgrabop7" \
9 "$main_lcdgrabop8" \
10 "$main_lcdgrabop9uidia" \
11 "$main_lcdgrabop10" \
E "$main_lcdgrabopEe" \
TD "$main_lcdgrabopTD $D_TMP" \
G "$main_lcdgrabopG" \
H "$main_lcdgrabopH" \
A "$main_lcdgrabopA" \
0 "$main_lcdgrabop0" 2>"${INPUT}"
mainopcion=$(<"${INPUT}")

lcdgrabmainmenutextopt $mainopcion $OUTPUT
done

rm -rf $INPUT $OUTPUT &> /dev/null

}

# lcdgrabmainmenutext
#
# Implementación del menu principal en texto

lcdgrabmainmenutext(){


echo -e "$FONDO_INTERFAZ"
echo -e "$COLOR_DEL_INTERFAZ"

clear

printf "=================================================\n"
printf "=\t\t$PROGRAMA\t\t=\n"
printf "=\t\t----------------\t\t=\n"
printf "=================================================\n"
printf "=  1.- $main_lcdgrabop1_text\n"
printf "=  2.- $main_lcdgrabop2_text\n"
printf "=  3.- $main_lcdgrabop3_text\n"
printf "=  4.- $main_lcdgrabop4_text\n"
printf "=  5.- $main_lcdgrabop5_text\n"
printf "=  6.- $main_lcdgrabop6_text\n"
printf "=  7.- $main_lcdgrabop6b_text\n"
printf "=  8.- $main_lcdgrabop7_text\n"
printf "=  9.- $main_lcdgrabop8_text\n"
printf "=  10.- $main_lcdgrabop9_text\n"
printf "=  11.- $main_lcdgrabop10_text\n"
printf "=  0.- $main_lcdgrabop0_text\n"
printf "=================================================\n"
printf "=\t\t## $main_lcdgrabet1_text\n"
printf "=  -->> E o e: $main_lcdgrabopEe_text\n"
if test $D_TMP == "/Depot";then
 if test $IDIOM == ".defecidiom" || test $IDIOM == "Español" || test $IDIOM == "EspDefNA";then
	tabs="\t="
 fi
fi
printf "=  -->> TD: $main_lcdgrabopTD_text $D_TMP $tabs\n"
printf "=  -->> G: $main_lcdgrabopG_text\n"
printf "=  -->> H: $main_lcdgrabopH_text\n"
printf "=  -->> A: $main_lcdgrabopA_text\n"
printf "=================================================\n"

echo -n "		$main_lcdgrabopPRINCIPAL  "
read mainopcion

lcdgrabmainmenutextopt $mainopcion

}

# lcdgrabmainmenutextopt
#
# Ejecuta las opciones del programa principal

lcdgrabmainmenutextopt(){

case $mainopcion in
	1) menugrabar_cd;;
	2) SeleccionaIUDVD;;
	3) menu_grabar_BD;;
	4) MenuDispositivosBloque;;
	5) MenuImagen;;
	6) menu_conversion_audio;;
	7) menu_conversion_video;;
	8) montar_dispositivos $LECTOR_CDROM;;
	9) Montar_Imagenes;;
	10) cargar_parche;;
	11) centro_de_control;;

	E|e) expulsar_medio $IDE;;

	"TD") dir_tmp;;

	"dep")

		# ejecuta linux-cdgrab en modo de depuración 

		depura_lcdgrab

	;;

	"deppatch")
		
		# ejecuta un parche para linux-cdgrab en modo de depuración

		depura_parche

	;;

	"logo")
		# Imprime el logo

		logo
	;;

	"G")
		# lanza el gestor de archivos

		gestor_de_archivos $MSG
	;;

	"H")
		# muestra la ayuda

		clear
		ayuda
	;;

	"A")
		# Muestra los créditos

		clear
        	creditos $TipoVer

	;; 

	0)
		# sale del programa

		# borra temporales de GoboLinux
		if test -d /Depot;then
			rm -rf menu.sh.*
		fi

		# borra temporales
		rm -rf $D_LINUXCDGRAB/lcdgrabnombreruta.*
		rm -rf $D_LINUXCDGRAB/*comprimir*
		rm -rf $D_TMP/menu.sh.*

		#imprime el color estandar del shell
		export COLOR_DEL_INTERFAZ=$STANDAR
		echo -e "${COLOR_DEL_INTERFAZ}"
		clear
	
		exit
	;;

	*)
		mui_Opcion_invalida
	;;
esac

sleep 1
}
