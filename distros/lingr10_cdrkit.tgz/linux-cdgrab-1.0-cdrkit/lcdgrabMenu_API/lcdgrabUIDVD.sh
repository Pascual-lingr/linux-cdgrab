##########################################################
# lcdgrabMenu_API/lcdgrabUIDVD.sh
# Menú de Interfaz para la grabación de DVD.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

#########################  GRABACIONES EN DVD ############################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIDVD.idiom

# Selecciona el interaz de de usuario que sera usado en grabaciones DVD
# SeleccionaIUDVD

SeleccionaIUDVD(){

INPUT=${D_TMP}/menu.sh.$$

export SeleccionaIUDVD_MSG3="$(echo $SeleccionaIUDVD_MSG3 | sed 's/Cdrecord-ProDVD/Cdrkit/g')"

clear

while $ver;do

case $UD in
0)

	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA DVD MENU" \
	--menu "$SeleccionaIUDVD_MSG1" 12 65 10 \
	1 "$SeleccionaIUDVD_MSG2" \
	2 "$SeleccionaIUDVD_MSG3" \
	3 "$SeleccionaIUDVD_MSG4" \
	0 "$SeleccionaIUDVD_MSG5" 2>"${INPUT}"
	IUMOP="$(<${INPUT})"
;;

1)
	cabecera
	echo ""
	echo $SeleccionaIUDVD_MSG1
	echo ""
	echo "1.- $SeleccionaIUDVD_MSG2"
	echo "2.- $SeleccionaIUDVD_MSG3"
	echo "3.- $SeleccionaIUDVD_MSG4"
	echo ""
	echo "0.- $SeleccionaIUDVD_MSG5"

	read IUMOP
;;

2)
	IUMOP=$(zenity --width=300 --height=250 --title="$PROGRAMA" --entry --text="
$SeleccionaIUDVD_MSG1
1.- $SeleccionaIUDVD_MSG2
2.- $SeleccionaIUDVD_MSG3
3.- $SeleccionaIUDVD_MSG4
0.- $SeleccionaIUDVD_MSG5")

;;

3)
	IUMOP=$(kdialog --menu "$SeleccionaIUDVD_MSG1" \
1 "1- $SeleccionaIUDVD_MSG2" \
2 "2- $SeleccionaIUDVD_MSG3" \
3 "3- $SeleccionaIUDVD_MSG4" \
0 "0- $SeleccionaIUDVD_MSG5" --geometry=480x200 --title "$PROGRAMA")

;;

esac
	case $IUMOP in
		1)
			menugrabar_dvd
		;;

		2)
			menugrabar_DVD
		;;

		3)
			menugrabar_DVD_libburnia
		;;

		0)
			break
		;;

		*)
		        mui_Opcion_invalida
		;;
	esac

	[ -f $INPUT ] && rm $INPUT

done

}

############# Grabaciones usando el IU para dvd+-rw-tools ################

# menugrabar_dvd

menugrabar_dvd(){

MEDIO="DVD"
INPUT=${D_TMP}/menu.sh.$$

buscar_grabadora

clear
	
while $verdadero;do

if test -f $HOME/rutas_lcdgrab.txt;then
	rm -f $HOME/rutas_lcdgrab.txt
fi

case $UD in
0)

	dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
	--title "$PROGRAMA DVD MENU" \
	--menu "$menugrabar_dvd_MSG1" 15 60 40 \
	1 "$menugrabar_dvd_MSG3" \
	2 "$menugrabar_dvd_MSG5" \
	3 "$menugrabar_dvd_MSG8" \
	4 "$menugrabar_dvd_MSG11" \
	5 "$menugrabar_dvd_MSG13" \
	6 "$menugrabar_dvd_MSG14" \
	0 "$menugrabar_dvd_MSG0" 2>"${INPUT}"
	gdvdop=$(<"${INPUT}")
;;

1)
	cabecera
	printf "\t\t$menugrabar_dvd_MSG1\n"
	printf "==================================================\n\n"
	echo -e "${C_ET} $menugrabar_dvd_MSG2 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "1.- $menugrabar_dvd_MSG3"
	echo -e "   ${C_AV} $menugrabar_dvd_MSG4 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "2.- $menugrabar_dvd_MSG5"
	echo "3.- $menugrabar_dvd_MSG8"
	echo -e "${C_ET} $menugrabar_dvd_MSG10 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "4.- $menugrabar_dvd_MSG11"
	echo -e "${C_ET} $menugrabar_dvd_MSG12 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "5.- $menugrabar_dvd_MSG13"
	echo "6.- $menugrabar_dvd_MSG14"
	echo ""
	echo "0.- $menugrabar_dvd_MSG0"
	echo ""
	echo -n "$menugrabar_dvd_MSGPRINCIPAL : "
	read gdvdop
	echo ""
;;

2)

	gdvdop=$(zenity --width=425 height=400 --title="$PROGRAMA" --entry --text="
$menugrabar_dvd_MSG1
$menugrabar_dvd_MSG2
1.- $menugrabar_dvd_MSG3
$menugrabar_dvd_MSG4
2.- $menugrabar_dvd_MSG5
3.- $menugrabar_dvd_MSG8
$menugrabar_dvd_MSG10
4.- $menugrabar_dvd_MSG11
$menugrabar_dvd_MSG12
5.- $menugrabar_dvd_MSG13
6.- $menugrabar_dvd_MSG14
0.- $menugrabar_dvd_MSG0
$menugrabar_dvd_MSGPRINCIPAL")

;;

3)

	gdvdop=$(kdialog --menu "$menugrabar_dvd_MSG1" \
1 "1- $menugrabar_dvd_MSG3" \
2 "2- $menugrabar_dvd_MSG5" \
3 "3- $menugrabar_dvd_MSG8" \
4 "4- $menugrabar_dvd_MSG11" \
5 "5- $menugrabar_dvd_MSG13" \
6 "6- $menugrabar_dvd_MSG14" \
0 "0- $menugrabar_dvd_MSG0" \
--geometry=551x262 --title "$PROGRAMA")

;;

esac

	case $gdvdop in

		1)
			cabecera
			copia_bin_dvd
		;;

		2)
			MSG=$menugrabar_dvd_MSG15
			echo $menugrabar_dvd_MSG16
			sleep 1
			gestor_de_archivos $MSG

            		mui_rutas_dir

			clear
			datos_dvd
		;;

		3)
			MSG=$menugrabar_dvd_MSG17
			echo $menugrabar_dvd_MSG16
			sleep 1
			gestor_de_archivos
			cabecera
			echo $menugrabar_dvd_MSG18
			read imagen
			grabimg-dvd $imagen
		;;
		
		4)
			cabecera
			dvd_video
		;;

		5)

			clear
			formatear_dvd
		;;

		6)

			dvd_disc_info
		;;

		0)
			break
		;;
		
		*)

            		mui_Opcion_invalida

		;;
	esac

	[ -f $INPUT ] && rm $INPUT
		
done

}

############# Grabaciones usando el IU para Cdrecord-ProDVD ################

# menugrabar_DVD

menugrabar_DVD(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

	if test -f $HOME/rutas_lcdgrab.txt;then
		rm -f $HOME/rutas_lcdgrab.txt
	fi

	case $UD in	
	0)
		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA DVD MENU" \
		--menu "$menugrabar_DVD_MSG1" 14 65 20 \
		1 "$menugrabar_DVD_MSG3" \
		2 "$menugrabar_DVD_MSG4" \
		3 "$menugrabar_DVD_MSG5" \
		4 "$menugrabar_DVD_MSG6" \
		5 "$menugrabar_DVD_MSG7" \
		0 "$menugrabar_DVD_MSG0" 2>"${INPUT}"
		opcion="$(<${INPUT})"

	;;
	
	1)
	cabecera
	printf "\t\t$menugrabar_DVD_MSG1\n"
	printf "==================================================\n"
	printf "\n"
	echo -e "${C_ET}$menugrabar_DVD_MSG2${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "1.- $menugrabar_DVD_MSG3"
	echo -e "${C_AV}    $menugrabar_DVD_MSG8 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "2.- $menugrabar_DVD_MSG4"
	echo "3.- $menugrabar_DVD_MSG5"
	echo "4.- $menugrabar_DVD_MSG6"
	echo "5.- $menugrabar_DVD_MSG7"
	echo ""
	echo "0.- $menugrabar_DVD_MSG0"
	echo ""
	echo -n "$menugrabar_DVD_MSGPRINCIPAL : "
	read opcion
	printf "\n"

	;;

	2)
	opcion=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="
$menugrabar_DVD_MSG1
$menugrabar_DVD_MSG2
1.- $menugrabar_DVD_MSG3
$menugrabar_DVD_MSG8
2.- $menugrabar_DVD_MSG4
3.- $menugrabar_DVD_MSG5
4.- $menugrabar_DVD_MSG6
5.- $menugrabar_DVD_MSG7
0.- $menugrabar_DVD_MSG0
$menugrabar_DVD_MSGPRINCIPAL")
	;;

	3)
	opcion=$(kdialog --menu "$menugrabar_DVD_MSG1" \
1 "1- $menugrabar_DVD_MSG3" \
2 "2- $menugrabar_DVD_MSG4" \
3 "3- $menugrabar_DVD_MSG5" \
4 "4- $menugrabar_DVD_MSG6" \
5 "5- $menugrabar_DVD_MSG7" \
0 "0- $menugrabar_DVD_MSG0" --geometry=620x270 --title "$PROGRAMA")
	;;

	esac

	case $opcion in

		1)
		dvd_copia_bin $LECTOR_CDROM
		;;

		2)
		cabecera
		dvd_datos
		;;

		3)
		cabecera
		dvd_grabimg
		;;

		4)
		clear
		dvd_borra
		;;

		5)
		dvd_discoinfo
		;;

		0)
		break
		;;

		*)
        	mui_Opcion_invalida
		;;

	esac

[ -f $INPUT ] && rm $INPUT

done

}

############# Grabaciones usando el IU para cdrskin y xorriso (libburnia) ################

# menugrabar_DVD_libburnia
#
# Menú principal de grabación con cdrskin (libburnia)

menugrabar_DVD_libburnia(){

INPUT=${D_TMP}/menu.sh.$$

buscar_grabadoralb

clear

while $verdadero;do

  case $UD in
    0)

		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA DVD MENU" \
		--menu "$menugrabar_dvd_MSG1" 16 70 30 \
		1 "$menugrabar_DVD_MSG3" \
		2 "$menugrabar_DVD_libburnia_MSG1" \
		3 "$menugrabar_DVD_libburnia_MSG2" \
		4 "$menugrabar_DVD_libburnia_MSG3" \
		5 "$menugrabar_DVD_libburnia_MSG4" \
		6 "$menugrabar_DVD_libburnia_MSG6" \
		7 "$menugrabar_DVD_libburnia_MSG8" \
		0 "$menugrabar_DVD_libburnia_MSG0" 2>"${INPUT}"
		libburniaop="$(<${INPUT})"
    ;;

    1)
    cabecera
    echo "		$menugrabar_dvd_MSG1"
    echo "=================================================="
    echo ""
    echo -e "${C_ET}$menugrabar_dvd_MSG2 ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
    echo "1.- $menugrabar_DVD_MSG3"
    echo -e "${C_AV}    $menugrabar_DVD_MSG8 ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
    echo "2.- $menugrabar_DVD_libburnia_MSG1"
    echo "3.- $menugrabar_DVD_libburnia_MSG2"
    echo -e "${C_ET}$menugrabar_dvd_MSG12${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
    echo "4.- $menugrabar_DVD_libburnia_MSG3"
    echo "5.- $menugrabar_DVD_libburnia_MSG4"
    echo "6.- $menugrabar_DVD_libburnia_MSG6"
    echo "7.- $menugrabar_DVD_libburnia_MSG8"
    echo ""
    echo "0.- $menugrabar_DVD_libburnia_MSG0"
    echo ""
    echo "$menugrabar_DVD_libburnia_MSG7:"

    read libburniaop
    echo ""

    ;;

    2)

	libburniaop=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="
$menugrabar_DVD_MSG1
$menugrabar_DVD_MSG2
1.- $menugrabar_DVD_MSG3
$menugrabar_DVD_MSG8
2.- $menugrabar_DVD_libburnia_MSG1
3.- $menugrabar_DVD_libburnia_MSG2
$menugrabar_dvd_MSG12
4.- $menugrabar_DVD_libburnia_MSG3
5.- $menugrabar_DVD_libburnia_MSG4
6.- $menugrabar_DVD_libburnia_MSG6
7.- $menugrabar_DVD_libburnia_MSG8
0.- $menugrabar_DVD_libburnia_MSG0
$menugrabar_DVD_libburnia_MSG7")
    ;;

    3)

	libburniaop=$(kdialog --menu "$menugrabar_DVD_MSG1" \
1 "1- $menugrabar_DVD_MSG3" \
2 "2- $menugrabar_DVD_libburnia_MSG1" \
3 "3- $menugrabar_DVD_libburnia_MSG2" \
4 "4- $menugrabar_DVD_libburnia_MSG3" \
5 "5- $menugrabar_DVD_libburnia_MSG4" \
6 "6- $menugrabar_DVD_libburnia_MSG6" \
7 "7- $menugrabar_DVD_libburnia_MSG8" \
0 "0- $menugrabar_DVD_libburnia_MSG0" --geometry=700x320 --title "$PROGRAMA")
    ;;

  esac

    case $libburniaop in

	1)  # Copia un DVD de datos creando una imgen binaria con dd
	    dvd_copia_binlb
	;;

        2)  # Graba imagen iso-9660 con cdrskin
            cdrskinisocddvd
        ;;

	3)
	    # Graba datos del disco duro a un CD o DVD
	    # Genera una imagen iso-9660 previa
	    grabardatosHD
	;;

        4)  # Formatea CD, DVD y BD
            formatearCDDVDBD
        ;;

        5)
            # Formatea un DVD-RW en incremental secuencial
            formatearDVDRW_incremental_secuencial
        ;;

        6)
            # Muestra la información del disco y la grabadora
            grabadorainfo
        ;;

	7)
	    # Lista los dispositivos de grabación instalados en el sistema
	    listargrabadoras
	;;

        0)
            # Sale del menú
            break
        ;;

        *)
            # Gestiona elecciones incorrectas de menú
	    mui_Opcion_invalida
        ;;
    esac

[ -f $INPUT ] && rm $INPUT

done

}


