#########################################################
# lcgdrabMenu_API/lcdgrabUIAUDIO.sh
# Menú de Interfaz para la conversión de Audio.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

####################### CONVERSION DE AUDIO ####################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIAUDIO.idiom

# menu_conversion_audio

menu_conversion_audio(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

case $UD in
0)

dialog --clear --no-cancel --ok-label "OK" --backtitle  "-++ $PROGRAMA ++-" \
--title "$PROGRAMA AUDIO MENU" \
--menu "$menu_conversion_audio_MSG1" 20 55 20 \
1 "$menu_conversion_audio_MSG3" \
2 "$menu_conversion_audio_MSG4" \
3 "$menu_conversion_audio_MSG6B" \
4 "$menu_conversion_audio_MSG5" \
5 "$menu_conversion_audio_MSG6" \
6 "$menu_conversion_audio_MSG6C" \
7 "$menu_conversion_audio_MSG8" \
8 "$menu_conversion_audio_MSG9" \
9 "$menu_conversion_audio_MSG10" \
10 "$menu_conversion_audio_MSG11" \
11 "$menu_conversion_audio_MSG17" \
12 "$menu_conversion_audio_MSG16" \
0 "$menu_conversion_audio_MSG0" 2>"${INPUT}"
opca=$(<"${INPUT}")

;;

1)

cabecera
printf "\t\t$menu_conversion_audio_MSG1\n"
printf "==================================================\n"
echo -e "${C_ET}$menu_conversion_audio_MSG2${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
printf "1.- $menu_conversion_audio_MSG3\n"
printf "2.- $menu_conversion_audio_MSG4\n"
printf "3.- $menu_conversion_audio_MSG6B\n"
printf "4.- $menu_conversion_audio_MSG5\n"
printf "5.- $menu_conversion_audio_MSG6\n"
printf "6.- $menu_conversion_audio_MSG6C\n"
echo -e "${C_ET}$menu_conversion_audio_MSG7${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
printf "7.- $menu_conversion_audio_MSG8\n"
printf "8.- $menu_conversion_audio_MSG9\n"
printf "9.- $menu_conversion_audio_MSG10\n"
printf "10.- $menu_conversion_audio_MSG11\n"
printf "11.- $menu_conversion_audio_MSG17\n"
echo -e "${C_ET}$menu_conversion_audio_MSG15${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
printf "12.- $menu_conversion_audio_MSG16\n\n"
printf "0.- $menu_conversion_audio_MSG0\n"
read opca

;;

2)
opca=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="
$menu_conversion_audio_MSG1
$menu_conversion_audio_MSG2
1.- $menu_conversion_audio_MSG3
2.- $menu_conversion_audio_MSG4
3.- $menu_conversion_audio_MSG6B
4.- $menu_conversion_audio_MSG5
5.- $menu_conversion_audio_MSG6
6.- $menu_conversion_audio_MSG6C
$menu_conversion_audio_MSG7
7.- $menu_conversion_audio_MSG8
8.- $menu_conversion_audio_MSG9
9.- $menu_conversion_audio_MSG10
10.- $menu_conversion_audio_MSG11
11.- $menu_conversion_audio_MSG17
$menu_conversion_audio_MSG15
12.- $menu_conversion_audio_MSG16
0.- $menu_conversion_audio_MSG0")

;;

3)
opca=$(kdialog --menu "$menu_conversion_audio_MSG1" \
1 "1- $menu_conversion_audio_MSG3" \
2 "2- $menu_conversion_audio_MSG4" \
3 "3- $menu_conversion_audio_MSG6B" \
4 "4- $menu_conversion_audio_MSG5" \
5 "5- $menu_conversion_audio_MSG6" \
6 "6- $menu_conversion_audio_MSG6C" \
7 "7- $menu_conversion_audio_MSG8" \
8 "8- $menu_conversion_audio_MSG9" \
9 "9- $menu_conversion_audio_MSG10" \
10 "10- $menu_conversion_audio_MSG11" \
11 "11- $menu_conversion_audio_MSG17" \
12 "12- $menu_conversion_audio_MSG16" \
0 "0- $menu_conversion_audio_MSG0" --geometry=510x460 --title "$PROGRAMA")
;;

esac

case $opca in

	1)	
		MSG=$menu_conversion_audio_MSG12
		gestor_de_archivos $MSG
		mp3awav
	;;

	2)
		
		MSG=$menu_conversion_audio_MSG13		
		gestor_de_archivos
		oggawav
	;;

	3)
		flacawav
	;;

	4)	
		MSG=$menu_conversion_audio_MSG14	
		gestor_de_archivos
		wavamp3
	;;

	5)
		MSG=$menu_conversion_audio_MSG14		
		gestor_de_archivos
		wavaogg
	;;

	6)
		wavaflac
	;;

	7)	
		cdawav
	;;

	8)
		cddawav
		teclash
	;;

	9)
		cdamp3
	;;

	10)
		cdaogg
	;;

	11)
		cdaflac
	;;	

	12)
		corta_wav
	;;

	0)
		break
	;;
	
	*)
        
        	mui_Opcion_invalida

	;;
	
esac

[ -f $INPUT ] && rm -f $INPUT &> /dev/null

done

}

