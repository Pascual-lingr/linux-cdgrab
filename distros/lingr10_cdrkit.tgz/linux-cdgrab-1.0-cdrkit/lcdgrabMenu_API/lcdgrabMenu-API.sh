#########################################################
# lcgdrabMenu_API/lcdgrabMenu-API.sh
# 
# Carga los procedimientos de menú usados 
# en la aplicación.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

# Expande los procedimientos generales a lcdgrabCMD junto 
# con los comandos usados

source ${D_LINUXCDGRAB}/lcdgrabCMD_API/lcdgrabCMD-API.sh

# Expande los procedimientos de lcdgrabMenu_API

source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIIMAGENESCDDVD.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUICD.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIAUDIO.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIVIDEO.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIDVD.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIBD.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIMontajeUnidades.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIUnidadesDisco.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUICentroControl.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUICargaParches.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUIGestorArchivos.sh
source ${D_LINUXCDGRAB}/lcdgrabMenu_API/lcdgrabUITMPDIR.sh



