#########################################################
# lcgdrabMenu_API/lcdgrabUITMPDIR.sh
# Menú de Interfaz para gestionar los archivos de imagen
# almacenados en el directorio /tmp del sistema.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

############################### INTERFAZ PARA /tmp ############################
###############################################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUITMPDIR.idiom

# ver_ftmp
# Muestra los ficheros de imagen del directorio temporal
# Muestra ficheros comprimidos del directorio temporal

ver_ftmp(){
	ls $D_TMP/*.iso $D_TMP/*.udf $D_TMP/*.ext2 $D_TMP/*.gz $D_TMP/*.bz2 $D_TMP/*.xz $D_TMP/*.img $D_TMP/*.ext3 $D_TMP/*.ext4 $D_TMP/*.xfs $D_TMP/*.jfs $D_TMP/*.btrfs
}

# del_ftmp
# Borra los ficheros de imagen del directorio temporal
# Borra ficheros comprimidos del directorio temporal

del_ftmp(){
	rm -rf $D_TMP/*.iso $D_TMP/*.udf $D_TMP/*.ext2 $D_TMP/*.gz $D_TMP/*.bz2 $D_TMP/*.xz $D_TMP/*.img $D_TMP/*.ext3 $D_TMP/*.ext4 $D_TMP/*.xfs $D_TMP/*.jfs $D_TMP/*.btrfs
}

# cab_dirtmp
# Cabecera de menú

cab_dirtmp(){
echo -e "${C_ET}${FONDO_INTERFAZ}##=========== $PROGRAMA DIR TMP MENU ==========##${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
}

# dir_tmp
# INTERFAZ PARA MANIPULAR ARCHIVOS DEL DIRECTORIO TEMPORAL

dir_tmp(){

INPUT=${D_TMP}/menu.sh.$$

		while $verdadero;do
			MSG=$dir_tmp_MSG1
			colores_interfaz
			cab_dirtmp
			echo "1.- $dir_tmp_MSG2"
			echo "2.- $dir_tmp_MSG3"
			echo "|------------------------------------------------------|"
			echo "3.- $dir_tmp_MSG4"
			echo "4.- $dir_tmp_MSG5"
			echo "5.- $dir_tmp_MSG6"
			echo "0.- $dir_tmp_MSG7"
			echo -e "${C_ET}$dir_tmp_MSG8 $D_TMP ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
			echo "======================================"
			ver_ftmp

			echo -n "$dir_tmp_MSG9	"
			read eleccion

			case $eleccion in

				1)

					del_ftmp

					pinta_mensaje ${C_OK} $dir_tmp_MSG10

				;;


				2)
					cd $D_TMP
					gestor_de_archivos $MSG
				;;

				3)
					case $UD in
					0)
						dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
						--title "$PROGRAMA MOUNT MENU" \
						--menu "" 10 60 21 \
						M "$dir_tmp_MSG11" \
						D "$dir_tmp_MSG12" 2>"${INPUT}"
						op_md_img="$(<${INPUT})"
					;;

					1)
					
					cabecera
					echo "M.- $dir_tmp_MSG11"
					echo "D.- $dir_tmp_MSG12"

					read op_md_img
					;;

					2)
					op_md_img=$(zenity --width=300 --height=350 --title="$PROGRAMA" --entry --text="
MOUNT MENU
M) $dir_tmp_MSG11
D) $dir_tmp_MSG12")

					;;

					3)
					op_md_img=$(kdialog --menu "MOUNT MENU" \
					M "M- $dir_tmp_MSG11" \
					D "D- $dir_tmp_MSG12" --geometry=400x210 --title "$PROGRAMA")

					;;

					esac

					case $op_md_img in

						"m" | "M" )

							monta_img

						;;

						"d" | "D" )

							desmonta_img
					
						;;

						*)

                        				mui_Opcion_invalida
						;;
					esac
				
				;;

				4)

					MenuImagen

				;;

				5)
				
				case $UD in
					0)
						dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
						--title "$PROGRAMA" \
						--menu "" 10 60 21 \
						1 "$dir_tmp_MSG13" \
						2 "$dir_tmp_MSG14" \
						3 "$dir_tmp_MSG14B" 2>"${INPUT}"
						op_grab_img="$(<${INPUT})"
					;;

					1)
					clear
					cabecera
					echo "1.- $dir_tmp_MSG13"
					echo "2.- $dir_tmp_MSG14"
					echo "3.- $dir_tmp_MSG14B"
					echo ""
					echo -n "$dir_tmp_MSG15: "
					read op_grab_img
					
					;;

					2)
					op_grab_img=$(zenity --width=300 --height=250 --title="$PROGRAMA" --entry --text="
1) $dir_tmp_MSG13
2) $dir_tmp_MSG14
3) $dir_tmp_MSG14B")
				
					;;

					3)
					# mgrabaimg_MSG1 de lcdgrabUICD.idiom
					op_grab_img=$(kdialog --menu "$mgrabaimg_MSG1" \
1 "1- $dir_tmp_MSG13" \
2 "2- $dir_tmp_MSG14" \
3 "3- $dir_tmp_MSG14B" --geometry=480x180 --title "$PROGRAMA")

					;;

				esac


				if ! test -f $D_CFG/lcdgrab.cfg;then

					pinta_mensaje ${C_FA} $dir_tmp_MSG16
					pinta_mensaje ${COLOR_DEL_INTERFAZ} $dir_tmp_MSG17

					break
				else
					exportar_variables
				fi

					case $op_grab_img in

						1)	
							echo ""
							grabimg
						;;

						2)
							MSG=$dir_tmp_MSG18
							gestor_de_archivos $MSG
							obten_cadena "ISO-9660 IMG" "$dir_tmp_MSG19"

							imagen=$lacadena

							buscar_grabadora
							grabimg-dvd $imagen
						;;

						3)
							grabar_ISO_BD
						;;
				
					esac

				;;

				0)
					break
				;;

				*)
                    
                    			mui_Opcion_invalida

				;;

				esac

			done

[ -f $INPUT ] && rm -rf $INPUT &> /dev/null

colores_interfaz

}

