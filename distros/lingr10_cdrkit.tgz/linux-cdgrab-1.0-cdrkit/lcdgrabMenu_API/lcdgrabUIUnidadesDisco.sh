#########################################################
# lcgdrabMenu_API/lcdgrabUIUnidadesDisco.sh
# Menú de Interfaz la escritura de datos y formateo
# sobre dispositivos de bloque.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

##################  DISPOSITIVOS DE BLOQUE ######################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIUnidadesDisco.idiom

# dialog_aviso_opescritura
#
# Cuadro de dialogo de aviso en el menú princpial
# para el IU en ncurses

dialog_aviso_opescritura(){

	UNIDAV="$MenuDispositivosBloque_MSG2
		$MenuDispositivosBloque_MSG3
		$MenuDispositivosBloque_MSG4
		$MenuDispositivosBloque_MSG5
		$MenuDispositivosBloque_MSG6
		$MenuDispositivosBloque_MSG7
		$MenuDispositivosBloque_MSG8
		$MenuDispositivosBloque_MSG9
		---------------------------------------------------------"

clear

dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" --title "$PROGRAMA FLASHDRIVE MENU" --msgbox "$UNIDAV" 13 80

}

# dialog_aviso_formatounidades
#
# Cuadro de dialogo de aviso para el menú
# de formateo en el IU con ncurses

dialog_aviso_formatounidades(){

	UNIDAVF="$UIFormatearUnidad_linuxfs_MSG1
		$UIFormatearUnidad_linuxfs_MSG2
		$UIFormatearUnidad_linuxfs_MSG2B
		$UIFormatearUnidad_linuxfs_MSG3
		$UIFormatearUnidad_linuxfs_MSG4
		$UIFormatearUnidad_linuxfs_MSG5
		$UIFormatearUnidad_linuxfs_MSG6
		$UIFormatearUnidad_linuxfs_MSG7"

clear

dialog --clear --backtitle "-++ $PROGRAMA ++-" --title "$PROGRAMA FLASHDRIVE MENU" --yesno "$UNIDAVF" 15 83 

if test $? -eq 0;then
	export opcionformatdisco="C"
else
	export opcionformatdisco="A"
fi

}

# kdialog_aviso_opescritura
#
# Cuadro de dialogo de aviso en el menú princpial
# para el IU con Qt

kdialog_aviso_opescritura(){

	UNIDAV="$MenuDispositivosBloque_MSG2
$MenuDispositivosBloque_MSG3
$MenuDispositivosBloque_MSG4
$MenuDispositivosBloque_MSG5
$MenuDispositivosBloque_MSG6
$MenuDispositivosBloque_MSG7
$MenuDispositivosBloque_MSG8
$MenuDispositivosBloque_MSG9
---------------------------------------------------------"

clear

kdialog --msgbox "$UNIDAV" --geometry= 500x350 --title "$PROGRAMA"

}

# MenuDispositivosBloque
#
# Menú principal de las opciones a realizar
# sobre dispositivos de bloque.

MenuDispositivosBloque(){

INPUT=${D_TMP}/menu.sh.$$

while $verdadero;do

clear

case $UD in
0)

dialog_aviso_opescritura

dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
--title "$PROGRAMA FLASHDRIVE MENU" \
--menu "" 13 130 20 \
1 "$MenuDispositivosBloque_MSG11" \
2 "$MenuDispositivosBloque_MSG11B" \
3 "$MenuDispositivosBloque_MSG12" \
4 "$MenuDispositivosBloque_MSG14" \
0 "$MenuDispositivosBloque_MSG15" 2>"${INPUT}"
opcion=$(<"${INPUT}")

;;

1)
	cabecera
	printf "\t$MenuDispositivosBloque_MSG1\n"
	printf "==================================================\n"
	echo -e "${C_AV}$MenuDispositivosBloque_MSG2${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}" 
	echo -e "${C_AV}$MenuDispositivosBloque_MSG3${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ} "
	echo -e "${C_AV}$MenuDispositivosBloque_MSG4${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ} "
	echo -e "${C_AV}$MenuDispositivosBloque_MSG5${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_AV}$MenuDispositivosBloque_MSG6${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_AV}$MenuDispositivosBloque_MSG7${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ} "
	echo -e "${C_AV}$MenuDispositivosBloque_MSG8${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_AV}$MenuDispositivosBloque_MSG9${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo -e "${C_AV}---------------------------------------------------------${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	
	echo -e "${C_ET}$MenuDispositivosBloque_MSG10${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "1.- $MenuDispositivosBloque_MSG11"
	echo "2.- $MenuDispositivosBloque_MSG11B"
	echo -e "${C_AV}    $MenuDispositivosBloque_MSG11C ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "3.- $MenuDispositivosBloque_MSG12"
	echo -e "${C_ET}$MenuDispositivosBloque_MSG13${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo "4.- $MenuDispositivosBloque_MSG14"

	echo "0.- $MenuDispositivosBloque_MSG15"
	echo -n "$MenuDispositivosBloque_MSG16 : "
	read opcion

;;

2)

	opcion=$(zenity --width=400 --height=350 --title="$PROGRAMA" --entry --text="
$MenuDispositivosBloque_MSG1
$MenuDispositivosBloque_MSG2 
$MenuDispositivosBloque_MSG3
$MenuDispositivosBloque_MSG4
$MenuDispositivosBloque_MSG5
$MenuDispositivosBloque_MSG6
$MenuDispositivosBloque_MSG7
$MenuDispositivosBloque_MSG8
$MenuDispositivosBloque_MSG9
$MenuDispositivosBloque_MSG10
1.- $MenuDispositivosBloque_MSG11
2.- $MenuDispositivosBloque_MSG11B
$MenuDispositivosBloque_MSG11C
3.- $MenuDispositivosBloque_MSG12
$MenuDispositivosBloque_MSG13
4.- $MenuDispositivosBloque_MSG14
0.- $MenuDispositivosBloque_MSG15
$MenuDispositivosBloque_MSG16")
;;

3)

kdialog_aviso_opescritura

	opcion=$(kdialog --menu "$MenuDispositivosBloque_KDE_MSG1" \
1 "1- $MenuDispositivosBloque_MSG11" \
2 "2- $MenuDispositivosBloque_MSG11B" \
3 "3- $MenuDispositivosBloque_MSG12" \
4 "4- $MenuDispositivosBloque_MSG14" \
0 "0- $MenuDispositivosBloque_MSG15" --geometry=860x230 --title "$PROGRAMA")
;;

esac
	case $opcion in

		1)
		volcar_imagen
		;;

		2)
		m_volcar_iso
		;;

		3)
		UIFormatearUnidad_linuxfs
		;;

		4)
		imagen_img
		;;

		0)
		break
		;;

		*)
        	mui_Opcion_invalida
		;;

	esac

done

rm -rf $INPUT &> /dev/null

colores_interfaz

}

# UIFormatearUnidad_linuxfs
#
# Interfaz para el formatear discos duros.

UIFormatearUnidad_linuxfs(){

clear

while $verdadero;do

  case $UD in
	0)
		dialog_aviso_formatounidades
		
	;;

	1)
	cabecera
	echo -e "${C_AV} "
	echo $UIFormatearUnidad_linuxfs_MSG1
	echo $UIFormatearUnidad_linuxfs_MSG2
	echo $UIFormatearUnidad_linuxfs_MSG3
	echo $UIFormatearUnidad_linuxfs_MSG4
	echo $UIFormatearUnidad_linuxfs_MSG5
	echo $UIFormatearUnidad_linuxfs_MSG6
	echo $UIFormatearUnidad_linuxfs_MSG7
	echo -e "${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
	echo $UIFormatearUnidad_linuxfs_MSG8
	
	read opcionformatdisco
	;;

	2)
	opcionformatdisco=$(zenity --width=400 --height=250 --title="$PROGRAMA" --entry --text="
$UIFormatearUnidad_linuxfs_MSG1
$UIFormatearUnidad_linuxfs_MSG2
$UIFormatearUnidad_linuxfs_MSG3
$UIFormatearUnidad_linuxfs_MSG4
$UIFormatearUnidad_linuxfs_MSG5
$UIFormatearUnidad_linuxfs_MSG6
$UIFormatearUnidad_linuxfs_MSG8")
	;;

	3)
		KDIAMSGFORM="$UIFormatearUnidad_linuxfs_MSG1
$UIFormatearUnidad_linuxfs_MSG2
$UIFormatearUnidad_linuxfs_MSG3
$UIFormatearUnidad_linuxfs_MSG4
$UIFormatearUnidad_linuxfs_MSG5
$UIFormatearUnidad_linuxfs_MSG6
$UIFormatearUnidad_linuxfs_MSG7"

		kdialog --warningyesno "$KDIAMSGFORM" --geometry=400x400 --title "$PROGRAMA"

		if test $? -eq 0;then
			opcionformatdisco="C"
		else
			opcionformatdisco="A"
		fi
	;;

   esac

	case $opcionformatdisco in

		"C" | "c")

			Formateador_linuxfs

		;;

		*)

			break
		;;

	esac
done

}

