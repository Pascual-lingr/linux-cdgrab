#########################################################
# lcgdrabMenu_API/lcdgrabUIBD.sh
# Menu de Interfaz para la grabación de Blu-Ray Disc (BD).
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

#########################  GRABACIONES EN BD ############################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabMenu_API_idiom/lcdgrabUIBD.idiom

# menu_grabar_BD
# Menú para grabaciones en dispositivo BD

menu_grabar_BD(){

typeset MSG=$menu_grabar_BD_MSG4
typeset INPUT=${D_TMP}/menu.sh.$$
typeset lb="-- (libburnia)" 
typeset dt="-- (dvd-+-rw-tools)"
typeset cr="-- (Cdrecord-ProDVD-ProBD)"

clear

while $verdadero;do


    case $UD in
	0)

		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA BLU-RAY DISC MENU" \
		--menu "$menu_grabar_BD_MSG1" 16 90 12 \
		1 "$menu_grabar_BD_MSG2 (libburnia)" \
		2 "$menu_grabar_BD_MSG7 (libburnia)" \
		3 "$menu_grabar_BD_MSG10 (libburnia)" \
		4 "$menu_grabar_BD_MSG7 (growisofs)" \
		5 "$menu_grabar_BD_MSG9 (dvd+rw-mediainfo)" \
		6 "$menu_grabar_BD_MSG2 (cdrecord)" \
		7 "$menu_grabar_BD_MSG7 (cdrecord)" \
		8 "$menu_grabar_BD_MSG9 (cdrecord)" \
		0 "$menu_grabar_BD_MSG0" 2>"${INPUT}"
		menuBDop="$(<${INPUT})"
	;;


	1)
		cabecera
		printf "\t\t$menu_grabar_BD_MSG1\n"
		printf "==================================================\n"
		echo -e "${C_ET}$menu_grabar_BD_MSG8${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
		echo ""
		echo -e "${C_AV} $lb ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		echo "1.- $menu_grabar_BD_MSG2"
		echo "2.- $menu_grabar_BD_MSG7"
		echo "3.- $menu_grabar_BD_MSG10"
		echo -e "${C_AV} $dt ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		echo "4.- $menu_grabar_BD_MSG7"
		echo "5.- $menu_grabar_BD_MSG9"
		echo -e "${C_AV} $cr ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		echo "6.- $menu_grabar_BD_MSG2"
		echo "7.- $menu_grabar_BD_MSG7"
		echo "8.- $menu_grabar_BD_MSG9"
		echo ""
		echo "0.- $menu_grabar_BD_MSG0"
	
		read menuBDop
	;;

	2)
		menuBDop=$(zenity --width=300 --height=200 --title="$PROGRAMA" --entry --text="
$menu_grabar_BD_MSG1
$lb
1.- $menu_grabar_BD_MSG2
2.- $menu_grabar_BD_MSG7
3.- $menu_grabar_BD_MSG10
$dt
4.- $menu_grabar_BD_MSG7
5.- $menu_grabar_BD_MSG9
$cr
6.- $menu_grabar_BD_MSG2
7.- $menu_grabar_BD_MSG7
8.- $menu_grabar_BD_MSG9
0.- $menu_grabar_BD_MSG0")
	;;

	3)
		menuBDop=$(kdialog --menu "$menu_grabar_BD_MSG1" \
1 "1-$menu_grabar_BD_MSG2 (libburnia)" \
2 "2-$menu_grabar_BD_MSG7 (libburnia)" \
3 "3-$menu_grabar_BD_MSG10 (libburnia)" \
4 "4-$menu_grabar_BD_MSG7 (growisofs)" \
5 "5-$menu_grabar_BD_MSG9 (dvd+rw-mediainfo)" \
6 "6-$menu_grabar_BD_MSG2 (cdrecord)" \
7 "7-$menu_grabar_BD_MSG7 (cdrecord)" \
8 "8-$menu_grabar_BD_MSG9 (cdrecord)" \
0 "0-$menu_grabar_BD_MSG0" --geometry=800x315 --title "$PROGRAMA")
	;;
esac

    case $menuBDop in

		1)
			buscar_grabadoralb
			grabar_BD_datos_iso
		;;


		2)
			buscar_grabadoralb
			grabar_ISO_BD_libburnia
		;;

		3)
			buscar_grabadoralb
			borrar_BDRE_lb
		;;

		4)
			buscar_grabadora
			grabar_ISO_BD
		;;

		5)
			buscar_grabadora
			bd_disc_info
		;;

		6)

			bd_datos
		;;

		7)

			grabar_ISO_BD_cdrecord
		;;

		8)
			bd_discoinfo
		;;

		0)
			break
		;;

		*)

            		mui_Opcion_invalida

		;;
	
     esac
     
     [ -f $INPUT ] && rm $INPUT &> /dev/null

done

}

