#########################################################
# lcgdrabCMD_API/lcdgrabDVD-API.sh
# Colección de funciones para grabaciones en DVD.
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

################################### GRABACIÓN EN DVD #####################################

##############################################################################
################## API DE GRABACIÓN CON dvd+-rw-tools ########################
##############################################################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabDVD-API.idiom

# buscar_grabadora
# comprueba el dispositivo que corresponde a la grabadora de DVD
# las dvd-rw-tools necesitan un dispositivo de bloque para funcionar.

buscar_grabadora(){

cabecera

if test -z $IDE;then
	IDE="$( cat $D_CFG/lcdgrab.cfg | grep -e 'IDE.' | sed -e 's/IDE//g' -e 's/ //g' -e 's/[=]//g')"
fi

cabecera
echo ""
	
if echo $IDE | grep -e '/dev.' &> /dev/null && expr $? = 0 &> /dev/null;then
	
	echo -e "$buscar_grabadora_MSG1 $IDE ${C_OK}$buscar_grabadora_MSG1B${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	grabadora_dvd=$IDE
else

	echo -e "$buscar_grabadora_MSG2 $IDE ${C_FA}$buscar_grabadora_MSG2B${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	echo -e "${C_AV}"
	echo "$buscar_grabadora_MSG3 $IDE"
	echo $buscar_grabadora_MSG4
	echo "$buscar_grabadora_MSG5 : /dev/ide/host0/bus1/target1/lun0/cd $buscar_grabadora_MSG6 /dev/hdd,/dev/hde etc"
	echo -e "${COLOR_DEL_INTERFAZ}"
	echo ""

	echo $buscar_grabadora_MSG7

	ls /dev
	teclash
        cabecera
        echo ""
        echo $buscar_grabadora_MSG8
        read grabadora_dvd

        if test -z $grabadora_dvd;then
		echo $buscar_grabadora_MSG9
        	teclash
	fi

fi

cabecera

# exporta la grabadora al entorno.
echo "$buscar_grabadora_MSG10: $grabadora_dvd"
if ! test -z grabadora_dvd;then
     export grabadora_dvd
     echo "$buscar_grabadora_MSG11 $grabadora_dvd"
fi

sleep 2

}

# datos_dvd
# graba datos del disco duro a un DVD

datos_dvd(){
colores_interfaz

vel="-speed=$Velocidad"

obten_cadena "${COLOR_DEL_INTERFAZ}" "$datos_dvd_MSG1"
etiqueta=$lacadena

if test -z $etiqueta;then
	etiqueta="NUEVO DVD"
fi

echo ""
echo $datos_dvd_MSG2
echo ""

# comprueba que se trata de la version de mkisofs disponible en las cdrtools.

if test -x $D_BIN/mkisofs && ! test -h $D_BIN/mkisofs && ! mkisofs --version | grep -e 'genisoimage';then

	echo "$datos_dvd_MSG3 :$($lingrmkimg1 $mkisofsver)"
	export MKISOFS="$D_BIN/mkisofs"
	export GENISOIMAGE="$D_BIN/mkisofs"

	sleep 2

	case $metadatosisoapple in
	0)
	lingrcmdexec $lingrdvdburn1 "#"$growisofsrocjol1s1 $grabadora_dvd $growisofsrocjol1s2 $vel $growisofsrocjol1s3 $growisofsrocjol1s4 $etiqueta $growisofsrocjol1s5 $NIVEL_ISO $growisofsrocjol1s6 $HOME/rutas_lcdgrab.txt "#" "NM" "#" "NM"
	;;

	1)
	lingrcmdexec $lingrdvdburn1 "#"$growisofshfsrocjol1s1 $grabadora_dvd $growisofshfsrocjol1s2 $vel $growisofshfsrocjol1s3 $etiqueta $growisofshfsrocjol1s4 $etiqueta $growisofshfsrocjol1s5 $NIVEL_ISO $growisofshfsrocjol1s6 $HOME/rutas_lcdgrab.txt "#" "NM" "#" "NM"
	;;

	esac

	if test $ejcodret -eq 0;then

        	pinta_mensaje ${C_OK} $datos_dvd_MSG5

	else

        	mui_DVD_error
	fi
	
	expulsar_medio $grabadora_dvd

elif test -x $D_BIN/genisoimage;then # comprueba que se trata de la version de mkisofs disponible en el cdrkit.

	echo "$datos_dvd_MSG3 :$($lingrmkimg2 $mkisofsver)"
	export MKISOFS="$D_BIN/genisoimage"
	export GENISOIMAGE="$D_BIN/genisoimage"
	sleep 2

	case $metadatosisoapple in 
	0)
	lingrcmdexec $lingrdvdburn1 "#" $growisofsrocjol1s1 $grabadora_dvd $growisofsrocjol1s2 $vel $growisofsrocjol1s3 $growisofsrocjol1s4 $etiqueta $growisofsrocjol1s5 $NIVEL_ISO $growisofsgenrocjol1s $HOME/rutas_lcdgrab.txt "#" "NM" "#" "NM"
	;;

	1)
	lingrcmdexec $lingrdvdburn1 "#" $growisofshfsrocjol1s1 $grabadora_dvd $growisofshfsrocjol1s2 $vel $growisofshfsrocjol1s3 $etiqueta $growisofshfsrocjol1s4 $etiqueta $growisofshfsrocjol1s5 $NIVEL_ISO $growisofsgenhfsrocjol1s $HOME/rutas_lcdgrab.txt "#" "NM" "#" "NM"
	;;

	esac

	if test $ejcodret -eq 0;then

        	pinta_mensaje ${C_OK} $datos_dvd_MSG5
	else

        	mui_DVD_error

	fi

	expulsar_medio $grabadora_dvd    

else

	echo $datos_dvd_MSG6
	teclash

fi

}

# grabimg-dvd
# graba una imagen ISO-9660 en un DVD

# pasarle el parametro imagen

grabimg-dvd(){

cabecera
echo ""
echo $grabimg_dvd_MSG1
echo ""

vel="-speed=$Velocidad"

lingrcmdexec $lingrdvdburn1 "#"$gus $grabadora_dvd=$imagen $growisofswimgdvd1 $vel "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
    pinta_mensaje ${C_OK} $grabimg_dvd_MSG3
else
    mui_DVD_error
fi

expulsar_medio $grabadora_dvd

}

# copia_bin_dvd
# copia un DVD de datos creando una imagen binaria con dd, necesario el parametro LECTOR_CDROM

copia_bin_dvd(){

imagendvd="$D_TMP/lcdgrabdvdimg.iso"
optsgimg2="$grabadora_dvd=$imagendvd $growisofswimgdvd1"

extraer_isoDVD_dd

mui_una_sola_grabadora

cabecera

echo ""
echo $copia_bin_dvd_MSG1

# graba la imagen en el DVD

lingrcmdexec $lingrdvdburn1 "#"$gus $optsgimg2 "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
	pinta_mensaje ${C_OK} $copia_bin_dvd_MSG4
else
    	mui_DVD_error
fi

expulsar_medio $grabadora_dvd

echo ""
echo "$copia_bin_dvd_MSG3 $imagen"

rm -rf $imagendvd &> /dev/null
sleep 1
	
}

# formatear_dvd
# formatea un DVD+RW/DVD-RW

formatear_dvd(){

INPUT=${D_TMP}/menu.sh.$$

clear

while $verdadero;do

	case $UD in
	0)
		dialog --clear --no-cancel --ok-label "OK" --backtitle "-++ $PROGRAMA ++-" \
		--title "$PROGRAMA DVD MENU" \
		--menu "DVD+-RW FORMAT" 16 75 20 \
		1 "$formatear_dvd_MSG1 DVD+RW/DVD-RW" \
		2 "$formatear_dvd_MSG2 DVD+RW" \
		3 "$formatear_dvd_MSG3 DVD+RW" \
		4 "$formatear_dvd_MSG4" \
		5 "$formatear_dvd_MSG5" \
		N "$formatear_dvd_MSG6" \
		I "$formatear_dvd_MSG7" \
		0 "$formatear_dvd_MSG8" 2>"${INPUT}"
		fdvdop="$(<${INPUT})"
	;;

	1)
		clear
		cabecera

		printf "1.- $formatear_dvd_MSG1 DVD+RW/DVD-RW\n"
		printf "\n"
		printf "\t\tDVD+RW\n"
		printf "\t\t------\n"
		printf "\n"
		printf "2.- $formatear_dvd_MSG2 DVD+RW\n"
		printf "3.- $formatear_dvd_MSG3 DVD+RW\n"
		printf "\n"
		printf "\t\tDVD-RW\n"
		printf "\t\t------\n"
		printf "\n"
		printf "4.- $formatear_dvd_MSG4\n"
		printf "5.- $formatear_dvd_MSG5\n"
		printf "\n"
		printf "N ---> $formatear_dvd_MSG6\n"
		printf "I ---> $formatear_dvd_MSG7\n"
		printf "\n"
		printf "0.- $formatear_dvd_MSG8\n"
		read fdvdop

	;;

	2)
		fdvdop=$(zenity --width=275 --height=400 --title="$PROGRAMA" --entry --text="
1.- $formatear_dvd_MSG1 DVD+RW/DVD-RW
DVD+RW
---------------
2.- $formatear_dvd_MSG2 DVD+RW
3.- $formatear_dvd_MSG3 DVD+RW
DVD-RW
---------------
4.- $formatear_dvd_MSG4
5.- $formatear_dvd_MSG5
N --- $formatear_dvd_MSG6
I --- $formatear_dvd_MSG7
0.- $formatear_dvd_MSG8")

	;;

	3)
		fdvdop=$(kdialog --menu "DVD+-RW FORMAT" \
1 "1.- $formatear_dvd_MSG1 DVD+RW/DVD-RW" \
2 "2.- $formatear_dvd_MSG2 DVD+RW" \
3 "3.- $formatear_dvd_MSG3 DVD+RW" \
4 "4.- $formatear_dvd_MSG4" \
5 "5.- $formatear_dvd_MSG5" \
N "N --- $formatear_dvd_MSG6" \
I "I --- $formatear_dvd_MSG7" \
0 "0.- $formatear_dvd_MSG8" --geometry=700x300 --title="$PROGRAMA")

	;;
esac

	case $fdvdop in

		1)
			# DVD+RW / DVD-RW (Sobreescritura restringida)
			# Primer formato del DVD+RW/DVD-RW
			# no hace nada si ya esta formateado.
			# Si el disco es un DVD-RW lo formatea
			# en sobreescritura restringida.

			cabecera
			echo -e "${C_AV}"
			echo $formatear_dvd_MSG9
			echo $formatear_dvd_MSG10
			echo $formatear_dvd_MSG11
			echo $formatear_dvd_MSG12
			echo $formatear_dvd_MSG13
			echo $formatear_dvd_MSG14
			echo ""
			echo -e "${COLOR_DEL_INTERFAZ}"
			sleep 2

			lingrcmdexec $lingrdvdburn2 "#" $grabadora_dvd "#" $formatear_dvd_MSG16 "#" $formatear_dvd_MSG17

			expulsar_medio $grabadora_dvd
		;;

		2)	
			# DVD+RW
			# Fuerza un nuevo formato para un DVD+RW
			# el comando nos indica que este modo no es recomendable.
			# Se pierden los datos del DVD+RW.

			cabecera
			echo $formatear_dvd_MSG18
			echo ""

			lingrcmdexec $lingrdvdburn2 "#" $dvdrwformatforce $grabadora_dvd "#" $formatear_dvd_MSG19 "#" $formatear_dvd_MSG20

			expulsar_medio $grabadora_dvd
		;;

		3)
			# DVD+RW
			# Relocaliza el bloque lead-out en un DVD+RW
			# para obtener mejor compatibilidad en lectores DVD-ROM
			# No afecta a los datos del disco

			cabecera
			echo $formatear_dvd_MSG21
			sleep 1
			echo $formatear_dvd_MSG22
			echo ""

			lingrcmdexec $lingrdvdburn2 "#" $dvdrwformatlout $grabadora_dvd "#" $formatear_dvd_MSG19 "#" $formatear_dvd_MSG20

			expulsar_medio $grabadora_dvd
		;;
		
		4)
			# DVD-RW
			# Cambia el formato de un DVD-RW de sobreescritura restringida
			# a incremental secuencial (formato por defecto).Este nuevo formato
			# aunque sea el estandar no suele ser compatible en lectores DVD-ROM

			cabecera
			echo $formatear_dvd_MSG23
			echo "$formatear_dvd_MSG15:$lingrdvdburn2 $dvdrwformatbful $grabadora_dvd"
			echo ""

			lingrcmdexec $lingrdvdburn2 "#" $dvdrwformatbful $grabadora_dvd "#" $formatear_dvd_MSG24 "#" $formatear_dvd_MSG25

			expulsar_medio $grabadora_dvd
		;;

		5)
			# DVD-RW
			# Cambia el formato de un DVD-RW de incremental secuencial
			# a sobreescritura restringida.Este nuevo formato no parece 
			# see el estandar pero si es compatible con la mayoria de
			# lectores DVD-ROM

			cabecera
			echo $formatear_dvd_MSG26
			echo ""
	
			lingrcmdexec $lingrdvdburn2 "#" $dvdrwformatfful $grabadora_dvd "#" $formatear_dvd_MSG24 "#" $formatear_dvd_MSG25

			expulsar_medio $grabadora_dvd
		;;

		N)
			# Rellena de ceros un DVD+RW/DVD-RW
			# se escribe en el disco lo que genera /dev/zero.
			# Borra completamente los datos y el formato en un DVD+RW.
			# En el caso de un DVD-RW borra los datos pero no cambia
			# el formato de escritura secuencial a sobreescritura restringida
			# ni inversa,tampoco borra estos tipos de formato en el disco.

			null_dvd
		;;

		I)
			# Muestra la informacion del disco presente
			# en la unidad de grabacion.

			cabecera

			lingrcmdexec $lingrdvdburn3 "#" $grabadora_dvd "#" "NM" "#" "NM"

		;;

		0)
			break
		;;

		*)
            		mui_Opcion_invalida
		;;

	esac	 

	[ -f $INPUT ] && rm -f $INPUT &> /dev/null

done

}

# null_dvd
# rellena de ceros un DVD+RW/DVD-RW

null_dvd(){

	cabecera
	echo ""
	echo $null_dvd_MSG1
	echo ""

	lingrcmdexec $lingrdvdburn1 "#"$gus $grabadora_dvd=/dev/zero "#" $null_dvd_MSG3 "#" $null_dvd_MSG4

	expulsar_medio $grabadora_dvd
}

# dvd_video
# graba DVD-Video (DVD 9)

dvd_video(){

	grabavideo=0
	Vel="-speed=$Velocidad"
	MSG=$dvd_video_MSG1

	gestor_de_archivos $MSG

	cabecera
	echo $dvd_video_MSG2
	echo ""
	read ruta_video
	
	cabecera
	if test -x $D_BIN/mkisofs && ! test -h $D_BIN/mkisofs;then

		echo "$datos_dvd_multi_MSG3 :$($lingrmkimg1 $mkisofsver)"
		export MKISOFS="$D_BIN/mkisofs"
		export GENISOIMAGE="$D_BIN/mkisofs"
		grabavideo=1
		sleep 2

	elif test -x $D_BIN/genisoimage;then

		echo "$datos_dvd_MSG3 :$($lingrmkimg2 $mkisofsver)"
		export MKISOFS="$D_BIN/genisoimage"
		export GENISOIMAGE="$D_BIN/genisoimage"
		grabavideo=1
		sleep 2

	else

		echo $datos_dvd_MSG6
		teclash

	fi

	if test $grabavideo -eq 1;then

		lingrcmdexec $lingrdvdburn1 "#"$gus $grabadora_dvd $growisofsdvdvideo1 $Vel $growisofsdvdvideo2 $ruta_video "#" "NM" "#" "NM"

		if test $ejcodret -eq 0;then
        		pinta_mensaje ${C_OK} $dvd_video_MSG4
		else
        		mui_DVD_error

		fi
	fi
}

dvd_disc_info(){
	
	cabecera
	$lingrdvdburn3 $grabadora_dvd
	echo ""
	teclash
}

##############################################################################
################## API DE GRABACIÓN CON Cdrecord-ProDVD ######################
##############################################################################

# dvd_copia_bin
# copia un DVD de datos creando una imagen binaria con dd.

dvd_copia_bin(){

DEV="dev=$IDE"
Vel="speed=$Velocidad"

#Si test llega valiendo 1, borra la imagen generada con dd al final del proceso.
	
tes=0

extraer_isoDVD_dd

###### graba la imagen generada anteriormente en un CD o DVD.

#- comprueba si solo existe una grabadora física instalada en el ordenador.

mui_una_sola_grabadora

#- fin de la comprobación.

cabecera

lingrcmdexec $lingrdvdburn4 "#"$DEV $Vel $cdrecordwimgdvdov $imagen "#" "NM" "#" "NM"

if test $ejcodret -eq 0;then
	mui_grabacion_ok
else
    	pinta_mensaje ${C_FA} $dvd_copia_bin_MSG3
fi

echo ""
echo $dvd_copia_bin_MSG2
rm -f $D_TMP/lcdgrabdvdimg.iso &> /dev/null

}

# dvd_datos
# graba datos del disco duro a un DVD

dvd_datos(){

ruta="$HOME/rutas_lcdgrab.txt"
imagen="$D_TMP/lcdgrabimgdvd.iso"
DEV="dev=$IDE"
SPEED="speed=$Velocidad"
MSG=$dvd_datos_MSG1
errisofmtmsg="ERR: NO mkisofs/genisoimage"

############ crea la imagen

obten_cadena " " "$dvd_datos_MSG3"
etiqueta=$lacadena

colores_interfaz
echo $dvd_datos_MSG4
sleep 1
gestor_de_archivos $MSG

mui_rutas_dir

if test -x $D_BIN/mkisofs && ! test -h $D_BIN/mkisofs && ! mkisofs --version | grep -e 'genisoimage';then

	echo "$datos_dvd_MSG3 :$($lingrmkimg1 $mkisofsver)"
	export MKISOFS="$D_BIN/mkisofs"
	export GENISOIMAGE="$D_BIN/mkisofs"
	
	cabecera
	echo $dvd_datos_MSG5
	sleep 1

	case $metadatosisoapple in
	0)

		echo "cmd: $lingrmkimg1 $mkisofscddat1 $etiqueta $mkisofscddat2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $ruta"

		$lingrmkimg1 $mkisofscddat1 $etiqueta $mkisofscddat2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $ruta

	;;

	1)

		echo "cmd: $lingrmkimg1 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $mkisofscddatap3 $imagen $mkisofscddatap4 $NIVEL_ISO $mkisofscddatap5 $ruta"

		$lingrmkimg1 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $mkisofscddatap3 $imagen $mkisofscddatap4 $NIVEL_ISO $mkisofscddatap5 $ruta

	;;

	esac
	
	sync
		
elif test -x $D_BIN/genisoimage;then # comprueba que se trata de la version de mkisofs disponible en el cdrkit.

	echo "$datos_dvd_MSG3 :$($lingrmkimg2 $mkisofsver)"
	export MKISOFS="$D_BIN/genisoimage"
	export GENISOIMAGE="$D_BIN/genisoimage"
	sleep 2

	case $metadatosisoapple in
	0)

		echo "cmd: $lingrmkimg1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $ruta"

		$lingrmkimg1 $mkisofscddat1 $etiqueta $genisoimagefscddatap2 $imagen $mkisofscddat3 $NIVEL_ISO $mkisofscddat4 $ruta

	;;

	1)

		echo "cmd: $lingrmkimg1 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap1 $imagen $mkisofscddatap4 $NIVEL_ISO $mkisofscddatap5 $ruta"

		$lingrmkimg1 $mkisofscddatap1 $etiqueta $mkisofscddatap2 $etiqueta $genisoimagefscddatap1 $imagen $mkisofscddatap4 $NIVEL_ISO $mkisofscddatap5 $ruta

	;;

	esac
	
	sync
	
else
	pinta_mensaje ${C_FA} $errisofmtmsg
fi
	
if test -e $imagen;then

	echo ""
	echo -e "${C_OK}"
	echo "$dvd_datos_MSG7 : $imagen"
	echo ""
	echo $dvd_datos_MSG8
	echo -e "${COLOR_DEL_INTERFAZ}"
	sleep 2

################ graba el DVD

	lingrcmdexec $lingrdvdburn4 "#"$DEV $SPEED $cdrecordwimgdvdov $imagen "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then

		mui_grabacion_ok

	else

		mui_DVD_error
	
	fi

	echo $dvd_datos_MSG13
	echo ""
	rm -f $ruta
	rm -f $imagen
	rm -f $D_LINUXCDGRAB/lcdgrabnombreetiqueta.$$
	echo ""

else

	mui_img_error	
	break

fi

}

# dvd_grabimg
# grabimg
# graba una imagen en CD o DVD mediante cdrecord

# modificada para informar sobre el proceso
# de grabacion de imagenes .ext2

dvd_grabimg(){

	grabimg

}

# dvd_borra
# Formatea un disco CD-RW/DVD-RW/DVD+RW

dvd_borra(){

DEV="dev=$IDE"
Vel="speed=$Velocidad"

cabecera

lingrcmdexec $lingrdvdburn4 "#"$DEV $Vel $cdrecordformatdvd "#" $dvd_borra_MSG2 "#" $dvd_borra_MSG3

}

# dvd_discoinfo
# Información sobre el disco grabado, usa cdrecord

dvd_discoinfo(){

	discoinfo
}

##############################################################################
################## API DE GRABACIÓN CON libburnia (cdrskin) ##################
##############################################################################

# buscar_grabadoralb
# comprueba el dispositivo que corresponde a la grabadora de DVD
# comprueba que no se use un valor para cdrecord como x,x,x
# difiere del utilizado en cdrskin, se solicita al usuario.

buscar_grabadoralb(){

cabecera

if test -z $IDE;then
	IDE="$( cat $D_CFG/lcdgrab.cfg | grep -e 'IDE.' | sed -e 's/IDE//g' -e 's/ //g' -e 's/[=]//g')"
fi

cabecera
echo ""

if echo $IDE | grep -e '/dev.' &> /dev/null && expr $? = 0 &> /dev/null;then

	echo -e "$buscar_grabadora_MSG1 $IDE ${C_OK}$buscar_grabadora_MSG1B${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	grabadora_dvd=$IDE

else

	echo -e "$buscar_grabadora_MSG2 $IDE ${C_AV}$buscar_grabadoralb_MSG1${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	echo -e "${C_AV}"
	echo "$buscar_grabadoralb_MSG2 $IDE"
	echo "$buscar_grabadoralb_MSG3"
	echo -e "${COLOR_DEL_INTERFAZ}"
	echo "$buscar_grabadoralb_MSG4"
	$lingrdvdburn5 $cdrecordscop1
	echo ""
	echo -n "$buscar_grabadoralb_MSG5 "
        read grabadora_dvd

        if test -z $grabadora_dvd;then
		echo $buscar_grabadora_MSG9
        	teclash
	fi

fi

cabecera

# exporta la grabadora al entorno.
echo "$buscar_grabadora_MSG10: $grabadora_dvd"
if ! test -z grabadora_dvd;then
     export grabadora_dvd
     echo "$buscar_grabadora_MSG11 $grabadora_dvd"
fi

sleep 2

}

# formatearCDDVDBD
#
# Formatea CD-RW, DVD-RW, DVD-RAM , BD-RE

formatearCDDVDBD(){

DEV="dev=$grabadora_dvd"

lingrcmdexec $lingrdvdburn5 "#"$cdrskiniso2od1 $DEV $cdrskincdrwerase2 "#" $formatearCDDVDBD_MSG2 "#" $formatearCDDVDBD_MSG3

}

########################### DVD-RW #######################

# formatearDVDRW_incremental_secuencial
#
# Formatea un DVD-RW a Incremental secuencial
# Permite que el DVD-RW pueda grabarse como multisesión

formatearDVDRW_incremental_secuencial(){

DEV="dev=$grabadora_dvd"

	lingrcmdexec $lingrdvdburn5 "#"$cdrskiniso2od1 $DEV $cdrskinfdvdrwis "#" $formatearDVDRW_incremental_secuencial_MSG1 "#" $formatearDVDRW_incremental_secuencial_MSG2

	expulsar_medio $grabadora_dvd

}

##########################################################

# dvd_copia_binlb
#
# Clonada de dvd_copia_bin
# copia un DVD de datos creando una imagen binaria con dd.

dvd_copia_binlb(){

DEV="dev=$grabadora_dvd"
msgnoimg="$datoslb_MSG1"

#Si test llega valiendo 1, borra la imagen generada con dd al final del proceso.
	
tes=0

extraer_isoDVD_dd

###### graba la imagen generada anteriormente en un CD o DVD.

if test -f $imagen;then
	#- comprueba si solo existe una grabadora física instalada en el ordenador.

	mui_una_sola_grabadora

	#- fin de la comprobación.

	cabecera

	lingrcmdexec $lingrdvdburn5 "#"$cdrskiniso2od1 $DEV $cdrskiniso2od2 $imagen "#" "NM" "#" "NM"

	if test $ejcodret -eq 0;then
		mui_grabacion_ok
	else
    		pinta_mensaje ${C_FA} $dvd_copia_bin_MSG3
	fi

	echo ""
	echo $dvd_copia_bin_MSG2
	rm -f $D_TMP/lcdgrabdvdimg.iso &> /dev/null

	expulsar_medio $IDE

else
	pinta_mensaje "${C_FA}" "$msgnoimg"
fi

}

# cdrskinisocddvd
#
# graba una imagen .iso en CD/DVD/BD
# con cdrskin

cdrskinisocddvd(){

DEV="dev=$grabadora_dvd"

typeset local LABEL="ISO-9660 IMG"

obten_cadena "$LABEL" "$cdrskinisocddvd_MSG1"
imagenISO9660user=$lacadena

lingrcmdexec $lingrdvdburn5 "#"$cdrskiniso2od1 $DEV$cdrskiniso2od2 $imagenISO9660user "#" $cdrskinisocddvd_MSG2 "#" $cdrskinisocddvd_MSG3

expulsar_medio $grabadora_dvd

}

# grabardatosHD
#
# graba datos del disco duro a CD/DVD/BD

grabardatosHD(){

	datoslb

}

# grabadorainfo
#
# Muestra la información del disco y la grabadora

grabadorainfo(){

    DEV="dev=$grabadora_dvd"

    cabecera
    $lingrdvdburn5 $DEV $cdrskininfdev
    echo ""
    teclash

}

# listargrabadoras
#
# Lista las grabadoras instaladas en nuestro sistema

listargrabadoras(){

	cabecera
	$lingrdvdburn5 $cdrskinlistd
	echo ""
	teclash
}
