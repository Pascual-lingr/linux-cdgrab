#########################################################
# lcgdrabCMD_API/lcdgrabAPP-SYS.sh
# Funciones comunes para la aplicación.
# Ejecución de comandos parametrizados en lingrcmd.sh
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

# Expande el fichero de colores

source ${D_LINUXCDGRAB}/lcdgrabCoreAPP/colores.dat

# Expande la parametrización de comandos

source ${D_LINUXCDGRAB}/lcdgrabCoreAPP/lingrcmd.sh

PROGRAMA="LINUX-CDGRAB 1.0"

# Herramientas usadas por LINUX-CDGRAB

CMDBURN=$APPBURN
CMDISOF=$APPISOF
CMDFMTD=$APPFMTD
CMDFCOM=$APPFCOM
CMDAUDC=$APPAUDC
CMDVIDC=$APPVIDC

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabAPP-SYS.idiom

# colores_por_defecto
#
# Carga los colores de la aplicación por defecto en caso de que $D_LINUXCDGRAB/lcdgrabCoreAPP/colores.dat no exista

colores_por_defecto(){

export COLOR_DEL_INTERFAZ="\033[1;37m" # B_BLANCO
export FONDO_INTERFAZ="\033[1;44m" # FONDO_AZUL
export C_OK="\033[1;32m" # B_VERDE
export C_FA="\033[1;31m" # B_ROJO
export C_AV="\033[1;33m" # B_AMARILLO
export C_ET="\033[1;36m" # B_CIAN 

}

# colores_interfaz
#
# muestra en pantalla los colores elegidos para el
# interfaz y borra la pantalla.

colores_interfaz(){
echo -e " ${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ} "
clear
}

# cabecera
#
# cabecera de menu del programa.

cabecera(){

colores_interfaz
printf "==================================================\n"
printf "=\t\t $PROGRAMA\t\t =\n"
printf "=\t\t ----------------\t\t =\n"
printf "==================================================\n"

}

# m_cdrecord-sin-overburn
#
# Mensaje Ejecucion de cdrecord sin -overburn

m_cdrecord-sin-overburn(){

echo ""
echo $m_cdrecord_sin_overburn_MSG1
echo $m_cdrecord_sin_overburn_MSG2
echo $m_cdrecord_sin_overburn_MSG3
echo ""

}

# dial_una_sola_grabadora
# zen_una_sola_grabadora
# kde_una_sola_grabadora
#
# Comprueba que en la máquina solo existe una unidad física instalada,
# en este caso hará una pausa para poder cambiar el CD o DVD de la unidad.
# Ordenadores con una sola grabadora.

dial_una_sola_grabadora(){

if test $IDE == $LECTOR_CDROM;then
	$lingreject $IDE
	dialog --title "$una_sola_grabadora_D_MSG1" --backtitle "$PROGRAMA" --msgbox "$una_sola_grabadora_D_MSG2" 15 90
fi

}

zen_una_sola_grabadora(){

if test $IDE == $LECTOR_CDROM;then
	$lingreject $IDE
	zenity --title="$PROGRAMA" --info --text="$una_sola_grabadora_D_MSG2" --width=500 --height=200
fi

}

kde_una_sola_grabadora(){

if test $IDE == $LECTOR_CDROM;then
	$lingreject $IDE
	kdialog --title="$PROGRAMA" --msgbox "$una_sola_grabadora_D_MSG2" --geometry=700x500
fi

}

## Funciones para IU en texto. Réplica de funciones text_*
#  Funcionales cuando UD=1

# teclash
#
# espera la pulsación de la tecla INTRO, modo texto.

teclash(){
	echo ""
	echo $teclash_MSG1
	read xxxx
	colores_interfaz

}

# text_rutas_dir
#
# rutas_dir versión texto.
# pide rutas de directorios al usuario

text_rutas_dir(){

dir=""

until [ $dir = "f" ];do
cabecera
echo $text_rutas_dir_MSG1
echo ""

read dir

if ! test $dir = "f";then
	
	if test -d $dir;then

		if ! test -f $HOME/rutas_lcdgrab.txt;then

			echo $dir > $HOME/rutas_lcdgrab.txt
		else
			echo $dir >> $HOME/rutas_lcdgrab.txt
		fi
	else
		echo $text_rutas_dir_MSG2 $dir $text_rutas_dir_MSG3
		sleep 1
	fi
fi

done

}

# text_una_sola_grabadora
#
# una_sola_grabadora versión texto.

text_una_sola_grabadora(){
cabecera
if test $IDE == $LECTOR_CDROM;then
echo -e "${C_AV}"
echo $text_una_sola_grabadora_MSG1
echo "-------------------------------------------------"
echo $text_una_sola_grabadora_MSG2
echo $text_una_sola_grabadora_MSG3
echo $text_una_sola_grabadora_MSG4
echo $text_una_sola_grabadora_MSG5
echo $text_una_sola_grabadora_MSG6
echo $text_una_sola_grabadora_MSG7
echo -e "${COLOR_DEL_INTERFAZ} ${FONDO_INTERFAZ}"
fi
eject $IDE
teclash
}

### Fin declaracion de funciones de texto.

# pinta_mensaje
#
# Notifica con dialog, zenity o en texto
# el mensaje de texto recibido como parametro.
# Debe espacificarsele el color para el 
# mensaje de texto.
# Usar: pinta_mensaje $color $cadena

pinta_mensaje(){

msged=$(echo $@| cut -d' ' -f 2-)

case $UD in
	0)
		dialog --backtitle "$PROGRAMA" --msgbox "$msged" 9 50
		colores_interfaz
	;;

	1)
		echo -e "		$@ ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
		teclash
	;;

	2)
		if test ${C_FA} == $1;then
			zenity --title="$PROGRAMA" --error --text="$msged" --width=300 --height=100
		else
			zenity --title="$PROGRAMA" --info --text="$msged" --width=300 --height=100
		fi
	;;

	3)
		if test ${C_FA} == $1;then
			kdialog --title="$PROGRAMA" --error "$msged" --geometry=700x500
		else
			kdialog --title="$PROGRAMA" --msgbox "$msged" --geometry=700x500
		fi
	;;

esac

}

# Estas funciones se replican para que funcionen sin 
# el comando dialog, zenity o kdialog (versiones text_*)
# El uso del interfaz con ncurses o gráfica requiere que
# la variable UD este informada como:
# UD=0 (dialog)
# UD=2 (zenity)
# UD=3 (kdialog)

# rutas_dir
#
# pide rutas de directorios al usuario

rutas_dir(){

dir="z"

until `test $dir = "f" `;do
clear

case $UD in
0)
	dialog --title "$rutas_dir_D_MSG1" --backtitle "$PROGRAMA" --inputbox "$rutas_dir_D_MSG2" 8 60 2> $D_LINUXCDGRAB/lcdgrabnombreruta.$$

	dir=`cat $D_LINUXCDGRAB/lcdgrabnombreruta.$$`
;;

2)
	dir=$(zenity --width=300 --height=100 --title="$PROGRAMA" --entry --text="$rutas_dir_D_MSG1
$rutas_dir_D_MSG2")
;;

3)
	dir=$(kdialog --title="$rutas_dir_D_MSG1" --inputbox "$rutas_dir_D_MSG2" " ")
;;

esac

if ! test $dir = "f";then
	
	if test -d $dir;then

		if ! test -f $HOME/rutas_lcdgrab.txt;then

			echo $dir > $HOME/rutas_lcdgrab.txt
		else
			echo $dir >> $HOME/rutas_lcdgrab.txt
		fi
		
	else
		pinta_mensaje ${C_FA} "$rutas_dir_D_MSG3 $dir $rutas_dir_D_MSG4"

	fi
fi
rm -f $dir
done

rm -f $D_LINUXCDGRAB/lcdgrabnombreruta.*

}

# Mensajes para el usuario desde el interfaz
# Otras actuaciones sobre el interfaz.

# mui_Opcion_invalida
#

mui_Opcion_invalida(){

    pinta_mensaje ${C_FA} $text_Opcion_invalida_MSG1

}

# mui_img_error
#

mui_img_error(){

    pinta_mensaje "${C_FA}" "	$text_img_error_MSG1"
}

# mui_CD_error
#

mui_CD_error(){

    pinta_mensaje ${C_FA} $text_CD_error_MSG1

}

# mui_DVD_error
#

mui_DVD_error(){

    pinta_mensaje ${C_FA} $text_DVD_error_MSG1

}

# mui_DO_error
#

mui_DO_error(){

    pinta_mensaje ${C_FA} $text_DO_error_MSG1

}

# mui_grabacion_ok
#

mui_grabacion_ok(){

    pinta_mensaje ${C_OK} $grabacion_ok_D_MSG1
}

# mui_rutas_dir
# 

mui_rutas_dir(){

    if test -f $HOME/rutas_lcdgrab.txt;then
	rm -f $HOME/rutas_lcdgrab.txt
    fi

    if test $UD -eq 1;then
        text_rutas_dir
    else
        rutas_dir
    fi

}

# mui_una_sola_grabadora
#
# encapsula las llamadas a text_una_sola_grabadora, dial_una_sola_grabadora,
# zen_una_sola_grabadora y kde_una_sola_grabadora.

mui_una_sola_grabadora(){

case $UD in
	0)
		dial_una_sola_grabadora
	;;

	1)
		text_una_sola_grabadora
	;;

	2)
		zen_una_sola_grabadora
	;;

	3)
		kde_una_sola_grabadora
	;;
esac

}

## Fin mui_*

# obten_cadena
#
# Obtiene la ruta de un directorio, etiquetas de CD/DVD...
# Obtiene una cadena de caracteres, muestra los mensajes pasados
# por parámetros en el interfaz de usuario.
# Llamada: obten_cadena "texto_cadena1" "texto_cadena2"

obten_cadena(){

typeset local obten_cadena_MSG1
typeset local obten_cadena_MSG2

lacadena=""

obten_cadena_MSG1=$1
obten_cadena_MSG2=$2

case $UD in
0)
    dialog --title "$obten_cadena_MSG1" --backtitle "$PROGRAMA" --no-cancel --ok-label "OK" --inputbox "$obten_cadena_MSG2" 8 60 2> $D_LINUXCDGRAB/lcdgrabcadena.$$
    lacadena=`cat $D_LINUXCDGRAB/lcdgrabcadena.$$`   
;;

1)
    cabecera
    echo $obten_cadena_MSG2
    read lacadena
;;

2)
    lacadena=$(zenity --width=300 --height=100 --title="$PROGRAMA" --entry --text="$obten_cadena_MSG2")
;;

3)
    lacadena=$(kdialog --title="$PROGRAMA" --inputbox "$obten_cadena_MSG2" " ")
;;

esac

export lacadena

rm -rf $D_LINUXCDGRAB/lcdgrabcadena.$$ &> /dev/null

}

# lingrcmdexec
#
# Ejecuta el comando informado junto con sus argumentos
# Parametrización de comandos definida en lingrcmd.sh
#
# Recibe los parametros $LCMDE "#" $OPTSCMD "#" $MSG_OK "#" $MSG_ERR
# Para usar sin mensajes informar los campos 3 y 4 con "NM"

# Incluir el delimitador "#" en la llamada para delimitar los parametros

lingrcmdexec(){

typeset local cmdexec=""
typeset local opts=""
typeset local MSG_OK=""
typeset local MSG_ERR=""

ejcodret=""

cmdexec=$1
opts=$(echo $@| cut -d'#' -f 2)
MSG_OK=$(echo $@| cut -d'#' -f 3)
MSG_ERR=$(echo $@| cut -d'#' -f 4)

cabecera

echo -e "${C_ET}$lingrcmdver${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

echo "$lingrcmdexec_MSG1: $cmdexec $opts"

if test $MSG_OK = "NM" &> /dev/null || test $MSG_ERR = "NM" &> /dev/null;then
	$cmdexec $opts

	if test $? -eq 0;then
	   ejcodret=0
	else
	   ejcodret=1
	fi
        

else

	if $cmdexec $opts;then
		pinta_mensaje ${C_OK} $MSG_OK
		ejcodret=0
	else
		pinta_mensaje ${C_FA} $MSG_ERR
		ejcodret=1
	fi

fi

export ejcodret

}

# lingrcmdexecnostop
#
# Ejecuta el comando informado junto con sus argumentos
# No se interrumpe la ejecución del programa con esta función.
# Parametrización de comandos definida en lingrcmd.sh
#
# Recibe los parametros $LCMDE "#" $OPTSCMD "#" $MSG_OK "#" $MSG_ERR
# Para usar sin mensajes informar los campos 3 y 4 con "NM"

# Incluir el delimitador "#" en la llamada para delimitar los parametros

lingrcmdexecnostop(){

typeset local pcmdexec=""
typeset local popts=""
typeset local pMSG_OK=""
typeset local pMSG_ERR=""

ejcodret=""

pcmdexec=$1
popts=$(echo $@| cut -d'#' -f 2)
pMSG_OK=$(echo $@| cut -d'#' -f 3)
pMSG_ERR=$(echo $@| cut -d'#' -f 4)

echo -e "${C_ET}$ligrcmdver${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"

echo "$lingrcmdexec_MSG1: $pcmdexec $popts"

if test $MSG_OK = "NM" &> /dev/null || test $MSG_ERR = "NM" &> /dev/null;then

	$pcmdexec $popts

	if test $? -eq 0;then
	   ejcodret=0
	else
	   ejcodret=1
	fi
        

else

	if $pcmdexec $popts;then
		ejcodret=0
		echo -e "${C_OK} $pMSG_OK ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	else
		ejcodret=1
		echo -e "${C_FA} $pMSG_ERR ${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
	fi

fi

export ejcodret

sleep 1

}

# ImprimirProgreso
#
# Imprime una barra de progreso del proceso en ejecución.
# Ejemplo de internet. Funcion invocada de la siguiente manera:
# proceso_en_ejecucion & ImprimirProgreso

ImprimirProgreso(){

# pid del proceso ejecutado
local pid=$!
local delay=0.75
local spinstr='|/-\'

while [ "$(ps a | awk '{print $1}' | grep $pid)" ];do
    local temp=${spinstr#?}
    
    printf "%c" "$spinstr"
    local spinstr=$temp${spinstr%"$temp"}
    sleep $delay
    printf "\b"
    
done

}


