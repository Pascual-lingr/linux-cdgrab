#########################################################
# lcgdrabCMD_API/lcdgrabBD-API.sh
# Colección de funciones para grabaciones en BD (Blu-Ray Disc).
#
# Pascual Martínez Cruz --> pascual89@hotmail.com
# Distribuir bajo GPL v2
# Parte de Linux-cdgrab 1.0
#########################################################

############################ GRABACION EN BD #################################

# Expande el fichero de idioma

source ${D_LINUXCDGRAB}/lcdgrabAPI_idiom/${IDIOM}/lcdgrabCMD_API_idiom/lcdgrabBD-API.idiom

##############################################################################
################## API DE GRABACION CON dvd+-rw-tools ########################
##############################################################################

# grabar_ISO_BD
# graba una imagen iso-9660 o udf en BD-R/RE. Necesario growisofs.

grabar_ISO_BD(){

imagenBDiso=""

obten_cadena "$grabar_ISO_BD_MSG3" "$grabar_ISO_BD_MSG4"

imagenBDiso=$lacadena

vel="-speed=$Velocidad"

lingrcmdexec $lingrbdburn1 "#"$gus $grabadora_dvd=$imagenBDiso $growisofswimgdvd1 $vel "#" $grabar_ISO_BD_MSG1 "#" $grabar_ISO_BD_MSG2

}

# bd_disc_info
# Información del disco insertado en la unidad

bd_disc_info(){
	
	cabecera
	$lingrbdburn2 $grabadora_dvd
	echo ""
	teclash

}

##############################################################################
############ API DE GRABACION CON cdrecord-ProDVD-ProBD-Clone ################
##############################################################################

# grabar_ISO_BD_cdrecord
# graba una imagen iso-9660 o udf en BD-R/RE. Necesario Cdrecord-ProDVD/BD.

grabar_ISO_BD_cdrecord(){

	grabimg

}

# bd_datos
# graba datos del disco duro a un BD

bd_datos(){

	datos

}

# bd_discoinfo
# Muestra información del disco insertado en la unidad

bd_discoinfo(){

	discoinfo
}

##############################################################################
#################### API DE GRABACION CON libburnia ##########################
##############################################################################

# grabar_ISO_BD_cdrecord_libburnia
# graba una imagen iso-9660en BD-R/RE. Necesario cdrskin.

grabar_ISO_BD_libburnia(){

	grabimglb

}

# grabar_BD_datos_iso
# graba un BD-R/BD-RE con datos del disco requiere libburnia (xorriso y cdrskin).

grabar_BD_datos_iso(){

	datoslb

}

# borrar_BDRE_lb
# Hace el borrado necesario de un BD-RE

borrar_BDRE_lb(){

typeset local DEV="dev=$grabadora_dvd"

cabecera
echo -e "${C_AV}$borrar_BDRE_lb_MSG1${COLOR_DEL_INTERFAZ}${FONDO_INTERFAZ}"
sleep 2

lingrcmdexec $lingrbdburn3 "#" $cdrskincdrwerase1 $DEV $cdrskincdrwerase2 "#" $borrar_BDRE_lb_MSG2 "#" $borrar_BDRE_lb_MSG3

}


